const express = require('express');
const checkGeomAPI = express();
const { checkGeometry } = require('./checkGeometry');

checkGeomAPI.get('/validaGeom', checkGeometry);

checkGeomAPI.all('*', (req, res) => {
  res
    .setHeader(
      'Strict-Transport-Security',
      'max-age=31536000; includeSubDomains; preload'
    )
    .status(404)
    .json({
      message:
        'API Validación Check geometry - Reseccionamiento: Recurso no encontrado',
    });
});

exports.checkGeomAPI = checkGeomAPI;
