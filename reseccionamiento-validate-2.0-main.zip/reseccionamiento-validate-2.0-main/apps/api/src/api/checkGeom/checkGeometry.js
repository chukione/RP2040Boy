const { getConn, getQuery } = require('./../../services/sql');
const { validateParams, handleError } = require('./../../services/common');
const { logger } = require('firebase-functions');

const pool = getConn('reseccionamiento2024');

exports.checkGeometry = async (req, res) => {
  logger.info(`checkGeometry ${req.originalUrl}`);
  try {
    const response = await validateParams(req, {
      body: 'query',
      methods: ['get'],
      optional: ['e', 'd', 's', 'et'],
    });
    if (!response.status) {
      return handleError(req, res, response.message);
    }
    //* validamos entidad
    if (req.query.e !== undefined && req.query.e !== null) {
      if (isNaN(req.query.e)) {
        return handleError(req, res, '-entidad- debe ser un número');
      }
      const entidad = parseInt(req.query.e);
      if (!(entidad > 0 && entidad <= 32)) {
        return handleError(req, res, '-entidad- debe ser un valor de 1 a 32');
      }
      req.query.e = parseInt(req.query.e);
    } else {
      return handleError(
        req,
        res,
        '-entidad- es null o indefinido y debe ser un número'
      );
    }
    //* validamos distrito
    if (req.query.d !== undefined && req.query.d !== null) {
      if (isNaN(req.query.d)) {
        return handleError(req, res, '-distrito- debe ser un número');
      }
      const distrito = parseInt(req.query.d);
      if (!(distrito >= 1 && distrito <= 300)) {
        return handleError(req, res, '-distrito- debe ser un valor de 1 a 300');
      }
      req.query.d = parseInt(req.query.d);
    } else {
      return handleError(
        req,
        res,
        '-distrito- es null o indefinido y debe ser un número'
      );
    }

    //* validamos seccion
    if (req.query.s !== undefined && req.query.s !== null) {
      if (isNaN(req.query.s)) {
        return handleError(req, res, '-seccion- debe ser un número');
      }
      if (req.query.s.length > 4) {
        return handleError(req, res, '-seccion- debe contener hasta 4 cifras');
      }
      const seccion = parseInt(req.query.s);
      if (!(seccion > 0)) {
        return handleError(req, res, '-seccion- debe ser un valor mayor a 0');
      }
      req.query.s = parseInt(req.query.s);
    } else {
      return handleError(
        req,
        res,
        '-sección- es null o indefinido y debe ser un número'
      );
    }
    //* validamos etapa
    if (req.query.et !== undefined && req.query.et !== null) {
      if (isNaN(req.query.et)) {
        return handleError(req, res, '-etapa- debe ser un número');
      }
      const etapa = parseInt(req.query.et);
      if (!(etapa > 0)) {
        return handleError(req, res, '-etapa- debe ser un valor mayor a 0');
      }
      if (!(etapa > 0 && etapa <= 3)) {
        return handleError(req, res, '-etapa- debe ser un valor de 1 a 3');
      }
      req.query.et = parseInt(req.query.et);
    } else {
      return handleError(
        req,
        res,
        '-etapa- es null o indefinido y debe ser un número'
      );
    }
    const e = Number(req.query.e);
    const d = Number(req.query.d);
    const et = Number(req.query.et);
    let s = Number(req.query.s);
    let entidad = req.query.e.toString().length === 1 ? '0' + e : e;
    let distrito = req.query.d.toString().length === 1 ? '0' + d : d;
    let seccion;
    s = parseInt(s, 10);
    if (s < 10) {
      seccion = '000' + s;
    } else if (s < 100) {
      seccion = '00' + s;
    } else if (s < 1000) {
      seccion = '0' + s;
    } else {
      seccion = s;
    }
    //* Genera nombre de tablas
    const schema = `${entidad}dto${distrito}`;
    const tableRed = `"${schema}"."red${seccion}"`;
    const tableMzReseccionamiento = `"${schema}"."mz_reseccionamiento${seccion}"`;
    const tablePolRedInterMz = `"${schema}"."pol_red_inter_inter_mz${seccion}"`;
    const tableEscuela = `"${schema}"."escuela${seccion}"`;
    const tablePoligonosRed = `"${schema}"."poligonos_red${seccion}"`;
    const schema_temp = `${entidad}dto${distrito}`;

    let validacion = {
      entidad: e,
      distrito: d,
      seccion: s,
      etapa: et,
      geometria_red: 0,
      geometria_mz: 0,
      nodos_duplicados_red: 0,
      redes_duplicadas: 0,
      sobreposicion_mz: 0,
      sobreposicion_red_sobre_mz: 0,
      categoria_red: 0,
      sobreposicion_red: 0,
      manzana_repetida_geom: 0,
      manzana_repetida_datos: 0,
      manzana_datos_nulos_otros: 0,
      existe_tabla_poligonos: 0,
      existe_tabla_poligonos_campo_gid: 0,
      existe_tabla_poligonos_campo_geom: 0,
      manzana_sin_poligono: 0,
      manzanas_intersectan_poligonos: 0,
      poligono_con_mas_manzanas: 0,
      poligonos_sin_manzanas: 0,
      existe_tabla_pol_red: 0,
      existe_tabla_pol_red_campo_geom: 0,
      totales: 0,
      sobreposicion_pol_red: 0,
      sobreposicion_red_sobre_pol_red: 0,
      existe_tabla_pol_red_campo_poligono: 0,
      fraccionamientos: 0,
      nulos_escuela: 0,
    };

    /*----------------------------Comprobar geometria en la capa red-----------------------------*/
    try {
      const validar_geometria_red = [];

      const queryCheckGeometry = `
      SELECT the_geom, gid
      FROM ${tableRed}
      WHERE NOT ST_isValid(the_geom)
      OR ST_Length(the_geom) = 0
      OR the_geom IS NULL;
      `;

      const resCheckGeometry = await getQuery(pool, queryCheckGeometry);

      let i = 0;
      const gids = [];
      resCheckGeometry.rows.forEach((row) => {
        validar_geometria_red[i]['gid'] = row.gid;
        gids.push(row.gid);
        i++;
      });

      if (gids.length) {
        const gids_str = gids.join(',');
        // Elimina Geometrias invalidas o nulas
        const queryDelete = `
        DELETE FROM ${tableRed} WHERE gid IN (${gids_str});
        `;
        await getQuery(pool, queryDelete);
        validacion.geometria_red = 0;
      } else {
        validacion.geometria_red = 1;
      }
    } catch (error) {
      error.validar_geometria_red = e;
    }

    /*----------------------------Comprobar geometria mz-reseccionamiento-----------------------------*/
    try {
      const validar_geometria_mz = [];
      // Primero las geometrias no validas
      const queryCheckGeometryMz = `
      SELECT manzana, gid FROM ${tableMzReseccionamiento}
      WHERE NOT ST_isValid(the_geom);
      `;
      const resCheckGeometryMz = getQuery(pool, queryCheckGeometryMz);

      validacion.geometria_mz = 1;

      let i = 0;

      resCheckGeometryMz.rows.forEach((row) => {
        validacion.geometria_mz = 0;
        const gid = row.gid;
        const manzana = row.manzana;
        validar_geometria_mz[i] = {
          i: i + 1,
          manzana: manzana !== undefined ? manzana : 'nulo',
          gid: gid,
          nula: 0,
        };
        i++;
      });

      /* Luego geometrías nulas */
      const queryNullGeometryMz = `
      SELECT manzana, gid FROM ${tableMzReseccionamiento}
      WHERE ST_Area(the_geom) = 0
      OR ST_Perimeter(the_geom) = 0
      OR the_geom IS NULL;
      `;

      const resNullGeometryMz = getQuery(pool, queryNullGeometryMz);

      const gids = [];
      let j = 0;

      resNullGeometryMz.rows.forEach((row) => {
        const gid = row.gid;
        const manzana = row.manzana;
        validar_geometria_mz[i] = {
          i: j + 1,
          manzana: manzana !== undefined ? manzana : 'nulo',
          gid: gid,
          nula: 1,
        };
      });

      if (gids.length) {
        const gids_str = gids.join(',');
        //* eliminar geometrias nulas
        const queryDeleteNull = `
        DELETE FROM ${tableMzReseccionamiento}
        WHERE gid IN (${gids_str});
        `;
        await getQuery(pool, queryDeleteNull);
        validacion.geometria_mz = 0;
      }
    } catch (error) {
      error.validar_geometria_mz = e;
    }

    /*----------------------------Comprobar nodos duplicados en la capa red-----------------------------*/
    try {
      const nodos_duplicados_red = {
        nodos: null,
        total: 0,
      };

      const queryDuplicateNodes = `
      SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb, 'properties', '{}'::jsonb) AS the_geom, gid, COUNT(*)
      FROM (
       SELECT( ST_Dump(ST_Points(the_geom))).geom as the_geom, gid
       FROM ${tableRed} as red 
       WHERE red.gid NOT IN (
             SELECT gid FROM ${tableRed}
             WHERE ST_RemoveRepeatedPoints(the_geom) = the_geom
            ) AND red.gid = 491
      ) AS g
      GROUP BY the_geom, gid
      HAVING COUNT(*) > 1;
      `;

      const resDuplicateNodes = getQuery(pool, queryDuplicateNodes);

      nodos_duplicados_red.total = resDuplicateNodes.length;

      const gids = [];
      const geometries = [];
      const gid_ordenados = {};

      resDuplicateNodes.rows.forEach((row) => {
        const gid = row.gid;
        const geometry = row.the_geom;

        if (!geometries.includes(geometry)) {
          geometries.push(geometry);
        }
        if (!gids.includes(gid)) {
          gids.push(gid);
          gid_ordenados[gid] = {
            gid: gid,
            contador: 1,
          };
        } else {
          gid_ordenados[gid].contador++;
        }
      });

      if (gids.length) {
        let i = 0;
        gid_ordenados.forEach((gid) => {
          nodos_duplicados_red.lista[i] = {
            i: i + 1,
            gid: gid.gid,
            repetidos: gid.contador,
          };
          i++;
        });
        const featuresJSON = '[' + geometries.join(',') + ']';
        nodos_duplicados_red.nodos = JSON.stringify({
          type: 'FeatureCollection',
          features: JSON.parse(featuresJSON),
        });
        const gids_str = gids.join(',');
        //TODO elimina nodos duplicados
        const queryRepair = `
        UPDATE ${tableRed}
        SET the_geom = ST_RemoveRepeatedPoints(the_geom)
        WHERE gid IN (${gids_str});
        `;
        getQuery(pool, queryRepair);

        const queryLineas = `
        SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb, 'properties', to_jsonb(r.*) - 'the_geom') AS the_geom
        FROM ${tableRed} as r WHERE gid IN (${gids_str}) 
        `;

        const resLineas = getQuery(pool, queryLineas);

        const geometries = [];
        resLineas.rows.forEach((row) => {
          geometries.push(row.the_geom);
        });
        nodos_duplicados_red.lineas =
          '{"type":"FeatureCollection","features":[' +
          geometries.join(',') +
          ']}';
        validacion.nodos_duplicados_red = 0;
      } else {
        validacion.nodos_duplicados_red = 1;
      }
    } catch (error) {
      error.nodos_duplicados_red = e;
    }
    /*----------------------------Comprobar geometrias red duplicadas y eliminar-----------------------------*/
    try {
      const geometrias_duplicadas_red = {
        lista: [],
      };
      const queryDuplicateGeometries = `
      SELECT gid, r.the_geom as the_geom, jsonb_build_object('type','Feature','geometry',
      ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb, 'properties', to_jsonb(r.*) - 'the_geom') AS the_geom_b
      FROM ( SELECT the_geom
                  FROM ${tableRed} 
                  WHERE NOT(NOT ST_isValid(the_geom)
                  OR ST_Length(the_geom) = 0
                  OR the_geom IS NULL)
                  GROUP BY the_geom HAVING COUNT(*) > 1
            ) as g, ${tableRed} as r 
      WHERE g.the_geom = r.the_geom;
      `;

      const resDuplicateGeometries = getQuery(pool, queryDuplicateGeometries);

      let i = 0;
      const gids = [];
      const geometries = [];
      const geometries_b = [];
      const gid_ordenados = [];

      resDuplicateGeometries.rows.forEach((row) => {
        const gid = row.gid;
        const geometry = row.the_geom;
        const geometry_b = row.the_geom_b;
        if (geometries.includes(geometry)) {
          gid_ordenados[geometry].repetidos.push(gid);
          gids.push(gid);
        } else {
          gid_ordenados[geometry].gid = gid;
          gid_ordenados[geometry].repetidos = [];
          geometries.push(geometry);
          geometries_b.push(geometry_b);
        }
        i++;
      });

      if (gids.length) {
        geometrias_duplicadas_red.duplicados = geometries.length;
        let i = 0;
        gid_ordenados.forEach((gid_) => {
          geometrias_duplicadas_red.lista[i] = {
            i: i + 1,
            gid: gid_.gid,
            repetidos: gid_.repetidos.join(','),
          };
          i++;
        });
        geometrias_duplicadas_red.geometry =
          '{"type":"FeatureCollection","features":[' +
          geometries_b.join(',') +
          ']}';
        const gids_str = gids.join(',');
        //TODO Eliminar geometrias duplicadas
        const queryDelete = `
        DELTE FROM ${tableRed}
        WHERE gid IN ($1)
        `;

        getQuery(pool, queryDelete, gids_str);

        validacion.redes_duplicadas = 0;
      } else {
        validacion.redes_duplicadas = 1;
      }
    } catch (error) {
      error.geometrias_duplicadas_red = error;
    }
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
