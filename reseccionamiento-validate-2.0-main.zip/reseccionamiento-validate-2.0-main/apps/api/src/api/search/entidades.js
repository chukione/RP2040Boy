const { getConn, getQuery } = require('./../../services/sql');
const { validateParams, handleError } = require('./../../services/common');
const { logger } = require('firebase-functions');

const pool = getConn('reseccionamiento2024');

exports.getSearchGoverment = async (req, res) => {
  logger.info(`getSearchEntidad ${req.originalUrl}`);
  try {
    const response = await validateParams(req, {
      body: 'query',
      methods: ['get'],
    });
    if (!response.status) {
      return handleError(req, res, response.message);
    }
    const query = `
    SELECT distinct(entidad) as entidad FROM public.seccion ORDER BY entidad
  `;
    const resEntidad = await getQuery(pool, query, []);
    if (resEntidad.rowCount <= 0) {
      res
        .setHeader(
          'Strict-Transport-Security',
          'max-age=31536000; includeSubDomains; preload'
        )
        .json({ code: '02', data: null });
    }
    const goverments = [];
    resEntidad.rows.forEach((row) => {
      goverments.push(row.entidad);
    });
    res
      .setHeader(
        'Strict-Transport-Security',
        'max-age=31536000; includeSubDomains; preload'
      )
      .json({ code: '02', data: goverments });
  } catch (error) {
    return handleError(req, res, 'Error server');
  }
};
