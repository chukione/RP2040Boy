const { getConn, getQuery } = require('./../../services/sql');
const { validateParams, handleError } = require('./../../services/common');
const { logger } = require('firebase-functions');

const pool = getConn('reseccionamiento2024');

exports.getSearchDistrito = async (req, res) => {
  logger.info(`getSearchDistrito ${req.originalUrl}`);
  try {
    const response = await validateParams(req, {
      body: 'query',
      methods: ['get'],
      optional: ['e'],
    });
    if (!response.status) {
      return handleError(req, res, response.message);
    }
    //* validamos entidad
    if (req.query.e) {
      if (isNaN(req.query.e)) {
        return handleError(req, res, '-entidad- debe ser un número');
      }
      const entidad = parseInt(req.query.e);
      if (!(entidad > 0 && entidad <= 32)) {
        return handleError(req, res, '-entidad- debe ser un valor de 1 a 32');
      }
      req.query.e = parseInt(req.query.e);
    }
    const entidad = Number(req.query.e);
    const query = `
    SELECT DISTINCT(distrito) FROM public.secciones where entidad=$1 ORDER BY distrito
  `;
    const resDsitritos = await getQuery(pool, query, [entidad]);
    if (resDsitritos.rowCount <= 0) {
      return res
        .setHeader(
          'Strict-Transport-Security',
          'max-age=31536000; includeSubDomains; preload'
        )
        .json({ code: '02', data: [] });
    }
    const goverments = [];
    resDsitritos.rows.forEach((row) => {
      goverments.push(row.distrito);
    });
    res
      .setHeader(
        'Strict-Transport-Security',
        'max-age=31536000; includeSubDomains; preload'
      )
      .json({ code: '02', data: goverments });
  } catch (error) {
    return handleError(req, res, 'Error server');
  }
};
