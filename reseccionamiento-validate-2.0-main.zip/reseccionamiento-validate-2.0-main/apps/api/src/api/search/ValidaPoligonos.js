const { getConn, getQuery } = require('../../services/sql');
const { validateParams, handleError } = require('../../services/common');
const { logger } = require('firebase-functions');

const pool = getConn('reseccionamiento2024');

exports.validateStagePoligonos = async (req, res) => {
  logger.info(`validateStageTwo ${req.originalUrl}`);
  try {
    const response = await validateParams(req, {
      body: 'query',
      methods: ['get'],
      optional: ['e', 'd', 's', 'et'],
    });
    if (!response.status) {
      return handleError(req, res, response.message);
    }
    //* validamos entidad
    if (req.query.e !== undefined && req.query.e !== null) {
      if (isNaN(req.query.e)) {
        return handleError(req, res, '-entidad- debe ser un número');
      }
      const entidad = parseInt(req.query.e);
      if (!(entidad > 0 && entidad <= 32)) {
        return handleError(req, res, '-entidad- debe ser un valor de 1 a 32');
      }
      req.query.e = parseInt(req.query.e);
    } else {
      return handleError(
        req,
        res,
        '-entidad- es null o indefinido y debe ser un número'
      );
    }
    //* validamos distrito
    if (req.query.d !== undefined && req.query.d !== null) {
      if (isNaN(req.query.d)) {
        return handleError(req, res, '-distrito- debe ser un número');
      }
      const distrito = parseInt(req.query.d);
      if (!(distrito >= 1 && distrito <= 300)) {
        return handleError(req, res, '-distrito- debe ser un valor de 1 a 300');
      }
      req.query.d = parseInt(req.query.d);
    } else {
      return handleError(
        req,
        res,
        '-distrito- es null o indefinido y debe ser un número'
      );
    }

    //* validamos seccion
    if (req.query.s !== undefined && req.query.s !== null) {
      if (isNaN(req.query.s)) {
        return handleError(req, res, '-seccion- debe ser un número');
      }
      if (req.query.s.length > 4) {
        return handleError(req, res, '-seccion- debe contener hasta 4 cifras');
      }
      const seccion = parseInt(req.query.s);
      if (!(seccion > 0)) {
        return handleError(req, res, '-seccion- debe ser un valor mayor a 0');
      }
      req.query.s = parseInt(req.query.s);
    } else {
      return handleError(
        req,
        res,
        '-sección- es null o indefinido y debe ser un número'
      );
    }
    //* validamos distrito
    if (req.query.et !== undefined && req.query.et !== null) {
      if (isNaN(req.query.et)) {
        return handleError(req, res, '-etapa- debe ser un número');
      }
      const etapa = parseInt(req.query.et);
      if (!(etapa >= 1 && etapa <= 3)) {
        return handleError(req, res, '-etapa- debe ser un valor de 1 a 3');
      }
      req.query.et = parseInt(req.query.et);
    } else {
      return handleError(
        req,
        res,
        '-eatapa- es null o indefinido y debe ser un número'
      );
    }
    const e = Number(req.query.e);
    const d = Number(req.query.d);
    // const se = Number(req.query.s);
    let s = Number(req.query.s);
    let entidad = req.query.e.toString().length === 1 ? '0' + e : e;
    let distrito = req.query.d.toString().length === 1 ? '0' + d : d;
    let seccion;
    s = parseInt(s, 10);
    if (s < 10) {
      seccion = '000' + s;
    } else if (s < 100) {
      seccion = '00' + s;
    } else if (s < 1000) {
      seccion = '0' + s;
    } else {
      seccion = s;
    }
    //* variables schemas
    const schema = `${entidad}dto${distrito}`;
    const tableSeccion = `"${schema}"."seccion${seccion}"`;
    const tableRed = `"${schema}"."red${seccion}"`;
    const tableMzReseccionamiento = `"${schema}"."mz_reseccionamiento${seccion}"`;
    const tableEscuela = `"${schema}"."escuela${seccion}"`;
    const tablePolRedInterMz = `"${schema}"."pol_red_inter_mz${seccion}"`;
    const tablePoligonosRed = `"${schema}"."poligonos_red.${seccion}"`;
    const schemaTemp = `${entidad}.dto.${distrito}`;

    //* Comprobar geometria en la capa red
    const validarGeometriaRed = [];
    const validarGeometriaRedDelete = [];
    const queryCheckGeometry = `SELECT the_geom, gid FROM ${tableRed} WHERE NOT ST_isValid(the_geom) OR ST_Length(the_geom) = 0 OR the_geom IS NULL;`;
    const resValidateRed = await getQuery(pool, queryCheckGeometry, []);
    if (resValidateRed.rowCount > 0) {
      resValidateRed.rows.forEach((row) => {
        validarGeometriaRed.push({ the_geom: row.the_geom, gid: row.gid });
        validarGeometriaRedDelete.push(row.gid);
      });
      const queryDeleteGeomRed = `DELETE FROM ${tableRed} WHERE gid IN (${validarGeometriaRedDelete.join(
        ','
      )});`;
      await getQuery(pool, queryDeleteGeomRed, []);
      // TODO geomRed invalidas > 0
      //* $validacion['geometria_red'] = 0
    }
    // TODO 0 geomRed invalidas
    //* $validacion['geometria_red'] = 1

    //* Comprobar geometria mz-reseccionamiento
    const validarGeometriaMz = { invalidas: [], nulas: [] };
    const queryCheckGeomMz = `SELECT manzana, gid FROM ${tableMzReseccionamiento} WHERE NOT ST_isValid(the_geom);`;
    const resMzNotValid = await getQuery(pool, queryCheckGeomMz, []);
    // TODO 1 geomMz
    //* $validacion['geometria_mz'] = 1
    if (resMzNotValid.rowCount > 0) {
      resMzNotValid.rows.forEach((row) => {
        validarGeometriaMz.invalidas.push({
          gid: row.gid,
          manzana: row.manzana ? row.manzana : null,
        });
      });
    }
    const queryGeomMzNull = `SELECT manzana, gid FROM ${tableMzReseccionamiento} WHERE ST_Area(the_geom) = 0 OR ST_Perimeter(the_geom) = 0 OR the_geom IS NULL;`;
    const resMzNull = await getQuery(pool, queryGeomMzNull, []);
    const deleteMzNulls = [];
    if (resMzNull.rowCount > 0) {
      resMzNull.rows.forEach((row) => {
        validarGeometriaMz.nulas.push({
          gid: row.gid,
          manzana: row.manzana ? row.manzana : null,
        });
        deleteMzNulls.push(row.gid);
      });
    }
    if (
      validarGeometriaMz.nulas.length > 0 ||
      validarGeometriaMz.invalidas.length > 0
    ) {
      // TODO 1 geomMz
      //* $validacion['geometria_mz'] = 0
    }
    if (deleteMzNulls.length > 0) {
      const queryDeleteMzNull = `DELETE FROM ${tableMzReseccionamiento} WHERE gid IN (${deleteMzNulls.join(
        ','
      )});`;
      await getQuery(pool, queryDeleteMzNull, []);
    }
    //* Comprobar nodos duplicados en la capa red
    const nodosDuplicadosRed = {
      nodos: [],
      total: 0,
      nodosDuplicados: [],
      lines: [],
    };
    const queryDuplicateNodes = `SELECT jsonb_build_object('type','Feature','geometry',
    ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb,'properties', '{}'::jsonb) AS the_geom,
    gid, COUNT(*) FROM (SELECT (ST_Dump(ST_Points(the_geom))).geom as the_geom, gid FROM ${tableRed} as red 
    WHERE red.gid NOT IN (SELECT gid FROM ${tableRed} WHERE ST_RemoveRepeatedPoints(the_geom) = the_geom)) AS g GROUP BY the_geom, gid HAVING COUNT(*) > 1;`;
    const resDuplicatedNodes = await getQuery(pool, queryDuplicateNodes, []);
    if (resDuplicatedNodes.rowCount > 0) {
      nodosDuplicadosRed.total = resDuplicatedNodes.rowCount;
      const gids = [];
      const geometries = [];
      const gidOrdenados = [];
      resDuplicatedNodes.rows.forEach((row) => {
        const gid = row.gid;
        const geometry = row.the_geom;
        if (!geometries.includes(geometry)) {
          geometries.push(geometry);
        }
        if (!gids.includes(gid)) {
          gids.push(gid);
          gidOrdenados[gid] = { gid: gid, contador: 1 };
        } else {
          gidOrdenados[gid].contador++;
        }
      });
      if (gids.length > 0) {
        gidOrdenados.forEach((gidx) => {
          nodosDuplicadosRed.nodosDuplicados.push({
            gid: gidx.gid,
            contador: gidx.contador,
          });
        });

        nodosDuplicadosRed.nodos = `{"type":"FeatureCollection","features":[${geometries.map(
          (str) => JSON.stringify(str)
        )}]}`;
        const sqlRepair = `UPDATE ${tableRed} SET the_geom = ST_RemoveRepeatedPoints(the_geom) WHERE gid IN (${gids.join(
          ','
        )});`;
        await getQuery(pool, sqlRepair, []);
        const sqlLines = `SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb, 
        'properties', to_jsonb(r.*) - 'the_geom') AS the_geom FROM ${tableRed} as r WHERE gid IN (${gids.join(
          ','
        )});`;
        const resLines = await getQuery(pool, sqlLines, []);
        const geometriesLines = [];
        if (resLines.rowCount > 0) {
          resLines.rows.forEach((row) => {
            geometriesLines.push(row.the_geom);
          });
          nodosDuplicadosRed.lines = `{"type":"FeatureCollection","features":[${geometriesLines.map(
            (str) => JSON.stringify(str)
          )}]}`;
        }
        // TODO validation
        // $validacion['nodos_duplicados_red'] = 0;
      } else {
        // TODO validation
        // $validacion['nodos_duplicados_red'] = 1;
      }
    }
    //* Comprobar geometrias red duplicadas y eliminar
    const geometriasDuplicadasRed = {
      lista: [],
      duplicados: 0,
      geometry: null,
    };
    const queryDuplicateGeometries = `SELECT gid, r.the_geom as the_geom, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb,
    'properties', to_jsonb(r.*) - 'the_geom') AS the_geom_b FROM ( SELECT the_geom FROM ${tableRed} WHERE NOT(NOT ST_isValid(the_geom) 
    OR ST_Length(the_geom) = 0 OR the_geom IS NULL) GROUP BY the_geom HAVING COUNT(*) > 1) as g, ${tableRed} as r WHERE g.the_geom = r.the_geom;`;
    const resDuplicateGeom = await getQuery(pool, queryDuplicateGeometries, []);
    if (resDuplicateGeom.rowCount > 0) {
      const gidsx = [];
      const geometriesx = [];
      const geometriesB = [];
      const gidOrdenadosx = [];
      resDuplicateGeom.rows.forEach((row) => {
        const gidx = row.gid;
        const geometryx = row.the_geom;
        const geometryB = row.the_geom_b;
        if (geometriesx.includes(geometryx)) {
          gidOrdenadosx[geometryx].repetidos.push(gidx);
          gidsx.push(gidx);
        } else {
          gidOrdenadosx[geometryx] = {
            gid: gidx,
            repetidos: [],
          };
          geometriesx.push(geometryx);
          geometriesB.push(geometryB);
        }
      });
      if (gidsx.length > 0) {
        geometriasDuplicadasRed.duplicados = geometriesx.length;
        for (let geometryk in gidOrdenadosx) {
          geometriasDuplicadasRed.lista.push({
            gid: gidOrdenadosx[geometryk].gid,
            repetidos: gidOrdenadosx[geometryk].repetidos,
          });
        }
        geometriasDuplicadasRed.geometry = `{"type":"FeatureCollection","features":[${geometriesB.map(
          (str) => JSON.stringify(str)
        )}]}`;
        const queryDeleteRedDu = `DELETE FROM ${tableRed} WHERE gid IN (${gidsx.join(
          ','
        )});`;
        await getQuery(pool, queryDeleteRedDu, []);
        // TODO validation
        //* $validacion['redes_duplicadas'] = 0;
      } else {
        //* $validacion['redes_duplicadas'] = 1;
      }
    }
    res
      .setHeader(
        'Strict-Transport-Security',
        'max-age=31536000; includeSubDomains; preload'
      )
      .json({
        code: '02',
        data: {
          validarGeometriaRed,
          validarGeometriaMz,
          nodosDuplicadosRed,
          geometriasDuplicadasRed,
        },
      });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
