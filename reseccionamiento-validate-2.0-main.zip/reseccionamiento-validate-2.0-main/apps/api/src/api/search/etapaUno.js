const { getConn, getQuery } = require('../../services/sql');
const { validateParams, handleError } = require('../../services/common');
const { logger } = require('firebase-functions');

const pool = getConn('reseccionamiento2024');

exports.etapaUno = async (req, res) => {
  logger.info(`etapaUno ${req.originalUrl}`);
  try {
    const response = await validateParams(req, {
      body: 'query',
      methods: ['get'],
      optional: ['e', 'd', 's', 'et', 'user'],
    });
    if (!response.status) {
      return handleError(req, res, response.message);
    }
    //* validamos entidad
    if (req.query.e !== undefined && req.query.e !== null) {
      if (isNaN(req.query.e)) {
        return handleError(req, res, '-entidad- debe ser un número');
      }
      const entidad = parseInt(req.query.e);
      if (!(entidad > 0 && entidad <= 32)) {
        return handleError(req, res, '-entidad- debe ser un valor de 1 a 32');
      }
      req.query.e = parseInt(req.query.e);
    } else {
      return handleError(
        req,
        res,
        '-entidad- es null o indefinido y debe ser un número'
      );
    }
    //* validamos distrito
    if (req.query.d !== undefined && req.query.d !== null) {
      if (isNaN(req.query.d)) {
        return handleError(req, res, '-distrito- debe ser un número');
      }
      const distrito = parseInt(req.query.d);
      if (!(distrito >= 1 && distrito <= 300)) {
        return handleError(req, res, '-distrito- debe ser un valor de 1 a 300');
      }
      req.query.d = parseInt(req.query.d);
    } else {
      return handleError(
        req,
        res,
        '-distrito- es null o indefinido y debe ser un número'
      );
    }

    //* validamos seccion
    if (req.query.s !== undefined && req.query.s !== null) {
      if (isNaN(req.query.s)) {
        return handleError(req, res, '-seccion- debe ser un número');
      }
      if (req.query.s.length > 4) {
        return handleError(req, res, '-seccion- debe contener hasta 4 cifras');
      }
      const seccion = parseInt(req.query.s);
      if (!(seccion > 0)) {
        return handleError(req, res, '-seccion- debe ser un valor mayor a 0');
      }
      req.query.s = parseInt(req.query.s);
    } else {
      return handleError(
        req,
        res,
        '-sección- es null o indefinido y debe ser un número'
      );
    }
    //* validamos distrito
    if (req.query.et !== undefined && req.query.et !== null) {
      if (isNaN(req.query.et)) {
        return handleError(req, res, '-etapa- debe ser un número');
      }
      const etapa = parseInt(req.query.et);
      if (!(etapa >= 1 && etapa <= 3)) {
        return handleError(req, res, '-etapa- debe ser un valor de 1 a 3');
      }
      req.query.et = parseInt(req.query.et);
    } else {
      return handleError(
        req,
        res,
        '-eatapa- es null o indefinido y debe ser un número'
      );
    }
    const e = Number(req.query.e);
    const d = Number(req.query.d);
    const et = Number(req.query.et);
    const user = String(req.query.user);
    let s = Number(req.query.s);
    let entidad = req.query.e.toString().length === 1 ? '0' + e : e;
    let distrito = req.query.d.toString().length === 1 ? '0' + d : d;
    let seccion;
    s = parseInt(s, 10);
    if (s < 10) {
      seccion = '000' + s;
    } else if (s < 100) {
      seccion = '00' + s;
    } else if (s < 1000) {
      seccion = '0' + s;
    } else {
      seccion = s;
    }
    // creamos id para update validacion
    const id = `${entidad}${distrito}${seccion}`;
    //* variables schemas
    const schema = `${entidad}dto${distrito}`;
    const tableRed = `"${schema}"."red${seccion}"`;
    const tableMzReseccionamiento = `"${schema}"."mz_reseccionamiento${seccion}"`;

    const validacion = {
      stamp: null,
      user,
      geometriaRedNull: 0,
      geometriaRedInvalidas: 0,
      geometriaMz: 0,
      nodosDuplicadosRed: 0,
      redesDuplicadas: 0, //hasta aqui son las globales
      sobreposicionMz: 0,
      sobreposicionRedSobreMz: 0,
      categoriaRed: 0,
    };

    //* Comprobar geometria en la capa red
    const validarGeometriaRed = [];
    const validarGeometriaRedDelete = [];
    const queryCheckGeometry = `SELECT the_geom, gid FROM ${tableRed} WHERE NOT ST_isValid(the_geom) OR ST_Length(the_geom) = 0 OR the_geom IS NULL;`;
    const resValidateRed = await getQuery(pool, queryCheckGeometry, []);
    if (resValidateRed.rowCount > 0) {
      resValidateRed.rows.forEach((row) => {
        validarGeometriaRed.push({ the_geom: row.the_geom, gid: row.gid });
        validarGeometriaRedDelete.push(row.gid);
      });
      const queryDeleteGeomRed = `DELETE FROM ${tableRed} WHERE gid IN (${validarGeometriaRedDelete.join(
        ','
      )});`;
      // TODO DELETE
      await getQuery(pool, queryDeleteGeomRed, []);
      validacion.geometriaRedNull = 0;
    }
    validacion.geometriaRedNull = 1;
    // Comprobar geometría invalidas capa red
    const validarGeometriaRedInvalidas = {
      lista: [],
      geometry: null,
    };

    const queryCheckGeometryInvalidas = `SELECT gid, ST_AsGeoJSON(the_geom) AS geom FROM ${tableRed} WHERE ST_IsSimple(the_geom) = 'f' OR ST_MinimumClearance(the_geom) <0.00000000001;`;
    const resValidateRedInvalid = await getQuery(
      pool,
      queryCheckGeometryInvalidas,
      []
    );
    if (resValidateRedInvalid.rowCount > 0) {
      const features = [];
      const lista = [];

      resValidateRedInvalid.rows.forEach((row) => {
        const geometry = JSON.parse(row.geom);
        geometry.properties = { gid: row.gid };
        features.push(geometry);
        lista.push({ gid: row.gid, geom: row.geom });
      });

      const featureCollection = {
        type: 'FeatureCollection',
        features: features,
      };

      validarGeometriaRedInvalidas.invalidas = resValidateRedInvalid.rowCount;
      validarGeometriaRedInvalidas.geometry = JSON.stringify(featureCollection);
      validarGeometriaRedInvalidas.lista = lista;
      validacion.geometriaRedInvalidas = 0;
    } else {
      validacion.geometriaRedInvalidas = 1;
    }
    /// Termina geom invalidas
    //* Comprobar geometria mz-reseccionamiento
    const validarGeometriaMz = { invalidas: [], nulas: [] };
    const queryCheckGeomMz = `SELECT manzana, gid FROM ${tableMzReseccionamiento} WHERE NOT ST_isValid(the_geom);`;
    const resMzNotValid = await getQuery(pool, queryCheckGeomMz, []);
    validacion.geometriaMz = 1;
    if (resMzNotValid.rowCount > 0) {
      resMzNotValid.rows.forEach((row) => {
        validarGeometriaMz.invalidas.push({
          gid: row.gid,
          manzana: row.manzana ? row.manzana : null,
        });
      });
    }
    const queryGeomMzNull = `SELECT manzana, gid FROM ${tableMzReseccionamiento} WHERE ST_Area(the_geom) = 0 OR ST_Perimeter(the_geom) = 0 OR the_geom IS NULL;`;
    const resMzNull = await getQuery(pool, queryGeomMzNull, []);
    const deleteMzNulls = [];
    if (resMzNull.rowCount > 0) {
      resMzNull.rows.forEach((row) => {
        validarGeometriaMz.nulas.push({
          gid: row.gid,
          manzana: row.manzana ? row.manzana : null,
        });
        deleteMzNulls.push(row.gid);
      });
    }
    if (
      validarGeometriaMz.nulas.length > 0 ||
      validarGeometriaMz.invalidas.length > 0
    ) {
      validacion.geometriaMz = 0;
    }
    if (deleteMzNulls.length > 0) {
      const queryDeleteMzNull = `DELETE FROM ${tableMzReseccionamiento} WHERE gid IN (${deleteMzNulls.join(
        ','
      )});`;
      // TODO DELETE
      await getQuery(pool, queryDeleteMzNull, []);
    }
    //* Comprobar nodos duplicados en la capa red
    const nodosDuplicadosRed = {
      nodos: [],
      total: 0,
      nodosDuplicados: [],
      lines: [],
    };
    const queryDuplicateNodes = `SELECT jsonb_build_object('type','Feature','geometry',
    ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb,'properties', '{}'::jsonb) AS the_geom,
    gid, COUNT(*) FROM (SELECT (ST_Dump(ST_Points(the_geom))).geom as the_geom, gid FROM ${tableRed} as red 
    WHERE red.gid NOT IN (SELECT gid FROM ${tableRed} WHERE ST_RemoveRepeatedPoints(the_geom) = the_geom)) AS g GROUP BY the_geom, gid HAVING COUNT(*) > 1;`;
    const resDuplicatedNodes = await getQuery(pool, queryDuplicateNodes, []);
    if (resDuplicatedNodes.rowCount > 0) {
      nodosDuplicadosRed.total = resDuplicatedNodes.rowCount;
      const gids = [];
      const geometries = [];
      const gidOrdenados = [];
      resDuplicatedNodes.rows.forEach((row) => {
        const gid = row.gid;
        const geometry = row.the_geom;
        if (!geometries.includes(geometry)) {
          geometries.push(geometry);
        }
        if (!gids.includes(gid)) {
          gids.push(gid);
          gidOrdenados[gid] = { gid: gid, contador: 1 };
        } else {
          gidOrdenados[gid].contador++;
        }
      });
      if (gids.length > 0) {
        gidOrdenados.forEach((gidx) => {
          nodosDuplicadosRed.nodosDuplicados.push({
            gid: gidx.gid,
            contador: gidx.contador,
          });
        });

        nodosDuplicadosRed.nodos = `{"type":"FeatureCollection","features":[${geometries.map(
          (str) => JSON.stringify(str)
        )}]}`;
        const sqlRepair = `UPDATE ${tableRed} SET the_geom = ST_RemoveRepeatedPoints(the_geom) WHERE gid IN (${gids.join(
          ','
        )});`;
        await getQuery(pool, sqlRepair, []);
        const sqlLines = `SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb, 
        'properties', to_jsonb(r.*) - 'the_geom') AS the_geom FROM ${tableRed} as r WHERE gid IN (${gids.join(
          ','
        )});`;
        const resLines = await getQuery(pool, sqlLines, []);
        const geometriesLines = [];
        if (resLines.rowCount > 0) {
          resLines.rows.forEach((row) => {
            geometriesLines.push(row.the_geom);
          });
          nodosDuplicadosRed.lines = `{"type":"FeatureCollection","features":[${geometriesLines.map(
            (str) => JSON.stringify(str)
          )}]}`;
        }
        validacion.nodosDuplicadosRed = 0;
      } else {
        validacion.nodosDuplicadosRed = 1;
      }
    }
    //* Comprobar geometrias red duplicadas y eliminar
    const geometriasDuplicadasRed = {
      lista: [],
      duplicados: 0,
      geometry: null,
    };
    // const queryDuplicateGeometries = `SELECT gid, r.the_geom as the_geom, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb,
    // 'properties', to_jsonb(r.*) - 'the_geom') AS the_geom_b FROM ( SELECT the_geom FROM ${tableRed} WHERE NOT(NOT ST_isValid(the_geom)
    // OR ST_Length(the_geom) = 0 OR the_geom IS NULL) GROUP BY the_geom HAVING COUNT(*) > 1) as g, ${tableRed} as r WHERE g.the_geom = r.the_geom;`;
    const queryDuplicateGeometries = `SELECT b.gid, b.the_geom, ST_AsGeoJSON(b.*)::jsonb as the_geom_b FROM ${tableRed} AS a, ${tableRed} AS b WHERE ST_Equals(a.the_geom, b.the_geom) AND a.gid <> b.gid;`;
    const resDuplicateGeom = await getQuery(pool, queryDuplicateGeometries, []);
    if (resDuplicateGeom.rowCount > 0) {
      const gidsx = [];
      const geometriesx = [];
      const geometriesB = [];
      const gidOrdenadosx = [];
      resDuplicateGeom.rows.forEach((row) => {
        const gidx = row.gid;
        const geometryx = row.the_geom;
        const geometryB = row.the_geom_b;
        if (geometriesx.includes(geometryx)) {
          gidOrdenadosx[geometryx].repetidos.push(gidx);
          gidsx.push(gidx);
        } else {
          gidOrdenadosx[geometryx] = {
            gid: gidx,
            repetidos: [],
          };
          geometriesx.push(geometryx);
          geometriesB.push(geometryB);
        }
      });
      if (gidsx.length > 0) {
        geometriasDuplicadasRed.duplicados = geometriesx.length;
        for (let geometryk in gidOrdenadosx) {
          geometriasDuplicadasRed.lista.push({
            gid: gidOrdenadosx[geometryk].gid,
            repetidos: gidOrdenadosx[geometryk].repetidos,
          });
        }
        geometriasDuplicadasRed.geometry = `{"type":"FeatureCollection","features":[${geometriesB.map(
          (str) => JSON.stringify(str)
        )}]}`;
        const queryDeleteRedDu = `DELETE FROM ${tableRed} WHERE gid IN (${gidsx.join(
          ','
        )});`;
        // TODO DELETE
        await getQuery(pool, queryDeleteRedDu, []);
        validacion.redesDuplicadas = 0;
      } else {
        validacion.redesDuplicadas = 1;
      }
    }

    /*----------------------------ETAPA 1-----------------------------*/
    const sobreposicion_mz = {
      lista: [],
      mz_a: null,
      mz_b: null,
      interseccion: [],
    };

    const sobreposicion_red_mz = {
      lista: [],
      mz: null,
      red: null,
      interseccion: [],
    };

    const validar_categoria_red = {
      lista: [],
      gids: null,
    };

    const mz_contenedoras = {
      contenida: null,
      create_contenida: false,
      lista: [],
      mz_contenedora: null,
      mz_contenidas: null,
    };

    if (et == 1) {
      /*----------------------------Comprobar sobreposicion en mz-reseccionamiento-----------------------------*/
      const queryOverlapGeometry = `SELECT a.gid as gid_a, b.gid as gid_b, a.manzana as manzana_a, b.manzana as manzana_b, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') AS geom_a, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom') AS geom_b, ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326)) as intersection FROM (SELECT the_geom, gid, manzana FROM ${tableMzReseccionamiento}) AS a, (SELECT the_geom, gid, manzana FROM ${tableMzReseccionamiento}) AS b WHERE a.gid != b.gid AND a.gid < b.gid AND (ST_Overlaps(a.the_geom,b.the_geom) OR (ST_Intersects(a.the_geom, st_buffer(b.the_geom, -0.000001)) AND ((ST_Contains(a.the_geom, st_buffer(b.the_geom, -0.000001)) AND b.manzana = 9999) OR (ST_Contains(b.the_geom, st_buffer(a.the_geom, -0.000001)) AND a.manzana = 9999)))) AND NOT(a.the_geom = b.the_geom) ORDER BY a.gid, b.gid;`;
      const resOverlapGeometry = await getQuery(pool, queryOverlapGeometry);

      const geometrias_mz_a = [];
      const geometrias_mz_b = [];
      const geometrias_interseccion = [];
      const intersecciones = [];

      resOverlapGeometry.rows.forEach((row) => {
        const gid_a = row.gid_a;
        const mz_a = row.manzana_a;
        const mz_b = row.manzana_b;
        const geometria_a = row.geom_a;
        const geometria_b = row.geom_b;
        const geometria_interseccion = row.intersection;
        if (!intersecciones[gid_a]) {
          intersecciones[gid_a] = {
            gid: [],
            mz: [],
            mz_interseccion: [],
          };
        }
        if (!geometrias_mz_a.includes(geometria_a)) {
          geometrias_mz_a.push(geometria_a);
          intersecciones[gid_a].gid = gid_a;
          intersecciones[gid_a].mz = mz_a;
          intersecciones[gid_a].mz_interseccion.push(mz_b);
        } else {
          intersecciones[gid_a].mz_interseccion.push(mz_b);
        }

        if (!geometrias_mz_b.includes(geometria_b)) {
          geometrias_mz_b.push(geometria_b);
        }

        if (!geometrias_interseccion.includes(geometria_interseccion)) {
          geometrias_interseccion.push(geometria_interseccion);
        }
      });

      if (resOverlapGeometry.rowCount > 0) {
        intersecciones.forEach((inter) => {
          sobreposicion_mz.lista.push({
            gid: inter.gid,
            manzana: inter.mz,
            contenidas: inter.mz_interseccion.join(', '),
          });
        });
        sobreposicion_mz.mz_a = `{"type":"FeatureCollection","features":[${geometrias_mz_a.map(
          (str) => JSON.stringify(str)
        )}]}`;
        sobreposicion_mz.mz_b = `{"type":"FeatureCollection","features":[${geometrias_mz_b.map(
          (str) => JSON.stringify(str)
        )}]}`;
        sobreposicion_mz.interseccion = `{"type":"FeatureCollection","features":[${geometrias_interseccion.map(
          (str) => JSON.stringify(str)
        )}]}`;
        validacion.sobreposicionMz = 0;
      } else {
        validacion.sobreposicionMz = 1;
      }

      /*----------------------------Comprobar sobreposicion red sobre mz-reseccionamiento-----------------------------*/

      const queryOverlapGeometryRedMz = `
        SELECT
            a.gid as gid_a,
            b.gid as gid_b,
            b.manzana as manzana,
            jsonb_build_object(
                'type',
                'Feature',
                'geometry',
                ST_AsGeoJSON(ST_Transform(a.the_geom, 4326)) :: jsonb,
                'properties',
                to_jsonb(a.*) - 'the_geom'
            ) AS geom_a,
            jsonb_build_object(
                'type',
                'Feature',
                'geometry',
                ST_AsGeoJSON(ST_Transform(b.the_geom, 4326)) :: jsonb,
                'properties',
                to_jsonb(b.*) - 'the_geom'
            ) AS geom_b,
            jsonb_build_object(
                'type',
                'Feature',
                'geometry',
                ST_AsGeoJSON(
                    ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326)
                ) :: jsonb,
                'properties',
                to_jsonb(a.*) - 'the_geom'
            ) as intersection
        FROM
            (
                SELECT
                    the_geom,
                    id,
                    gid,
                    categoria
                FROM
                    ${tableRed}
            ) AS a,
            (
                SELECT
                    ST_Buffer(the_geom, -0.00001) AS the_geom,
                    gid,
                    manzana
                FROM
                    ${tableMzReseccionamiento}
            ) AS b
        WHERE
            ST_Overlaps(a.the_geom, b.the_geom)
            OR ST_Crosses(a.the_geom, b.the_geom)
            OR ST_Intersects(a.the_geom, b.the_geom)
        ORDER BY
            manzana;       
      `;
      const resOverlapGeometryRedMz = await getQuery(
        pool,
        queryOverlapGeometryRedMz
      );

      const geometrias_red = [];
      const geometrias_mz = [];
      const geometrias_interseccion_mz_red = [];
      const intersecciones_mz_red = [];

      resOverlapGeometryRedMz.rows.forEach((row) => {
        const gid_red = row.gid_a;
        const manzana = row.manzana;
        const red = row.geom_a;
        const mz = row.geom_b;
        const interseccion = row.intersection;

        if (!intersecciones_mz_red[gid_red]) {
          intersecciones_mz_red[gid_red] = {
            gid: [],
            mz_intersecciones: [],
          };
        }

        if (!geometrias_red.includes(red)) {
          intersecciones_mz_red[gid_red].gid = gid_red;
          intersecciones_mz_red[gid_red].mz_intersecciones = [manzana];
          geometrias_red.push(red);
        } else {
          intersecciones_mz_red[gid_red].mz_intersecciones.push(manzana);
        }
        if (!geometrias_mz.includes(mz)) {
          geometrias_mz.push(mz);
        }
        if (!geometrias_interseccion_mz_red.includes(interseccion)) {
          geometrias_interseccion_mz_red.push(interseccion);
        }
      });

      if (resOverlapGeometryRedMz.rowCount > 0) {
        intersecciones_mz_red.forEach((inter) => {
          sobreposicion_red_mz.lista.push({
            gid: inter.gid,
            repetidos: inter.mz_intersecciones.join(', '),
          });
        });

        sobreposicion_red_mz.red = `{"type":"FeatureCollection","features":[${geometrias_red.map(
          (str) => JSON.stringify(str)
        )}]}`;
        sobreposicion_red_mz.mz = `{"type":"FeatureCollection","features":[${geometrias_mz.map(
          (str) => JSON.stringify(str)
        )}]}`;
        sobreposicion_red_mz.interseccion = `{"type":"FeatureCollection","features":[${geometrias_interseccion.map(
          (str) => JSON.stringify(str)
        )}]}`;
        validacion.sobreposicionRedSobreMz = 0;
      } else {
        validacion.sobreposicionRedSobreMz = 1;
      }
      /*----------------------------Comprobar categoria en red-----------------------------*/
      const queryCheckGeometryCompCatRed = `
        SELECT
            gid,
            categoria
        FROM
            ${tableRed}
        WHERE
            categoria NOT IN (1, 2, 3, 5, 8);
      `;

      const resCheckGeometryCompCatRed = await getQuery(
        pool,
        queryCheckGeometryCompCatRed
      );

      const gidsccr = [];

      resCheckGeometryCompCatRed.rows.forEach((row) => {
        validar_categoria_red.lista.push({
          red: row.gid,
          categoria: row.categoria,
        });
        gidsccr.push(row.gid);
      });
      validar_categoria_red.gids = gidsccr;
      if (resCheckGeometryCompCatRed.rowCount > 0) {
        validacion.categoriaRed = 0;
      } else {
        validacion.categoriaRed = 1;
      }
      /*----------------------------Comprobar manzanas contenedoras-----------------------------*/
      const queryOverlapGeometryMzConten = `
          SELECT
              ST_Contains(a.the_geom, st_buffer(b.the_geom, -0.000001)) as a_c_b,
              ST_Contains(b.the_geom, st_buffer(a.the_geom, -0.000001)) as b_c_a,
              a.gid as gid_a,
              b.gid as gid_b,
              a.manzana as manzana_a,
              b.manzana as manzana_b,
              jsonb_build_object(
                  'type',
                  'Feature',
                  'geometry',
                  ST_AsGeoJSON(ST_Transform(a.the_geom, 4326)) :: jsonb,
                  'properties',
                  to_jsonb(a.*) - 'the_geom'
              ) AS geom_a,
              jsonb_build_object(
                  'type',
                  'Feature',
                  'geometry',
                  ST_AsGeoJSON(ST_Transform(b.the_geom, 4326)) :: jsonb,
                  'properties',
                  to_jsonb(b.*) - 'the_geom'
              ) AS geom_b,
              ST_AsGeoJSON(
                  ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326)
              ) as intersection
          FROM
              (
                  SELECT
                      the_geom,
                      gid,
                      manzana
                  FROM
                      ${tableMzReseccionamiento}
              ) AS a,
              (
                  SELECT
                      the_geom,
                      gid,
                      manzana
                  FROM
                      ${tableMzReseccionamiento}
              ) AS b
          WHERE
              a.gid != b.gid
              AND a.gid < b.gid
              AND ST_Intersects(a.the_geom, st_buffer(b.the_geom, -0.000001))
              AND NOT(a.the_geom = b.the_geom)
              AND (
                  (
                      ST_Contains(a.the_geom, st_buffer(b.the_geom, -0.000001))
                      AND b.manzana != 9999
                  )
                  OR (
                      ST_Contains(b.the_geom, st_buffer(a.the_geom, -0.000001))
                      AND a.manzana != 9999
                  )
              )
          ORDER BY
              a.gid,
              b.gid;
      `;

      const resOverlapGeometryMzConten = await getQuery(
        pool,
        queryOverlapGeometryMzConten
      );

      const geometrias_mz_a_conten = [];
      const geometrias_mz_b_conten = [];
      const manzanasZ = [];

      const queryNotExistsContenida = `
        SELECT
          NOT EXISTS(
              SELECT
                  column_name
              FROM
                  information_schema.columns
              WHERE
                  table_schema = '$schema_temp'
                  and table_name = 'mz_reseccionamiento$seccion_'
                  and column_name = 'contenida'
          ) as contenida_exists
      `;
      const resNotExistsContenida = await getQuery(
        pool,
        queryNotExistsContenida
      );

      const notExistsContenida = resNotExistsContenida.rows[0].contenida_exists;

      mz_contenedoras.contenida = notExistsContenida == 't';

      if (notExistsContenida === 't') {
        const queryAddContenida = `
        ALTER TABLE
            ${tableMzReseccionamiento}
        ADD
            COLUMN contenida SMALLINT DEFAULT 0;
        `;
        await getQuery(pool, queryAddContenida);
        mz_contenedoras.create_contenida = true;
      }

      const queryUpdateContenida0 = `
      UPDATE
          ${tableMzReseccionamiento}
      SET
          contenida = 0
      `;

      await getQuery(pool, queryUpdateContenida0);

      resOverlapGeometryMzConten.rows.forEach((row) => {
        let queryUpdateContenedora;
        let gid_a = null;
        let manzana_a;
        let gid_b;
        let manzana_b;
        let geometria_a;
        let geometria_b;
        const acb = row.a_c_b;
        if (acb) {
          gid_a = row.gid_a;
          manzana_a = row.manzana_a;
          gid_b = row.gid_b;
          manzana_b = row.manzana_b;
          geometria_a = row.geom_a;
          geometria_b = row.geom_b;

          queryUpdateContenedora = `
          UPDATE
              ${tableMzReseccionamiento}
          SET
              contenida = 1
          WHERE
              gid = ${gid_b}
          `;
        } else {
          gid_a = row.gid_b;
          manzana_a = row.manzana_b;
          gid_b = row.gid_a;
          manzana_b = row.manzana_a;
          geometria_a = row.geom_b;
          geometria_b = row.geom_a;
          queryUpdateContenedora = `
          UPDATE
              ${tableMzReseccionamiento}
          SET
              contenida = 1
          WHERE
              gid = ${gid_b}
          `;
        }

        // getQuery(pool, queryUpdateContenedora);
        if (!geometrias_mz_a_conten.includes(geometria_a)) {
          if (!manzanasZ[gid_a]) {
            manzanasZ[gid_a] = {
              gid: gid_a,
              manzana: manzana_a,
              contenidas: [],
            };
          }
          manzanasZ[gid_a].contenidas.push(manzana_b);
          geometrias_mz_a_conten.push(geometria_a);
        } else {
          manzanasZ[gid_a].contenidas.push(manzana_b);
        }

        if (!geometrias_mz_b_conten.includes(geometria_b)) {
          geometrias_mz_b_conten.push(geometria_b);
        }
      });

      if (resOverlapGeometryMzConten.rowCount > 0) {
        manzanasZ.forEach((manzana) => {
          mz_contenedoras.lista.push({
            gid: manzana.gid,
            manzanas: manzana.manzana,
            contenidas: manzana.contenidas.join(', '),
          });
        });

        mz_contenedoras.mz_contenedora = `{"type":"FeatureCollection","features":[${geometrias_mz_a_conten.map(
          (str) => JSON.stringify(str)
        )}]}`;
        mz_contenedoras.mz_contenidas = `{"type":"FeatureCollection","features":[${geometrias_mz_b_conten.map(
          (str) => JSON.stringify(str)
        )}]}`;
      }

      //**********************************  ---Validacion---- ************************************/
      const pool2 = getConn('reseccionamientoBitacora');

      //validamos si ya estan las banderas en true
      const verificarTodo = (objeto) => {
        for (let key in objeto) {
          if (
            Object.prototype.hasOwnProperty.call(objeto, key) &&
            key !== 'stamp' &&
            key !== 'user'
          ) {
            if (objeto[key] !== 1) {
              return false;
            }
          }
        }
        return true;
      };

      const attended_one = verificarTodo(validacion);
      const current_date_val = new Date().toLocaleString('es-MX', {
        timeZone: 'America/Mexico_City',
      });

      validacion.stamp = current_date_val;
      const queryValidacionEtapaUno = `
      UPDATE
          public.reporte2024
      SET
          attended_one = $1,
          logbook_one = COALESCE(logbook_one, '[]' :: jsonb) || $2 :: jsonb,
          current_date_val = $3
      WHERE
          id=$4
      `;

      await getQuery(pool2, queryValidacionEtapaUno, [
        attended_one,
        JSON.stringify(validacion),
        current_date_val,
        id,
      ]);
    }

    res
      .setHeader(
        'Strict-Transport-Security',
        'max-age=31536000; includeSubDomains; preload'
      )
      .json({
        code: '02',
        data: {
          validarGeometriaRed,
          validarGeometriaRedInvalidas,
          validarGeometriaMz,
          nodosDuplicadosRed,
          geometriasDuplicadasRed,
          sobreposicion_mz,
          sobreposicion_red_mz,
          validar_categoria_red,
          mz_contenedoras,
        },
      });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
