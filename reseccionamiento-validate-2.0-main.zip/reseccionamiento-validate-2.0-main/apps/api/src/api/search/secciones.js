const { getConn, getQuery } = require('./../../services/sql');
const { validateParams, handleError } = require('./../../services/common');
const { logger } = require('firebase-functions');

const pool = getConn('reseccionamiento2024');

exports.getSearchSecciones = async (req, res) => {
  logger.info(`getSearchSecciones ${req.originalUrl}`);
  try {
    const response = await validateParams(req, {
      body: 'query',
      methods: ['get'],
      optional: ['e', 'd'],
    });
    if (!response.status) {
      return handleError(req, res, response.message);
    }
    //* validamos entidad
    if (req.query.e) {
      if (isNaN(req.query.e)) {
        return handleError(req, res, '-entidad- debe ser un número');
      }
      const entidad = parseInt(req.query.e);
      if (!(entidad > 0 && entidad <= 32)) {
        return handleError(req, res, '-entidad- debe ser un valor de 1 a 32');
      }
      req.query.e = parseInt(req.query.e);
    }
    //* validamos distrito
    if (req.query.d) {
      if (isNaN(req.query.d)) {
        return handleError(req, res, '-distrito- debe ser un número');
      }
      const distrito = parseInt(req.query.d);
      if (!(distrito >= 1 && distrito <= 300)) {
        return handleError(req, res, '-distrito- debe ser un valor de 1 a 300');
      }
      req.query.d = parseInt(req.query.d);
    }
    const entidad = Number(req.query.e);
    const distrito = Number(req.query.d);
    const query = `
    SELECT seccion FROM public.secciones WHERE entidad=$1 AND distrito=$2 ORDER BY seccion
  `;
    const resSecciones = await getQuery(pool, query, [entidad, distrito]);
    if (resSecciones.rowCount <= 0) {
      return res
        .setHeader(
          'Strict-Transport-Security',
          'max-age=31536000; includeSubDomains; preload'
        )
        .json({ code: '02', data: [] });
    }
    const secciones = [];
    resSecciones.rows.forEach((row) => {
      secciones.push(row.seccion);
    });
    res
      .setHeader(
        'Strict-Transport-Security',
        'max-age=31536000; includeSubDomains; preload'
      )
      .json({ code: '02', data: secciones });
  } catch (error) {
    return handleError(req, res, 'Error server');
  }
};
