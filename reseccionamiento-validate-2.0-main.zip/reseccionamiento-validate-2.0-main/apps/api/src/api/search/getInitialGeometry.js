const { getConn, getQuery } = require('./../../services/sql');
const { validateParams, handleError } = require('./../../services/common');
const { logger } = require('firebase-functions');

const pool = getConn('reseccionamiento2024');

exports.getInitialGeometry = async (req, res) => {
  logger.info(`getInitialGeometry ${req.originalUrl}`);
  try {
    const response = await validateParams(req, {
      body: 'query',
      methods: ['get'],
      optional: ['e', 'd', 's'],
    });
    if (!response.status) {
      return handleError(req, res, response.message);
    }
    //* validamos entidad
    if (req.query.e !== undefined && req.query.e !== null) {
      if (isNaN(req.query.e)) {
        return handleError(req, res, '-entidad- debe ser un número');
      }
      const entidad = parseInt(req.query.e);
      if (!(entidad > 0 && entidad <= 32)) {
        return handleError(req, res, '-entidad- debe ser un valor de 1 a 32');
      }
      req.query.e = parseInt(req.query.e);
    } else {
      return handleError(
        req,
        res,
        '-entidad- es null o indefinido y debe ser un número'
      );
    }
    //* validamos distrito
    if (req.query.d !== undefined && req.query.d !== null) {
      if (isNaN(req.query.d)) {
        return handleError(req, res, '-distrito- debe ser un número');
      }
      const distrito = parseInt(req.query.d);
      if (!(distrito >= 1 && distrito <= 300)) {
        return handleError(req, res, '-distrito- debe ser un valor de 1 a 300');
      }
      req.query.d = parseInt(req.query.d);
    } else {
      return handleError(
        req,
        res,
        '-distrito- es null o indefinido y debe ser un número'
      );
    }

    //* validamos seccion
    if (req.query.s !== undefined && req.query.s !== null) {
      if (isNaN(req.query.s)) {
        return handleError(req, res, '-seccion- debe ser un número');
      }
      if (req.query.s.length > 4) {
        return handleError(req, res, '-seccion- debe contener hasta 4 cifras');
      }
      const seccion = parseInt(req.query.s);
      if (!(seccion > 0)) {
        return handleError(req, res, '-seccion- debe ser un valor mayor a 0');
      }
      req.query.s = parseInt(req.query.s);
    } else {
      return handleError(
        req,
        res,
        '-sección- es null o indefinido y debe ser un número'
      );
    }
    const e = Number(req.query.e);
    const d = Number(req.query.d);
    const se = Number(req.query.s);
    let s = Number(req.query.s);
    let entidad = req.query.e.toString().length === 1 ? '0' + e : e;
    let distrito = req.query.d.toString().length === 1 ? '0' + d : d;
    let seccion;
    s = parseInt(s, 10);
    if (s < 10) {
      seccion = '000' + s;
    } else if (s < 100) {
      seccion = '00' + s;
    } else if (s < 1000) {
      seccion = '0' + s;
    } else {
      seccion = s;
    }
    //* variables schemas
    const schema = `${entidad}dto${distrito}`;
    const tableSeccion = `"${schema}"."seccion${seccion}"`;
    const tableRed = `"${schema}"."red${seccion}"`;
    const tableMzReseccionamiento = `"${schema}"."mz_reseccionamiento${seccion}"`;
    const tableEscuela = `"${schema}"."escuela${seccion}"`;
    //*Query geomSection
    const query = `
    SELECT row_to_json(fc) AS secciones_json FROM 
    ( SELECT 'FeatureCollection' AS type, array_to_json(array_agg(f)) AS features FROM 
    (SELECT 'Feature' AS type, ST_AsGeoJSON(ST_Transform( lg.the_geom, 4326 ))::json AS geometry, row_to_json((SELECT l FROM (SELECT gid ) AS l)) 
    AS properties FROM ${tableSeccion} AS lg 
    WHERE lg.entidad = $1 AND lg.distrito = $2 AND lg.seccion = $3) AS f )  AS fc;
    `;
    const values = [e, d, se];
    const resGeomSection = await getQuery(pool, query, values);

    //*Query geomRed
    const queryRed = `
    SELECT row_to_json(fc) AS red_json FROM 
    ( SELECT 'FeatureCollection' AS type, array_to_json(array_agg(f)) AS features FROM 
    (SELECT 'Feature' AS type, ST_AsGeoJSON(ST_Transform( lg.the_geom, 4326 ))::json AS geometry, row_to_json((SELECT l FROM (SELECT gid ) AS l)) AS properties 
    FROM ${tableRed} AS lg 
    WHERE lg.entidad = $1 AND lg.distrito = $2 AND lg.seccion = $3) AS f )  AS fc;
    `;
    const resGeomRed = await getQuery(pool, queryRed, values);

    //*Query geomMz
    const queryMz = `
    SELECT row_to_json(fc) AS mz_json FROM 
    ( SELECT 'FeatureCollection' AS type, array_to_json(array_agg(f)) AS features FROM 
    (SELECT 'Feature' AS type, ST_AsGeoJSON(ST_Transform( lg.the_geom, 4326 ))::json AS geometry, row_to_json((SELECT l FROM (SELECT gid, manzana ) AS l)) 
    AS properties FROM ${tableMzReseccionamiento} AS lg 
    WHERE lg.entidad = $1 AND lg.distrito = $2 AND lg.seccion = $3) AS f )  AS fc;
    `;
    const resGeomMz = await getQuery(pool, queryMz, values);

    //*Query pointServices
    const querySchools = `
    SELECT row_to_json(fc) AS escuela_json FROM 
    ( SELECT 'FeatureCollection' AS type, array_to_json(array_agg(f)) AS features FROM 
    (SELECT 'Feature' AS type, ST_AsGeoJSON(ST_Transform( lg.the_geom, 4326 ))::json AS geometry, row_to_json((SELECT l FROM (SELECT gid, tipo ) AS l)) 
    AS properties FROM ${tableEscuela} AS lg 
    WHERE lg.entidad = $1 AND lg.distrito = $2 AND lg.seccion = $3) AS f )  AS fc;
    `;

    const resGeomSchools = await getQuery(pool, querySchools, values);
    const resultsGeoms = {
      geomSeccion: resGeomSection.rows[0],
      geomRed: resGeomRed.rows[0],
      geomMz: resGeomMz.rows[0],
      geomSchools: resGeomSchools.rows[0],
    };
    res
      .setHeader(
        'Strict-Transport-Security',
        'max-age=31536000; includeSubDomains; preload'
      )
      .json({ code: '02', data: resultsGeoms });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
