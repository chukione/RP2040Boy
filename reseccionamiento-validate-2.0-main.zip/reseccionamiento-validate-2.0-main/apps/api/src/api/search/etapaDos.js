const { getConn, getQuery } = require('../../services/sql');
const { validateParams, handleError } = require('../../services/common');
const { logger } = require('firebase-functions');

const pool = getConn('reseccionamiento2024');

exports.etapaDos = async (req, res) => {
  logger.info(`etapaDos ${req.originalUrl}`);
  try {
    const response = await validateParams(req, {
      body: 'query',
      methods: ['get'],
      optional: ['e', 'd', 's', 'et'],
    });
    if (!response.status) {
      return handleError(req, res, response.message);
    }
    //* validamos entidad
    if (req.query.e !== undefined && req.query.e !== null) {
      if (isNaN(req.query.e)) {
        return handleError(req, res, '-entidad- debe ser un número');
      }
      const entidad = parseInt(req.query.e);
      if (!(entidad > 0 && entidad <= 32)) {
        return handleError(req, res, '-entidad- debe ser un valor de 1 a 32');
      }
      req.query.e = parseInt(req.query.e);
    } else {
      return handleError(
        req,
        res,
        '-entidad- es null o indefinido y debe ser un número'
      );
    }
    //* validamos distrito
    if (req.query.d !== undefined && req.query.d !== null) {
      if (isNaN(req.query.d)) {
        return handleError(req, res, '-distrito- debe ser un número');
      }
      const distrito = parseInt(req.query.d);
      if (!(distrito >= 1 && distrito <= 300)) {
        return handleError(req, res, '-distrito- debe ser un valor de 1 a 300');
      }
      req.query.d = parseInt(req.query.d);
    } else {
      return handleError(
        req,
        res,
        '-distrito- es null o indefinido y debe ser un número'
      );
    }

    //* validamos seccion
    if (req.query.s !== undefined && req.query.s !== null) {
      if (isNaN(req.query.s)) {
        return handleError(req, res, '-seccion- debe ser un número');
      }
      if (req.query.s.length > 4) {
        return handleError(req, res, '-seccion- debe contener hasta 4 cifras');
      }
      const seccion = parseInt(req.query.s);
      if (!(seccion > 0)) {
        return handleError(req, res, '-seccion- debe ser un valor mayor a 0');
      }
      req.query.s = parseInt(req.query.s);
    } else {
      return handleError(
        req,
        res,
        '-sección- es null o indefinido y debe ser un número'
      );
    }
    //* validamos distrito
    if (req.query.et !== undefined && req.query.et !== null) {
      if (isNaN(req.query.et)) {
        return handleError(req, res, '-etapa- debe ser un número');
      }
      const etapa = parseInt(req.query.et);
      if (!(etapa >= 1 && etapa <= 3)) {
        return handleError(req, res, '-etapa- debe ser un valor de 1 a 3');
      }
      req.query.et = parseInt(req.query.et);
    } else {
      return handleError(
        req,
        res,
        '-eatapa- es null o indefinido y debe ser un número'
      );
    }
    const e = Number(req.query.e);
    const d = Number(req.query.d);
    // const se = Number(req.query.s);
    const user = String(req.query.user);
    let s = Number(req.query.s);
    let entidad = req.query.e.toString().length === 1 ? '0' + e : e;
    let distrito = req.query.d.toString().length === 1 ? '0' + d : d;
    let seccion;
    s = parseInt(s, 10);
    if (s < 10) {
      seccion = '000' + s;
    } else if (s < 100) {
      seccion = '00' + s;
    } else if (s < 1000) {
      seccion = '0' + s;
    } else {
      seccion = s;
    }

    // creamos id para update validacion
    const id = `${entidad}${distrito}${seccion}`;
    //* variables schemas
    const schema = `${entidad}dto${distrito}`;
    const tableRed = `"${schema}"."red${seccion}"`;
    const tableMzReseccionamiento = `"${schema}"."mz_reseccionamiento${seccion}"`;
    const tablePoligonosRed = `"${schema}"."poligonos_red${seccion}"`;

    const validacion = {
      stamp: null,
      user,
      geometriaRedNull: 0,
      geometriaRedInvalidas: 0,
      geometriaMz: 0,
      nodosDuplicadosRed: 0,
      redesDuplicadas: 0, //hasta aqui son las globales
      validarGeometriaRed: 0,
      validarGeometriaRedInvalidas: 0,
      validarGeometriaMz: 0,
      geometriasDuplicadasRed: 0,
      geometriasDuplicadasMzResecc: 0,
      sobreposicionGeom: 0,
      validarMzaSinPoligonos: 0,
      validarMzaInterPoligonos: 0,
      validarPoligonosMza: 0,
      validarPoligonosSinMza: 0,
      validarMzasOtrosDatos: 0,
      validarMzasDuplicadas: 0,
      validarMzasNulas: 0,
    };

    // Cambiar geom a "the_geom"
    const queryFlatFieldGeometry = `SELECT CASE WHEN EXISTS ( SELECT 1
    FROM information_schema.columns
    WHERE table_schema = '${schema}' AND table_name = 'poligonos_red${seccion}' AND column_name = 'the_geom') THEN 1 
    WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = '${schema}' 
    AND table_name = 'poligonos_red${seccion}' AND column_name = 'geom') THEN 2 ELSE 3 END AS resultado;`;
    const resFlatFieldGeometry = await getQuery(
      pool,
      queryFlatFieldGeometry,
      []
    );
    if (resFlatFieldGeometry.rowCount > 0) {
      const flatNameGeom = resFlatFieldGeometry.rows[0].resultado;
      if (flatNameGeom === 2) {
        // TODO: Agregar query para cambiar nombre
        const queryRenameGeom = `ALTER TABLE ${tablePoligonosRed} RENAME COLUMN geom TO the_geom;`;
        await getQuery(pool, queryRenameGeom, []);
      }
    }

    // const schemaTemp = `${entidad}.dto.${distrito}`;

    //* Comprobar geometria en la capa red
    const validarGeometriaRed = [];
    // const validarGeometriaRedDelete = [];
    const queryCheckGeometry = `SELECT the_geom, gid FROM ${tableRed} WHERE NOT ST_isValid(the_geom) OR ST_Length(the_geom) = 0 OR the_geom IS NULL;`;
    const resValidateRed = await getQuery(pool, queryCheckGeometry, []);
    if (resValidateRed.rowCount > 0) {
      resValidateRed.rows.forEach((row) => {
        validarGeometriaRed.push({ the_geom: row.the_geom, gid: row.gid });
        // validarGeometriaRedDelete.push(row.gid);
      });
      // const queryDeleteGeomRed = `DELETE FROM ${tableRed} WHERE gid IN (${validarGeometriaRedDelete.join(
      //   ','
      // )});`;
      // await getQuery(pool, queryDeleteGeomRed, []);
      // TODO geomRed invalidas > 0
      //* $validacion['geometria_red'] = 0
      validacion.validarGeometriaRed = 0;
    } else {
      validacion.validarGeometriaRed = 1;
    }

    // Comprobar geometría invalidas capa red
    const validarGeometriaRedInvalidas = {
      lista: [],
      geometry: null,
    };

    const queryCheckGeometryInvalidas = `SELECT gid, ST_AsGeoJSON(the_geom) AS geom FROM ${tableRed} WHERE ST_IsSimple(the_geom) = 'f' OR ST_MinimumClearance(the_geom) <0.00000000001;`;
    const resValidateRedInvalid = await getQuery(
      pool,
      queryCheckGeometryInvalidas,
      []
    );
    if (resValidateRedInvalid.rowCount > 0) {
      const features = [];
      const lista = [];

      resValidateRedInvalid.rows.forEach((row) => {
        const geometry = JSON.parse(row.geom);
        geometry.properties = { gid: row.gid };
        features.push(geometry);
        lista.push({ gid: row.gid, geom: row.geom });
      });

      const featureCollection = {
        type: 'FeatureCollection',
        features: features,
      };

      validarGeometriaRedInvalidas.invalidas = resValidateRedInvalid.rowCount;
      validarGeometriaRedInvalidas.geometry = JSON.stringify(featureCollection);
      validarGeometriaRedInvalidas.lista = lista;
      validacion.validarGeometriaRedInvalidas = 0;
    } else {
      validacion.validarGeometriaRedInvalidas = 1;
    }
    /// Termina geom invalidas

    //* Comprobar nodos duplicados en la capa red
    const nodosDuplicadosRed = {
      nodos: [],
      total: 0,
      nodosDuplicados: [],
      lines: [],
    };
    // const queryDuplicateNodes = `SELECT jsonb_build_object('type','Feature','geometry',
    // ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb,'properties', '{}'::jsonb) AS the_geom,
    // gid, COUNT(*) FROM (SELECT (ST_Dump(ST_Points(the_geom))).geom as the_geom, gid FROM ${tableRed} as red
    // WHERE red.gid NOT IN (SELECT gid FROM ${tableRed} WHERE ST_RemoveRepeatedPoints(the_geom) = the_geom)) AS g GROUP BY the_geom, gid HAVING COUNT(*) > 1;`;
    const queryDuplicateNodes = `SELECT jsonb_build_object('type','Feature','geometry',
    ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb,'properties', '{}'::jsonb) AS the_geom,
    gid, COUNT(*) FROM (SELECT (ST_Dump(ST_Points(the_geom))).geom as the_geom, gid FROM ${tableRed} as red 
    WHERE red.gid NOT IN (SELECT gid FROM ${tableRed} WHERE ST_RemoveRepeatedPoints(the_geom) = the_geom)) 
	AS g GROUP BY the_geom, gid HAVING COUNT(*) > 1;`;
    const resDuplicatedNodes = await getQuery(pool, queryDuplicateNodes, []);
    if (resDuplicatedNodes.rowCount > 0) {
      nodosDuplicadosRed.total = resDuplicatedNodes.rowCount;
      const gids = [];
      const geometries = [];
      const gidOrdenados = [];
      resDuplicatedNodes.rows.forEach((row) => {
        const gid = row.gid;
        const geometry = row.the_geom;
        if (!geometries.includes(geometry)) {
          geometries.push(geometry);
        }
        if (!gids.includes(gid)) {
          gids.push(gid);
          gidOrdenados[gid] = { gid: gid, contador: 1 };
        } else {
          gidOrdenados[gid].contador++;
        }
      });
      if (gids.length > 0) {
        gidOrdenados.forEach((gidx) => {
          nodosDuplicadosRed.nodosDuplicados.push({
            gid: gidx.gid,
            contador: gidx.contador,
          });
        });

        nodosDuplicadosRed.nodos = `{"type":"FeatureCollection","features":[${geometries.map(
          (str) => JSON.stringify(str)
        )}]}`;
        const sqlRepair = `UPDATE ${tableRed} SET the_geom = ST_RemoveRepeatedPoints(the_geom) WHERE gid IN (${gids.join(
          ','
        )});`;
        await getQuery(pool, sqlRepair, []);
        const sqlLines = `SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb, 
        'properties', to_jsonb(r.*) - 'the_geom') AS the_geom FROM ${tableRed} as r WHERE gid IN (${gids.join(
          ','
        )});`;
        const resLines = await getQuery(pool, sqlLines, []);
        const geometriesLines = [];
        if (resLines.rowCount > 0) {
          resLines.rows.forEach((row) => {
            geometriesLines.push(row.the_geom);
          });
          nodosDuplicadosRed.lines = `{"type":"FeatureCollection","features":[${geometriesLines.map(
            (str) => JSON.stringify(str)
          )}]}`;
        }
        // TODO validation
        // $validacion['nodos_duplicados_red'] = 0;
        validacion.nodosDuplicadosRed = 0;
      }
    } else {
      // TODO validation
      // $validacion['nodos_duplicados_red'] = 1;
      validacion.nodosDuplicadosRed = 1;
    }

    //* Comprobar geometrias red duplicadas y eliminar
    const geometriasDuplicadasRed = {
      lista: [],
      duplicados: 0,
      geometry: null,
    };
    // const queryDuplicateGeometries = `SELECT gid, r.the_geom as the_geom, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb,
    // 'properties', to_jsonb(r.*) - 'the_geom') AS the_geom_b FROM ( SELECT the_geom FROM ${tableRed} WHERE NOT(NOT ST_isValid(the_geom)
    // OR ST_Length(the_geom) = 0 OR the_geom IS NULL) GROUP BY the_geom HAVING COUNT(*) > 1) as g, ${tableRed} as r WHERE g.the_geom = r.the_geom;`;
    const queryDuplicateGeometries = `SELECT b.gid, b.the_geom, ST_AsGeoJSON(b.*)::jsonb as the_geom_b FROM ${tableRed} AS a, ${tableRed} AS b WHERE ST_Equals(a.the_geom, b.the_geom) AND a.gid <> b.gid;`;
    const resDuplicateGeom = await getQuery(pool, queryDuplicateGeometries, []);
    if (resDuplicateGeom.rowCount > 0) {
      const gidsx = [];
      const geometriesx = [];
      const geometriesB = [];
      const gidOrdenadosx = [];
      resDuplicateGeom.rows.forEach((row) => {
        const gidx = row.gid;
        const geometryx = row.the_geom;
        const geometryB = row.the_geom_b;
        if (geometriesx.includes(geometryx)) {
          gidOrdenadosx[geometryx].repetidos.push(gidx);
          gidsx.push(gidx);
        } else {
          gidOrdenadosx[geometryx] = {
            gid: gidx,
            repetidos: [],
          };
          geometriesx.push(geometryx);
          geometriesB.push(geometryB);
        }
      });
      if (gidsx.length > 0) {
        geometriasDuplicadasRed.duplicados = geometriesx.length;
        for (let geometryk in gidOrdenadosx) {
          geometriasDuplicadasRed.lista.push({
            gid: gidOrdenadosx[geometryk].gid,
            repetidos: gidOrdenadosx[geometryk].repetidos,
          });
        }
        geometriasDuplicadasRed.geometry = `{"type":"FeatureCollection","features":[${geometriesB.map(
          (str) => JSON.stringify(str)
        )}]}`;
        // const queryDeleteRedDu = `DELETE FROM ${tableRed} WHERE gid IN (${gidsx.join(
        //   ','
        // )});`;
        // await getQuery(pool, queryDeleteRedDu, []);
        // TODO validation
        //* $validacion['redes_duplicadas'] = 0;
        validacion.geometriasDuplicadasRed = 0;
      }
    } else {
      //* $validacion['redes_duplicadas'] = 1
      validacion.geometriasDuplicadasRed = 1;
    }
    // TODO etapa 2
    // if ( et === 2 )

    //* Comprobar geometria mz-reseccionamiento
    const validarGeometriaMz = { invalidas: [], nulas: [] };
    const queryCheckGeomMz = `SELECT manzana, gid FROM ${tableMzReseccionamiento} WHERE NOT ST_isValid(the_geom);`;
    const resMzNotValid = await getQuery(pool, queryCheckGeomMz, []);
    // TODO 1 geomMz
    //* $validacion['geometria_mz'] = 1
    if (resMzNotValid.rowCount > 0) {
      resMzNotValid.rows.forEach((row) => {
        validarGeometriaMz.invalidas.push({
          gid: row.gid,
          manzana: row.manzana ? row.manzana : null,
        });
      });
      validacion.validarGeometriaMz = 0;
    } else {
      //* $validacion['redes_duplicadas'] = 1
      validacion.validarGeometriaMz = 1;
    }
    const queryGeomMzNull = `SELECT manzana, gid FROM ${tableMzReseccionamiento} WHERE ST_Area(the_geom) = 0 OR ST_Perimeter(the_geom) = 0 OR the_geom IS NULL;`;
    const resMzNull = await getQuery(pool, queryGeomMzNull, []);
    const deleteMzNulls = [];
    if (resMzNull.rowCount > 0) {
      resMzNull.rows.forEach((row) => {
        validarGeometriaMz.nulas.push({
          gid: row.gid,
          manzana: row.manzana ? row.manzana : null,
        });
        // deleteMzNulls.push(row.gid);
      });
      validacion.validarGeometriaMz = 0;
    } else {
      //* $validacion['redes_duplicadas'] = 1
      validacion.validarGeometriaMz = 1;
    }
    if (
      validarGeometriaMz.nulas.length > 0 ||
      validarGeometriaMz.invalidas.length > 0
    ) {
      // TODO 1 geomMz
      //* $validacion['geometria_mz'] = 0
    }
    if (deleteMzNulls.length > 0) {
      const queryDeleteMzNull = `DELETE FROM ${tableMzReseccionamiento} WHERE gid IN (${deleteMzNulls.join(
        ','
      )});`;
      await getQuery(pool, queryDeleteMzNull, []);
    }

    //* Comprobar geometrias MZReseccionamiento duplicadas
    const geometriasDuplicadasMzResecc = {
      lista: [],
      duplicados: 0,
      geometry: null,
    };
    const queryDuplicateGeometriesMz = `SELECT b.gid, b.the_geom, ST_AsGeoJSON(b.*)::jsonb as the_geom_b FROM ${tableMzReseccionamiento} AS a, ${tableMzReseccionamiento} AS b WHERE ST_Equals(a.the_geom, b.the_geom) AND a.gid <> b.gid;`;
    const resDuplicateGeomMz = await getQuery(
      pool,
      queryDuplicateGeometriesMz,
      []
    );
    if (resDuplicateGeomMz.rowCount > 0) {
      const gidsx = [];
      const geometriesx = [];
      const geometriesB = [];
      const gidOrdenadosx = [];
      resDuplicateGeomMz.rows.forEach((row) => {
        const gidx = row.gid;
        const geometryx = row.the_geom;
        const geometryB = row.the_geom_b;
        if (geometriesx.includes(geometryx)) {
          gidOrdenadosx[geometryx].repetidos.push(gidx);
          gidsx.push(gidx);
        } else {
          gidOrdenadosx[geometryx] = {
            gid: gidx,
            repetidos: [],
          };
          geometriesx.push(geometryx);
          geometriesB.push(geometryB);
        }
      });
      if (gidsx.length > 0) {
        geometriasDuplicadasMzResecc.duplicados = geometriesx.length;
        for (let geometryk in gidOrdenadosx) {
          geometriasDuplicadasMzResecc.lista.push({
            gid: gidOrdenadosx[geometryk].gid,
            repetidos: gidOrdenadosx[geometryk].repetidos,
          });
        }
        geometriasDuplicadasMzResecc.geometry = `{"type":"FeatureCollection","features":[${geometriesB.map(
          (str) => JSON.stringify(str)
        )}]}`;
        // const queryDeleteRedDu = `DELETE FROM ${tableRed} WHERE gid IN (${gidsx.join(
        //   ','
        // )});`;
        // await getQuery(pool, queryDeleteRedDu, []);
        // TODO validation
        //* $validacion['redes_duplicadas'] = 0;
        validacion.geometriasDuplicadasMzResecc = 0;
      }
    } else {
      //* $validacion['redes_duplicadas'] = 1;
      validacion.geometriasDuplicadasMzResecc = 1;
    }
    // TODO etapa 2

    // Sobreposicíon RED
    //* Comprobar sobreposicion
    const sobreposicionGeom = {
      lista: [],
      sobreposicion: 0,
      geometry: null, // Inicialmente null, la configuraremos más adelante
    };

    const querySobreposicionGeometries = `WITH a AS (
      SELECT the_geom, gid, id FROM ${tableRed}),
      b AS (SELECT the_geom, gid, id FROM ${tableRed})
      SELECT a.gid as gid_a,
      b.gid as gid_b,
      jsonb_build_object(
        'type', 'Feature',
        'geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb,
        'properties', to_jsonb(a.*) - 'the_geom'
      ) as geom_a,
      jsonb_build_object(
        'type', 'Feature',
        'geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb,
        'properties', to_jsonb(b.*) - 'the_geom'
      ) as geom_b,
      CASE
        WHEN ST_IsEmpty(ST_Intersection(a.the_geom, b.the_geom)) THEN NULL
        ELSE jsonb_build_object(
          'type', 'Feature',
          'geometry', ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326))::jsonb,
          'properties', jsonb_build_object('gid_a', a.gid, 'gid_b', b.gid)
        )
      END as intersection
      FROM
        a, b
      WHERE
        a.gid != b.gid
        AND a.gid < b.gid
        AND (
          ST_Overlaps(a.the_geom, b.the_geom)
          OR ST_Contains(b.the_geom, a.the_geom)
          OR ST_Contains(a.the_geom, b.the_geom)
        )
      ORDER BY
        gid_a, gid_b;`;
    const resSobreposicionGeom = await getQuery(
      pool,
      querySobreposicionGeometries,
      []
    );

    if (resSobreposicionGeom.rowCount > 0) {
      const gidOrdenadosx = {}; // Para almacenar los gids con sus repetidos
      const features = []; // Lista de todas las features para la geometría

      resSobreposicionGeom.rows.forEach((row) => {
        const gidxA = row.gid_a;
        const gidxB = row.gid_b;
        const geometryA = row.geom_a;
        const geometryB = row.geom_b;
        const intersection = row.intersection; // La geometría de intersección

        if (geometryA && geometryB) {
          // Agregar todas las geometrías detectadas
          if (intersection) {
            features.push(intersection); // Agregar directamente a la lista de features
          }

          if (gidOrdenadosx[gidxA]) {
            gidOrdenadosx[gidxA].repetidos.push(gidxB);
          } else {
            gidOrdenadosx[gidxA] = {
              gid: gidxA,
              repetidos: [gidxB],
            };
          }
        }
      });

      // Construir la lista final de geometrías duplicadas
      for (let geometryKey in gidOrdenadosx) {
        sobreposicionGeom.lista.push({
          gid: gidOrdenadosx[geometryKey].gid,
          repetidos: gidOrdenadosx[geometryKey].repetidos,
        });
      }

      sobreposicionGeom.sobreposicion = sobreposicionGeom.lista.length;

      // Convertir la colección de geometrías a cadena con formato JSON
      sobreposicionGeom.geometry = JSON.stringify({
        type: 'FeatureCollection',
        features: features,
      });
      validacion.sobreposicionGeom = 0;
    } else {
      validacion.sobreposicionGeom = 1;
    }
    //FIN

    // Manzanas sin polígono
    const validarMzaSinPoligonos = {
      lista: [],
      geometry: null,
    };
    const queryMzaSinPoligonos = `SELECT gid, manzana, ST_AsGeoJSON(mz.*)::jsonb AS geom, the_geom 
    FROM ${tableMzReseccionamiento} AS mz WHERE NOT EXISTS (
    SELECT 1 
    FROM ${tablePoligonosRed} a
    JOIN ${tableMzReseccionamiento} b ON ST_Contains(a.the_geom, ST_Buffer(b.the_geom, -0.00001))
    WHERE b.manzana = mz.manzana);`;
    const resValidateMza = await getQuery(pool, queryMzaSinPoligonos, []);
    if (resValidateMza.rowCount > 0) {
      const features = [];
      const lista = [];

      resValidateMza.rows.forEach((row) => {
        const geometry = row.geom;
        geometry.properties = { gid: row.gid };
        features.push(geometry);
        lista.push({
          gid: row.gid,
          // geom: row.geom,
          manzana: row.manzana ? row.manzana : null,
        });
      });

      const featureCollection = {
        type: 'FeatureCollection',
        features: features,
      };

      validarMzaSinPoligonos.invalidas = resValidateMza.rowCount;
      validarMzaSinPoligonos.geometry = JSON.stringify(featureCollection);
      validarMzaSinPoligonos.lista = lista;
      validacion.validarMzaSinPoligonos = 0;
    } else {
      validacion.validarMzaSinPoligonos = 1;
    }
    // Termina manzana sin poligono

    // Manzanas que intersectan con poligonos
    const validarMzaInterPoligonos = {
      lista: [],
      geometry: null,
    };
    const queryMzaInterPoligonos = `SELECT DISTINCT mz.gid, mz.manzana, ST_AsGeoJSON(mz.*)::jsonb AS geom, mz.the_geom
    FROM ${tableMzReseccionamiento} AS mz
    JOIN ${tablePoligonosRed} AS pol ON ST_Intersects(mz.the_geom, pol.the_geom)
    WHERE NOT ST_Contains(pol.the_geom, mz.the_geom);`;
    const resValidateMzaInterPoligonos = await getQuery(
      pool,
      queryMzaInterPoligonos,
      []
    );
    if (resValidateMzaInterPoligonos.rowCount > 0) {
      const features = [];
      const lista = [];

      resValidateMzaInterPoligonos.rows.forEach((row) => {
        const geometry = row.geom;
        geometry.properties = { gid: row.gid };
        features.push(geometry);
        lista.push({
          gid: row.gid,
          // geom: row.geom,
          manzana: row.manzana ? row.manzana : null,
        });
      });

      const featureCollection = {
        type: 'FeatureCollection',
        features: features,
      };

      validarMzaInterPoligonos.invalidas = resValidateMza.rowCount;
      validarMzaInterPoligonos.geometry = JSON.stringify(featureCollection);
      validarMzaInterPoligonos.lista = lista;
      validacion.validarMzaInterPoligonos = 0;
    } else {
      validacion.validarMzaInterPoligonos = 1;
    }
    // Termina manzana que intersectan con poligonos

    // POLIGONOS CON MAS DE UNA MANZANA
    const validarPoligonosMza = {
      lista: [],
      geometry: null,
    };
    const queryPoligonosMza = `SELECT count(*), subquery.gid as gid, jsonb_build_object('type', 'Feature','geometry', ST_AsGeoJSON(ST_Transform(subquery.a_the_geom, 4326))::jsonb,'properties',
    CONCAT('{"gid":', subquery.gid, '}')::jsonb) as geom, subquery.a_the_geom as the_geom FROM (SELECT a.the_geom as a_the_geom, a.gid FROM ${tablePoligonosRed} 
    AS a, (SELECT ST_Buffer(the_geom, -0.00001) as the_geom, gid, manzana FROM ${tableMzReseccionamiento}) AS b WHERE ST_Contains(a.the_geom, b.the_geom)) AS subquery 
    GROUP BY subquery.a_the_geom, subquery.gid HAVING COUNT(*) > 1;`;
    const resValidatePoligonosMza = await getQuery(pool, queryPoligonosMza, []);
    if (resValidatePoligonosMza.rowCount > 0) {
      const features = [];
      const lista = [];

      resValidatePoligonosMza.rows.forEach((row) => {
        const geometry = row.geom;
        geometry.properties = { gid: row.gid };
        features.push(geometry);
        lista.push({
          gid: row.gid,
          // geom: row.geom,
          count: row.count ? row.count : null,
        });
      });

      const featureCollection = {
        type: 'FeatureCollection',
        features: features,
      };

      validarPoligonosMza.invalidas = resValidateMza.rowCount;
      validarPoligonosMza.geometry = JSON.stringify(featureCollection);
      validarPoligonosMza.lista = lista;
      validacion.validarPoligonosMza = 0;
    } else {
      validacion.validarPoligonosMza = 1;
    }
    // Termina POLIGONOS CON MAS DE UNA MANZANA

    // POLIGONOS SIN MANZANA
    const validarPoligonosSinMza = {
      lista: [],
      geometry: null,
    };
    const queryPoligonosSinMza = `SELECT gid, the_geom, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb, 'properties', to_jsonb(pr.*) - 'the_geom')
    AS geom FROM ${tablePoligonosRed} AS pr WHERE gid NOT IN (SELECT a.gid FROM (SELECT the_geom, gid FROM ${tablePoligonosRed}) AS a,
    (SELECT ST_Buffer(the_geom, -0.00001) as the_geom, gid, manzana
    FROM ${tableMzReseccionamiento}) AS b WHERE ST_Contains(a.the_geom, b.the_geom));`;
    const resValidatePoligonosSinMza = await getQuery(
      pool,
      queryPoligonosSinMza,
      []
    );
    if (resValidatePoligonosSinMza.rowCount > 0) {
      const features = [];
      const lista = [];

      resValidatePoligonosSinMza.rows.forEach((row) => {
        const geometry = row.geom;
        geometry.properties = { gid: row.gid };
        features.push(geometry);
        lista.push({
          gid: row.gid,
        });
      });

      const featureCollection = {
        type: 'FeatureCollection',
        features: features,
      };

      validarPoligonosSinMza.invalidas = resValidateMza.rowCount;
      validarPoligonosSinMza.geometry = JSON.stringify(featureCollection);
      validarPoligonosSinMza.lista = lista;
      validacion.validarPoligonosMza = 0;
    } else {
      validacion.validarPoligonosMza = 1;
    }
    // Termina POLIGONOS SIN MANZANA

    // Manzanas con otros datos
    const validarMzasOtrosDatos = [];
    const queryMzasOtrosDatos = `SELECT gid, entidad, distrito, seccion FROM ${tableMzReseccionamiento}
    WHERE gid < 0 OR entidad <> CAST(SUBSTRING('${tableMzReseccionamiento}', 2, 2) AS INTEGER)
    OR distrito <> CAST(SUBSTRING('${tableMzReseccionamiento}', 7, 2) AS INTEGER)
    OR seccion <> CAST(SUBSTRING('${tableMzReseccionamiento}', LENGTH('${tableMzReseccionamiento}') - 4, 4) AS INTEGER);`;
    const resValidateMzasOtrosDato = await getQuery(
      pool,
      queryMzasOtrosDatos,
      []
    );
    if (resValidateMzasOtrosDato.rowCount > 0) {
      // Procesar los resultados y almacenarlos en validarMzasOtrosDatos
      resValidateMzasOtrosDato.rows.forEach((row) => {
        validarMzasOtrosDatos.push({
          gid: row.gid,
          entidad: row.entidad,
          distrito: row.distrito,
          seccion: row.seccion,
        });
      });
      validacion.validarMzasOtrosDatos = 0;
    } else {
      validacion.validarMzasOtrosDatos = 1;
    }
    // Termina Manzanas con otros datos

    // Manzanas con datos nulos
    const validarMzasNulas = [];
    const queryMzasNulas = `select gid, entidad, distrito, seccion, municipio, localidad, manzana 	
    from ${tableMzReseccionamiento} where entidad is null or distrito is null or seccion is null or municipio is null or
    localidad is null or manzana is null`;
    const resValidateMzasNulas = await getQuery(pool, queryMzasNulas, []);
    if (resValidateMzasNulas.rowCount > 0) {
      resValidateMzasNulas.rows.forEach((row) => {
        // Verificar que localidad no sea 0 antes de agregarlo
        if (row.localidad === null || row.localidad !== 0) {
          validarMzasNulas.push({
            gid: row.gid,
            entidad: row.entidad,
            distrito: row.distrito,
            seccion: row.seccion,
            municipio: row.municipio,
            localidad: row.localidad,
            manzana: row.manzana,
          });
        }
      });

      // Verificar si alguna localidad es 0 en los resultados obtenidos
      const localidadInvalida = validarMzasNulas.some(
        (item) => item.localidad === 0
      );
      validacion.validarMzasNulas = localidadInvalida ? 1 : 0;
    } else {
      validacion.validarMzasNulas = 1; // No se pintará la tabla si no hay resultados
    }
    // Termina Manzanas con datos nulos

    // Manzanas con datos duplicados
    const validarMzasDuplicadas = [];
    const queryMzasDuplicadas = `SELECT entidad, distrito, municipio, seccion, localidad, manzana, STRING_AGG(gid::text, ', ') AS gids
    FROM ${tableMzReseccionamiento} WHERE (entidad, distrito, municipio, seccion, localidad, manzana) IN (
    SELECT entidad, distrito, municipio, seccion, localidad, manzana
    FROM ${tableMzReseccionamiento} GROUP BY entidad, distrito, municipio, seccion, localidad, manzana HAVING COUNT(*) > 1)
    GROUP BY entidad, distrito, municipio, seccion, localidad, manzana;`;

    const resValidateMzasDuplicadas = await getQuery(
      pool,
      queryMzasDuplicadas,
      []
    );
    if (resValidateMzasDuplicadas.rowCount > 0) {
      // Procesar los resultados y almacenarlos en validarMzasDuplicadas
      resValidateMzasDuplicadas.rows.forEach((row) => {
        validarMzasDuplicadas.push({
          entidad: row.entidad,
          distrito: row.distrito,
          municipio: row.municipio,
          seccion: row.seccion,
          localidad: row.localidad,
          manzana: row.manzana,
          gids: row.gids,
        });
      });
      validacion.validarMzasDuplicadas = 0;
    } else {
      validacion.validarMzasDuplicadas = 1;
    }
    // Termina Manzanas con datos duplicados

    //**********************************  ---Validacion---- ************************************/
    const pool2 = getConn('reseccionamientoBitacora');

    //validamos si ya estan las banderas en true
    const verificarTodo = (objeto) => {
      for (let key in objeto) {
        if (
          Object.prototype.hasOwnProperty.call(objeto, key) &&
          key !== 'stamp' &&
          key !== 'user'
        ) {
          if (objeto[key] !== 1) {
            return false;
          }
        }
      }
      return true;
    };

    const attended_two = verificarTodo(validacion);
    const current_date_val = new Date().toLocaleString('es-MX', {
      timeZone: 'America/Mexico_City',
    });

    validacion.stamp = current_date_val;
    const queryValidacionEtapaDos = `
         UPDATE
              public.reporte2024
          SET
              attended_two = $1,
              logbook_two = COALESCE(logbook_two::jsonb, '[]'::jsonb) || $2::jsonb,
              current_date_val = $3
          WHERE
              id = $4;
          `;

    await getQuery(pool2, queryValidacionEtapaDos, [
      attended_two,
      JSON.stringify(validacion),
      current_date_val,
      id,
    ]);

    res
      .setHeader(
        'Strict-Transport-Security',
        'max-age=31536000; includeSubDomains; preload'
      )
      .json({
        code: '02',
        data: {
          validarGeometriaRed,
          validarGeometriaRedInvalidas,
          validarGeometriaMz,
          nodosDuplicadosRed,
          geometriasDuplicadasRed,
          geometriasDuplicadasMzResecc,
          sobreposicionGeom,
          validarMzaSinPoligonos,
          validarMzaInterPoligonos,
          validarPoligonosMza,
          validarPoligonosSinMza,
          validarMzasOtrosDatos,
          validarMzasDuplicadas,
          validarMzasNulas,
        },
      });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
