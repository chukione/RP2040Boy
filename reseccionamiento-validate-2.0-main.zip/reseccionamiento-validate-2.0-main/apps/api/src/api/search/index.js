const express = require('express');
const searchAPI = express();
const { getSearchGoverment } = require('./entidades');
const { getSearchDistrito } = require('./distritos');
const { getSearchSecciones } = require('./secciones');
const { getInitialGeometry } = require('./getInitialGeometry');
const { validateStagePoligonos } = require('./ValidaPoligonos');
const { etapaUno } = require('./etapaUno');
const { etapaDos } = require('./etapaDos');
const { etapaTres } = require('./etapaTres');

searchAPI.get('/entidades', getSearchGoverment);
searchAPI.get('/distritos', getSearchDistrito);
searchAPI.get('/secciones', getSearchSecciones);
searchAPI.get('/initialGeom', getInitialGeometry);
searchAPI.get('/validateStage', validateStagePoligonos);
searchAPI.get('/etapaUno', etapaUno);
searchAPI.get('/etapaDos', etapaDos);
searchAPI.get('/etapaTres', etapaTres);

searchAPI.all('*', (req, res) => {
  res
    .setHeader(
      'Strict-Transport-Security',
      'max-age=31536000; includeSubDomains; preload'
    )
    .status(404)
    .json({
      message: 'API Validación - Reseccionamiento: Recurso no encontrado',
    });
});

exports.searchAPI = searchAPI;
