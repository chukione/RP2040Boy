const { getConn, getQuery } = require('../../services/sql');
const { validateParams, handleError } = require('../../services/common');
const { logger } = require('firebase-functions');

const pool = getConn('reseccionamiento2024');

exports.etapaTres = async (req, res) => {
  logger.info(`etapaTres ${req.originalUrl}`);
  try {
    const response = await validateParams(req, {
      body: 'query',
      methods: ['get'],
      optional: ['e', 'd', 's', 'et'],
    });
    if (!response.status) {
      return handleError(req, res, response.message);
    }

    // Validación de parámetros
    const validateNumber = (param, name, min, max) => {
      if (param === undefined || param === null || isNaN(param)) {
        throw new Error(`-${name}- debe ser un número`);
      }
      const number = parseInt(param);
      if (!(number >= min && number <= max)) {
        throw new Error(`-${name}- debe ser un valor de ${min} a ${max}`);
      }
      return number;
    };

    try {
      req.query.e = validateNumber(req.query.e, 'entidad', 1, 32);
      req.query.d = validateNumber(req.query.d, 'distrito', 1, 300);
      req.query.s = validateNumber(req.query.s, 'sección', 1, 9999);
      req.query.et = validateNumber(req.query.et, 'etapa', 1, 3);
    } catch (error) {
      return handleError(req, res, error.message);
    }

    const e = Number(req.query.e);
    const d = Number(req.query.d);
    const et = Number(req.query.et);
    const user = String(req.query.user);
    const s = Number(req.query.s);
    // creamos id para update validacion
    const entidad = req.query.e.toString().length === 1 ? '0' + e : e;
    const distrito = req.query.d.toString().length === 1 ? '0' + d : d;
    const seccion = s.toString().padStart(4, '0');
    const id = `${entidad}${distrito}${seccion}`;
    const schema = `${entidad}dto${distrito}`;
    const tableRed = `"${schema}".red${seccion}`;
    const tableMzReseccionamiento = `"${schema}".mz_reseccionamiento${seccion}`;
    const tableMzComparacion = `"${schema}".mz_comparacion${seccion}`;
    const tableEscuela = `"${schema}".escuela${seccion}`;
    const tablePolRedInterMz = `pol_red_inter_mz${seccion}`;

    let aux;

    let validacion = {
      stamp: null,
      user,
      geometriaRedNull: 0,
      geometriaRedInvalidas: 0,
      geometriaMz: 0,
      nodosDuplicadosRed: 0,
      redesDuplicadas: 0, //hasta aqui son las globales
      existeTablaPolRed: 0,
      existeTablaPolRedCampoGeom: 0,
      totales: 0,
      sobreposicionPolRed: 0,
      sobreposicionRedSobrePolRed: 0,
      existeTablaPolRedCampoPoligono: 0,
      fraccionamientos: 0, //pendiente
      nulosEscuela: 0, //Para abajo bien
      duplicatedManzanas: 0,
      mzReseccionamientoFaltantes: 0,
      mzPolRedFaltantes: 0,
      manzanasAlteradas: 0,
      manzanasAlteradasPol: 0,
      manzanaAlteradaGeometria: 0,
      manzanaAlteradaGeometriaPol: 0,
    };

    const executeQuery = async (query, params = []) => {
      try {
        return await getQuery(pool, query, params);
      } catch (error) {
        logger.error(`Error executing query: ${query}`, error);
        throw error;
      }
    };

    const validarGeometriaRed = [];
    const validarGeometriaRedDelete = [];
    try {
      const queryCheckGeometry = `SELECT the_geom, gid FROM ${tableRed} WHERE NOT ST_isValid(the_geom) OR ST_Length(the_geom) = 0 OR the_geom IS NULL;`;
      const resValidateRed = await executeQuery(queryCheckGeometry);
      if (resValidateRed.rowCount > 0) {
        resValidateRed.rows.forEach((row) => {
          validarGeometriaRed.push({ the_geom: row.the_geom, gid: row.gid });
          validarGeometriaRedDelete.push(row.gid);
        });
        const queryDeleteGeomRed = `DELETE FROM ${tableRed} WHERE gid IN (${validarGeometriaRedDelete.join(
          ','
        )});`;
        await executeQuery(queryDeleteGeomRed);
      }
      validacion.geometriaRedNull = 0;
    } catch (error) {
      logger.error('Error validating geometries in red layer', error);
    }
    validacion.geometriaRedNull = 1;

    const validarGeometriaRedInvalidas = { lista: [], geometry: null };
    try {
      const queryCheckGeometryInvalidas = `SELECT gid, ST_AsGeoJSON(the_geom) AS geom FROM ${tableRed} WHERE ST_IsSimple(the_geom) = 'f' OR ST_MinimumClearance(the_geom) <0.00000000001;`;
      const resValidateRedInvalid = await executeQuery(
        queryCheckGeometryInvalidas
      );
      if (resValidateRedInvalid.rowCount > 0) {
        const features = [];
        const lista = [];
        resValidateRedInvalid.rows.forEach((row) => {
          const geometry = JSON.parse(row.geom);
          geometry.properties = { gid: row.gid };
          features.push(geometry);
          lista.push({ gid: row.gid, geom: row.geom });
        });
        const featureCollection = {
          type: 'FeatureCollection',
          features: features,
        };
        validarGeometriaRedInvalidas.invalidas = resValidateRedInvalid.rowCount;
        validarGeometriaRedInvalidas.geometry =
          JSON.stringify(featureCollection);
        validarGeometriaRedInvalidas.lista = lista;
        validacion.geometriaRedInvalidas = 0;
      } else {
        validacion.geometriaRedInvalidas = 1;
      }
    } catch (error) {
      logger.error('Error validating invalid geometries in red layer', error);
    }

    const validarGeometriaMz = { invalidas: [], nulas: [] };
    try {
      const queryCheckGeomMz = `SELECT manzana, gid FROM ${tableMzReseccionamiento} WHERE NOT ST_isValid(the_geom);`;
      const resMzNotValid = await executeQuery(queryCheckGeomMz);
      validacion.geometriaMz = 1;
      if (resMzNotValid.rowCount > 0) {
        resMzNotValid.rows.forEach((row) => {
          validarGeometriaMz.invalidas.push({
            gid: row.gid,
            manzana: row.manzana ? row.manzana : null,
          });
        });
      }
    } catch (error) {
      logger.error(
        'Error validating geometries in mz reseccionamiento layer',
        error
      );
    }

    try {
      const queryGeomMzNull = `SELECT manzana, gid FROM ${tableMzReseccionamiento} WHERE ST_Area(the_geom) = 0 OR ST_Perimeter(the_geom) = 0 OR the_geom IS NULL;`;
      const resMzNull = await executeQuery(queryGeomMzNull);
      const deleteMzNulls = [];
      if (resMzNull.rowCount > 0) {
        resMzNull.rows.forEach((row) => {
          validarGeometriaMz.nulas.push({
            gid: row.gid,
            manzana: row.manzana ? row.manzana : null,
          });
          deleteMzNulls.push(row.gid);
        });
      }
      if (deleteMzNulls.length > 0) {
        validacion.geometriaMz = 0;
        const queryDeleteMzNull = `DELETE FROM ${tableMzReseccionamiento} WHERE gid IN (${deleteMzNulls.join(
          ','
        )});`;
        await executeQuery(queryDeleteMzNull);
      }
    } catch (error) {
      logger.error(
        'Error validating null geometries in mz reseccionamiento layer',
        error
      );
    }

    const nodosDuplicadosRed = {
      nodos: [],
      total: 0,
      nodosDuplicados: [],
      lines: [],
    };
    try {
      const queryDuplicateNodes = `SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb,'properties', '{}'::jsonb) AS the_geom, gid, COUNT(*) FROM (SELECT (ST_Dump(ST_Points(the_geom))).geom as the_geom, gid FROM ${tableRed} as red WHERE red.gid NOT IN (SELECT gid FROM ${tableRed} WHERE ST_RemoveRepeatedPoints(the_geom) = the_geom)) AS g GROUP BY the_geom, gid HAVING COUNT(*) > 1;`;
      const resDuplicatedNodes = await executeQuery(queryDuplicateNodes);
      if (resDuplicatedNodes.rowCount > 0) {
        validacion.nodosDuplicadosRed = 0;
        nodosDuplicadosRed.total = resDuplicatedNodes.rowCount;
        const gids = [];
        const geometries = [];
        const gidOrdenados = [];
        resDuplicatedNodes.rows.forEach((row) => {
          const gid = row.gid;
          const geometry = row.the_geom;
          if (!geometries.includes(geometry)) {
            geometries.push(geometry);
          }
          if (!gids.includes(gid)) {
            gids.push(gid);
            gidOrdenados[gid] = { gid: gid, contador: 1 };
          } else {
            gidOrdenados[gid].contador++;
          }
        });
        if (gids.length > 0) {
          gidOrdenados.forEach((gidx) => {
            nodosDuplicadosRed.nodosDuplicados.push({
              gid: gidx.gid,
              contador: gidx.contador,
            });
          });
          nodosDuplicadosRed.nodos = `{"type":"FeatureCollection","features":[${geometries.map(
            (str) => JSON.stringify(str)
          )}]}`;
          const sqlRepair = `UPDATE ${tableRed} SET the_geom = ST_RemoveRepeatedPoints(the_geom) WHERE gid IN (${gids.join(
            ','
          )});`;
          await executeQuery(sqlRepair);
          const sqlLines = `SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb, 'properties', to_jsonb(r.*) - 'the_geom') AS the_geom FROM ${tableRed} as r WHERE gid IN (${gids.join(
            ','
          )});`;
          const resLines = await executeQuery(sqlLines);
          const geometriesLines = [];
          if (resLines.rowCount > 0) {
            resLines.rows.forEach((row) => {
              geometriesLines.push(row.the_geom);
            });
            nodosDuplicadosRed.lines = `{"type":"FeatureCollection","features":[${geometriesLines.map(
              (str) => JSON.stringify(str)
            )}]}`;
          }
        }
      } else {
        validacion.nodosDuplicadosRed = 1;
      }
    } catch (error) {
      logger.error('Error validating duplicate nodes in red layer', error);
    }

    const geometriasDuplicadasRed = {
      lista: [],
      duplicados: 0,
      geometry: null,
    };
    try {
      const queryDuplicateGeometries = `SELECT b.gid, b.the_geom, ST_AsGeoJSON(b.*)::jsonb as the_geom_b FROM ${tableRed} AS a, ${tableRed} AS b WHERE ST_Equals(a.the_geom, b.the_geom) AND a.gid <> b.gid;`;
      const resDuplicateGeom = await executeQuery(queryDuplicateGeometries);
      if (resDuplicateGeom.rowCount > 0) {
        validacion.redesDuplicadas = 0;
        const gidsx = [];
        const geometriesx = [];
        const geometriesB = [];
        const gidOrdenadosx = [];
        resDuplicateGeom.rows.forEach((row) => {
          const gidx = row.gid;
          const geometryx = row.the_geom;
          const geometryB = row.the_geom_b;
          if (geometriesx.includes(geometryx)) {
            gidOrdenadosx[geometryx].repetidos.push(gidx);
            gidsx.push(gidx);
          } else {
            gidOrdenadosx[geometryx] = { gid: gidx, repetidos: [] };
            geometriesx.push(geometryx);
            geometriesB.push(geometryB);
          }
        });
        if (gidsx.length > 0) {
          geometriasDuplicadasRed.duplicados = geometriesx.length;
          for (let geometryk in gidOrdenadosx) {
            geometriasDuplicadasRed.lista.push({
              gid: gidOrdenadosx[geometryk].gid,
              repetidos: gidOrdenadosx[geometryk].repetidos,
            });
          }
          geometriasDuplicadasRed.geometry = `{"type":"FeatureCollection","features":[${geometriesB.map(
            (str) => JSON.stringify(str)
          )}]}`;
          const queryDeleteRedDu = `DELETE FROM ${tableRed} WHERE gid IN (${gidsx.join(
            ','
          )});`;
          // TODO DELETE
          //await executeQuery(queryDeleteRedDu);
        }
      } else {
        validacion.redesDuplicadas = 1;
      }
    } catch (error) {
      logger.error('Error validating duplicate geometries in red layer', error);
    }

    let comparacionTableMzComparacion = {
      manzanasAlteradas: null,
      manzanasAlteradasPol: null,
      manzanaAlteradaGeometria: null,
      manzanaAlteradaGeometriaPol: null,
    };

    if (et === 3) {
      let nulosEscuelaLista = [];
      let validacionNulosEscuela = 1;
      let verificaNombresPol = {
        table: false,
        the_geom: false,
        checkTheGeom: false,
      };

      let sobreposicionPolRed = { lista: [] };
      let sobreposicionRedPolRed = { lista: [] };
      let fraccionamientos = { lista: [] };
      let totalPolMzCumple = { cumple: 1, manzanas: [] };
      let sinRepetir = [];
      let manzanaPolRed = [];
      let badPoligonos = [];
      let polRedInterMz = { poligonosRed: null, redEscuelaServicios: null };

      let comparacionManzanas = {
        duplicatedManzanas: null,
        mzReseccionamientoFaltantes: null,
        mzPolRedFaltantes: null,
      };

      try {
        const queryCheckEscuela = `
          SELECT gid, entidad, distrito, seccion,
            (entidad != $1) AS entidad_distinto,
            (distrito != $2) AS distrito_distinto,
            (seccion != $3) AS seccion_distinto,
            (entidad IS NULL OR entidad = 0) AS val_entidad,
            (distrito IS NULL OR distrito = 0) AS val_distrito,
            (seccion IS NULL OR seccion = 0) AS val_seccion,
            (tipo IS NULL OR tipo = '') AS val_tipo,
            tipo NOT IN ('Escuela','Oficina gubernamental','Oficina municipal','Central de autobús','Centro comercial','Centro cultural','Centro recreativo','Instalaciones deportivas','Mercado','Plaza o Monumento') as val_tipo_cat,
            tipo
          FROM ${tableEscuela}
          WHERE (entidad IS NULL OR entidad = 0) 
            OR (distrito IS NULL OR distrito = 0) 
            OR (seccion IS NULL OR seccion = 0) 
            OR (tipo IS NULL OR tipo = '') 
            OR LOWER(tipo) NOT IN ('escuela','oficina gubernamental','oficina municipal','central de autobús','centro comercial','centro cultural','centro recreativo','instalaciones deportivas','mercado','plaza','monumento') 
            OR entidad != $1 
            OR distrito != $2 
            OR seccion != $3
          ORDER BY gid;
        `;
        const resultQueryEscuela = await executeQuery(queryCheckEscuela, [
          e,
          d,
          s,
        ]);
        nulosEscuelaLista = resultQueryEscuela.rows.map((row) => ({
          gid: parseInt(row.gid, 10),
          entidad: row.val_entidad ? 1 : row.entidad_distinto ? 1 : 0,
          distrito: row.val_distrito ? 1 : row.distrito_distinto ? 1 : 0,
          seccion: row.val_seccion ? 1 : row.seccion_distinto ? 1 : 0,
          detalleEntidad: parseInt(row.entidad, 10),
          detalleDistrito: parseInt(row.distrito, 10),
          detalleSeccion: parseInt(row.seccion, 10),
          tipo: row.val_tipo ? 1 : row.val_tipo_cat ? 1 : 0,
          detalleTipo: row.tipo,
        }));
        validacion.nulosEscuela = resultQueryEscuela.rowCount === 0 ? 1 : 0;
      } catch (error) {
        logger.error('Error validating null values in school layer', error);
      }

      try {
        const queryVerifyTablePol = `SELECT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = $1 AND table_name = $2) AS table_exists;`;
        const resultVerifyTablePol = await executeQuery(queryVerifyTablePol, [
          schema,
          tablePolRedInterMz,
        ]);
        const tableExists = resultVerifyTablePol.rows[0].table_exists;
        verificaNombresPol.table = tableExists;
        validacion.existeTablaPolRed = tableExists ? 1 : 0;
      } catch (error) {
        logger.error(
          'Error verifying existence of pol_red_inter_mz table',
          error
        );
      }

      if (verificaNombresPol.table) {
        try {
          const queryVerifyFieldTheGeom = `SELECT NOT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = $1 AND table_name = $2 AND column_name = 'the_geom') AS the_geom_exists;`;
          const resultVerifyFieldTheGeom = await executeQuery(
            queryVerifyFieldTheGeom,
            [schema, `pol_red_inter_mz${seccion}`]
          );
          const notExistsTheGeom =
            resultVerifyFieldTheGeom.rows[0].the_geom_exists;
          verificaNombresPol.the_geom = notExistsTheGeom;
          if (notExistsTheGeom) {
            const queryVerifyFieldGeom = `SELECT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = $1 AND table_name = $2 AND column_name = 'geom') AS geom_exists;`;
            const resultVerifyFieldGeom = await executeQuery(
              queryVerifyFieldGeom,
              [schema, `pol_red_inter_mz${seccion}`]
            );
            const existsGeom = resultVerifyFieldGeom.rows[0].geom_exists;
            if (existsGeom) {
              const queryRenameTheGeom = `ALTER TABLE "${schema}".${tablePolRedInterMz} RENAME COLUMN geom TO the_geom;`;
              await executeQuery(queryRenameTheGeom);
              verificaNombresPol.checkTheGeom = true;
              validacion.existeTablaPolRedCampoGeom = 1;
            } else {
              verificaNombresPol.checkTheGeom = false;
              validacion.existeTablaPolRedCampoGeom = 0;
            }
          } else {
            validacion.existeTablaPolRedCampoGeom = 1;
          }
        } catch (error) {
          logger.error(
            'Error verifying and renaming the_geom column in pol_red_inter_mz table',
            error
          );
        }

        try {
          const queryOverlapsGeometry = `
            SELECT a.gid as gid_a, b.gid as gid_b, a.manzana as manzana_a, b.manzana as manzana_b, 
              jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom' || jsonb_build_object('manzana', b.manzana)) as geom_a, 
              jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom' || jsonb_build_object('manzana', b.manzana)) as geom_b, 
              jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326))::jsonb, 'properties', jsonb_build_object('gid_a', a.gid, 'gid_b', b.gid, 'manzana', b.manzana)) as intersection 
            FROM (SELECT the_geom, gid, manzana FROM "${schema}".${tablePolRedInterMz}) AS a, (SELECT the_geom, gid, manzana FROM "${schema}".${tablePolRedInterMz}) AS b 
            WHERE a.manzana != b.manzana AND a.manzana < b.manzana AND (ST_Overlaps(a.the_geom, b.the_geom) OR ST_Contains(b.the_geom, a.the_geom) OR ST_Contains(a.the_geom, b.the_geom)) 
            ORDER BY a.manzana, b.manzana;
          `;
          const result = await executeQuery(queryOverlapsGeometry);
          const geometries_a = [];
          const geometries_b = [];
          const intersecciones = [];
          const intersecciones_repetidos = [];
          result.rows.forEach((row) => {
            const gid_a = parseInt(row.gid_a);
            const manzana_a = parseInt(row.manzana_a);
            const manzana_b = parseInt(row.manzana_b);
            const geom_a = row.geom_a;
            const geom_b = row.geom_b;
            const interseccion = row.intersection;
            if (!geometries_a.includes(geom_a)) {
              intersecciones_repetidos[gid_a] = {
                manzana: manzana_a,
                repetidos: [manzana_b],
              };
              geometries_a.push(geom_a);
            } else {
              intersecciones_repetidos[gid_a].push(manzana_b);
            }
            if (!geometries_b.includes(geom_b)) {
              geometries_b.push(geom_b);
            }
            if (!intersecciones.includes(interseccion)) {
              intersecciones.push(interseccion);
            }
          });
          if (result.rowCount > 0) {
            const interseccionesNoNulas = intersecciones_repetidos.filter(
              (inter) => inter !== null
            );
            let i = 0;
            for (const inter of interseccionesNoNulas) {
              sobreposicionPolRed.lista.push({
                i: i + 1,
                manzana: inter.manzana,
                repetidos: inter.repetidos.join(', '),
              });
              i++;
            }
            sobreposicionPolRed.geometries_a = {
              type: 'FeatureCollection',
              features: geometries_a,
            };
            sobreposicionPolRed.geometries_b = {
              type: 'FeatureCollection',
              features: geometries_b,
            };
            sobreposicionPolRed.intersecciones = {
              type: 'FeatureCollection',
              features: intersecciones,
            };
            validacion.sobreposicionPolRed = 0;
          } else {
            validacion.sobreposicionPolRed = 1;
          }
        } catch (error) {
          logger.error(
            'Error validating overlaps in pol_red_inter_mz layer',
            error
          );
        }

        try {
          const queryOverlapsRedPolRed = `
            SELECT a.categoria as categoria, a.gid as gid_a, b.gid as gid_b, b.manzana as manzana, 
              jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom' || jsonb_build_object('manzana', b.manzana)) as geom_a, 
              jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom' || jsonb_build_object('manzana', b.manzana)) as geom_b, 
              jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom' || jsonb_build_object('manzana', b.manzana)) as intersection 
            FROM (SELECT the_geom, id, gid, categoria FROM ${tableRed} WHERE categoria IN (1,5,8)) AS a, (SELECT ST_Buffer(the_geom, -0.000000001) AS the_geom, gid, manzana FROM "${schema}".${tablePolRedInterMz}) AS b 
            WHERE ST_Intersects(a.the_geom, b.the_geom) ORDER BY gid_a;
          `;
          const resultRedPolRed = await executeQuery(queryOverlapsRedPolRed);
          const geometries_a = [];
          const geometries_b = [];
          const intersecciones = [];
          const interseccion_repetidos = [];
          resultRedPolRed.rows.forEach((row) => {
            const gid_a = parseInt(row.gid_a);
            const manzana_b = parseInt(row.manzana);
            const geom_a = row.geom_a;
            const geom_b = row.geom_b;
            const interseccion = row.intersection;
            const categoria = parseInt(row.categoria);
            if (!geometries_a.includes(geom_a)) {
              interseccion_repetidos[gid_a] = {
                gid: gid_a,
                categoria: categoria,
                repetidos: [manzana_b],
              };
              geometries_a.push(geom_a);
            } else {
              interseccion_repetidos[gid_a].repetidos.push(manzana_b);
            }
            if (!geometries_b.includes(geom_b)) {
              geometries_b.push(geom_b);
            }
            if (!intersecciones.includes(interseccion)) {
              intersecciones.push(interseccion);
            }
          });
          if (resultRedPolRed.rowCount > 0) {
            const interseccionesNoNulas = interseccion_repetidos.filter(
              (inter) => inter !== null
            );
            let i = 0;
            for (const inter of interseccionesNoNulas) {
              sobreposicionRedPolRed.lista.push({
                i: i + 1,
                gid: inter.gid,
                categoria: inter.categoria,
                repetidos: inter.repetidos.join(', '),
              });
              i++;
            }
            sobreposicionRedPolRed.geometries_a = {
              type: 'FeatureCollection',
              features: geometries_a,
            };
            sobreposicionRedPolRed.geometries_b = {
              type: 'FeatureCollection',
              features: geometries_b,
            };
            sobreposicionRedPolRed.intersecciones = {
              type: 'FeatureCollection',
              features: intersecciones,
            };
            validacion.sobreposicionRedSobrePolRed = 0;
          } else {
            validacion.sobreposicionRedSobrePolRed = 1;
          }
        } catch (error) {
          logger.error(
            'Error validating overlaps between red and pol_red_inter_mz layers',
            error
          );
        }

        try {
          const queryDuplicadosPoligonos = `SELECT count(*), mz.localidad, mz.manzana FROM "${schema}".${tablePolRedInterMz} pol LEFT JOIN ${tableMzReseccionamiento} mz ON pol.localidad = mz.localidad AND pol.manzana = mz.manzana GROUP BY mz.localidad, mz.manzana HAVING count(*) > 1 ORDER BY mz.localidad, mz.manzana;`;
          const resultDuplicadosPoligonos = await executeQuery(
            queryDuplicadosPoligonos
          );
          if (resultDuplicadosPoligonos.rowCount > 0) {
            totalPolMzCumple.cumple = 0;
            totalPolMzCumple.tipo = 0;
            resultDuplicadosPoligonos.rows.forEach((row, i) => {
              totalPolMzCumple.manzanas.push({
                i: i + 1,
                localidad: row.localidad || 'null',
                manzana: row.manzana || 'null',
              });
            });
            validacion.totales = 0;
          }
        } catch (error) {
          logger.error(
            'Error validating duplicated polygons in pol_red_inter_mz layer',
            error
          );
        }

        try {
          const queryFaltaPoligonos = `SELECT mz.manzana, mz.localidad FROM "${schema}".${tablePolRedInterMz} pol RIGHT JOIN ${tableMzReseccionamiento} mz ON pol.localidad = mz.localidad AND pol.manzana = mz.manzana WHERE pol.localidad IS NULL ORDER BY mz.manzana;`;
          const resultFaltaPoligonos = await executeQuery(queryFaltaPoligonos);
          if (resultFaltaPoligonos.rowCount > 0) {
            totalPolMzCumple.cumple = 0;
            totalPolMzCumple.tipo = 1;
            resultFaltaPoligonos.rows.forEach((row, i) => {
              totalPolMzCumple.manzanas.push({
                i: i + 1,
                localidad: row.localidad || 'null',
                manzana: row.manzana || 'null',
              });
            });
            validacion.totales = 0;
          } else {
            const queryFaltaManzanas = `SELECT pol.manzana, pol.localidad FROM "${schema}".${tablePolRedInterMz} pol LEFT JOIN ${tableMzReseccionamiento} mz ON pol.localidad = mz.localidad AND pol.manzana = mz.manzana WHERE mz.localidad IS NULL ORDER BY pol.manzana;`;
            const resultFaltaManzanas = await executeQuery(queryFaltaManzanas);
            if (resultFaltaManzanas.rowCount > 0) {
              totalPolMzCumple.cumple = 0;
              totalPolMzCumple.tipo = 2;
              resultFaltaManzanas.rows.forEach((row, i) => {
                totalPolMzCumple.manzanas.push({
                  i: i + 1,
                  localidad: row.localidad || 'null',
                  manzana: row.manzana || 'null',
                });
              });
              validacion.totales = 0;
            }
          }
          validacion.totales = totalPolMzCumple.cumple;
        } catch (error) {
          logger.error(
            'Error validating missing polygons and manzanas in pol_red_inter_mz layer',
            error
          );
        }

        try {
          const queryVerifyFieldPoligono = `SELECT NOT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = $1 AND table_name = $2 AND column_name = 'poligono_') AS the_geom_exists;`;
          const resultVerifyFieldPoligono = await executeQuery(
            queryVerifyFieldPoligono,
            [schema, `pol_red_inter_mz${seccion}`]
          );
          const notExistsPoligono =
            resultVerifyFieldPoligono.rows[0].the_geom_exists;
          verificaNombresPol.poligono = notExistsPoligono;
          validacion.existeTablaPolRedCampoPoligono = notExistsPoligono ? 0 : 1;
        } catch (error) {
          logger.error(
            'Error verifying poligono_ field in pol_red_inter_mz layer',
            error
          );
        }

        try {
          const getPoligonos = `SELECT poligono_ AS poligono, COUNT(*) AS total FROM "${schema}".${tablePolRedInterMz} WHERE poligono_ IS NOT NULL GROUP BY poligono_ ORDER BY poligono_;`;
          const resultPoligonos = await executeQuery(getPoligonos);
          const poligonos = resultPoligonos.rows.map((row) => ({
            poligono: parseInt(row.poligono),
            total: parseInt(row.total),
          }));
          const getPoligonosRed15 = `SELECT (ST_Dump(ST_Polygonize(the_geom))).geom as the_geom FROM (SELECT ST_Union(the_geom) as the_geom FROM ${tableRed} WHERE categoria IN (1,5,8)) as a;`;
          const resultPoligonosRed15 = await executeQuery(getPoligonosRed15);
          const poligonosRed = resultPoligonosRed15.rows.map(
            (row) => row.the_geom
          );
          const poligonosRedData = await Promise.all(
            poligonosRed.map(async (poligonoRed15) => {
              const getContainsManzanasInRed = `SELECT count(*) as total FROM "${schema}".${tablePolRedInterMz} WHERE ST_Contains($1, ST_Buffer(the_geom, -0.00001));`;
              const result = await executeQuery(getContainsManzanasInRed, [
                poligonoRed15,
              ]);
              return {
                the_geom: poligonoRed15,
                total_contenidos: parseInt(result.rows[0].total),
              };
            })
          );
          for (const poligon of poligonos) {
            const poligono = poligon.poligono;
            const totalPoligonos = poligon.total;
            let counter = 0;
            for (const poligonRed of poligonosRedData) {
              const poligonoRed15 = poligonRed.the_geom;
              const totalContenidos = poligonRed.total_contenidos;
              const queryContencionPoligonos = `SELECT count(*) as total FROM "${schema}".${tablePolRedInterMz} WHERE ST_Contains($1, ST_Buffer(the_geom, -0.00001)) AND poligono_ = $2;`;
              const resultContencionPoligonos = await executeQuery(
                queryContencionPoligonos,
                [poligonoRed15, poligono]
              );
              const totalContenidosMismoId = parseInt(
                resultContencionPoligonos.rows[0].total
              );
              if (totalContenidosMismoId !== 0) {
                if (
                  totalContenidos !== totalContenidosMismoId ||
                  (totalContenidos === totalContenidosMismoId &&
                    totalContenidos !== totalPoligonos)
                ) {
                  if (!sinRepetir.includes(poligono)) {
                    sinRepetir.push(poligono);
                    badPoligonos.push({ i: badPoligonos.length + 1, poligono });
                    const getBadPoligonos = `SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as the_geom FROM "${schema}".${tablePolRedInterMz} as a WHERE poligono_ = $1;`;
                    const resultBadPoligonos = await executeQuery(
                      getBadPoligonos,
                      [poligono]
                    );
                    manzanaPolRed.push(
                      ...resultBadPoligonos.rows.map((row) => row.the_geom)
                    );
                  }
                }
              } else {
                counter++;
              }
            }
            if (counter === poligonosRedData.length) {
              sinRepetir.push(poligono);
              badPoligonos.push({ i: badPoligonos.length + 1, poligono });
              const getBadPoligonos = `SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as the_geom FROM "${schema}".${tablePolRedInterMz} as a WHERE poligono_ = $1;`;
              const resultBadPoligonos = await executeQuery(getBadPoligonos, [
                poligono,
              ]);
              manzanaPolRed.push(
                ...resultBadPoligonos.rows.map((row) => row.the_geom)
              );
            }
          }
          const getTodaRed15 = `SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as the_geom FROM ${tableRed} as a WHERE categoria IN (1,5,8);`;
          const resultGetTodaRed15 = await executeQuery(getTodaRed15);
          const redes = resultGetTodaRed15.rows.map(
            (objeto) => objeto.the_geom
          );
          fraccionamientos.red15 =
            redes.length !== 0
              ? { type: 'FeatureCollection', features: redes }
              : null;
          if (badPoligonos.length !== 0) {
            fraccionamientos.lista = badPoligonos;
            fraccionamientos.red = fraccionamientos.red15;
            fraccionamientos.poligonos = {
              type: 'FeatureCollection',
              features: manzanaPolRed,
            };
            validacion.fraccionamientos = 0;
          } else {
            validacion.fraccionamientos = 1;
          }
        } catch (error) {
          logger.error(
            'Error validating fraccionamientos in pol_red_inter_mz layer',
            error
          );
        }

        try {
          const getTodoPolRed = `SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as the_geom FROM "${schema}".${tablePolRedInterMz} as a;`;
          const resultTodoPolRed = await executeQuery(getTodoPolRed);
          const gids = nulosEscuelaLista.map((item) => item.gid);
          const getTodoPolRedEscuelaServicios = `SELECT jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(a.the_geom)::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as the_geom FROM ${tableEscuela} as a WHERE a.gid IN (${gids.join(
            ', '
          )});`;
          const resultTodoPolRedEscuelaServicios = await executeQuery(
            getTodoPolRedEscuelaServicios
          );
          polRedInterMz.poligonosRed = {
            type: 'FeatureCollection',
            features: resultTodoPolRed.rows.map((row) => row.the_geom),
          };
          polRedInterMz.redEscuelaServicios = {
            type: 'FeatureCollection',
            features: resultTodoPolRedEscuelaServicios.rows.map(
              (row) => row.the_geom
            ),
          };
        } catch (error) {
          logger.error('Error validating pol_red_inter_mz geometries', error);
        }

        try {
          const getDuplicatedManzanas = `WITH duplicated_manzanas AS (SELECT manzana, COUNT(*) FROM "${schema}".${tablePolRedInterMz} GROUP BY manzana HAVING COUNT(*) > 1) SELECT jsonb_build_object('type', 'FeatureCollection', 'features', jsonb_agg(jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(a.the_geom)::jsonb, 'properties', jsonb_build_object('gid', a.gid, 'localidad', a.localidad, 'manzana', a.manzana)))) as the_geom FROM "${schema}".${tablePolRedInterMz} a JOIN duplicated_manzanas b ON a.manzana = b.manzana;`;
          const resultDuplicatedManzanas = await executeQuery(
            getDuplicatedManzanas
          );
          comparacionManzanas.duplicatedManzanas =
            resultDuplicatedManzanas.rows;
          if (
            comparacionManzanas.duplicatedManzanas[0].the_geom.features === null
          ) {
            validacion.duplicatedManzanas = 1;
          } else {
            validacion.duplicatedManzanas = 0;
          }
        } catch (error) {
          logger.error(
            'Error validating duplicated manzanas in pol_red_inter_mz layer',
            error
          );
        }

        try {
          const mzReseccionamientoFaltantes = `WITH reseccion_manzanas AS (SELECT manzana FROM ${tableMzReseccionamiento}) SELECT jsonb_build_object('type', 'FeatureCollection', 'features', jsonb_agg(jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(a.the_geom)::jsonb, 'properties', jsonb_build_object('gid', a.gid, 'localidad', a.localidad, 'manzana', a.manzana)))) as the_geom FROM "${schema}".${tablePolRedInterMz} a WHERE a.manzana NOT IN (SELECT manzana FROM reseccion_manzanas);`;
          const resultMzReseccionamientoFaltantes = await executeQuery(
            mzReseccionamientoFaltantes
          );
          comparacionManzanas.mzReseccionamientoFaltantes =
            resultMzReseccionamientoFaltantes.rows;
          if (
            comparacionManzanas.mzReseccionamientoFaltantes[0].the_geom
              .features === null
          ) {
            validacion.mzReseccionamientoFaltantes = 1;
          } else {
            validacion.mzReseccionamientoFaltantes = 0;
          }
        } catch (error) {
          logger.error(
            'Error validating missing manzanas in mz_reseccionamiento layer',
            error
          );
        }

        try {
          const mzPolRedFaltantes = `WITH inter_mz_manzanas AS (SELECT manzana FROM "${schema}".${tablePolRedInterMz}) SELECT jsonb_build_object('type', 'FeatureCollection', 'features', jsonb_agg(jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(a.the_geom)::jsonb, 'properties', jsonb_build_object('gid', a.gid, 'localidad', a.localidad, 'manzana', a.manzana)))) as the_geom FROM ${tableMzReseccionamiento} a WHERE a.manzana NOT IN (SELECT manzana FROM inter_mz_manzanas);`;
          const resultMzPolRedFaltantes = await executeQuery(mzPolRedFaltantes);
          comparacionManzanas.mzPolRedFaltantes = resultMzPolRedFaltantes.rows;
          if (
            comparacionManzanas.mzPolRedFaltantes[0].the_geom.features === null
          ) {
            validacion.mzPolRedFaltantes = 1;
          } else {
            validacion.mzPolRedFaltantes = 0;
          }
        } catch (error) {
          logger.error(
            'Error validating missing manzanas in pol_red_inter_mz layer',
            error
          );
        }

        /* Este servicio genera la comparacion de las manzanas originales contra las nuevas modificagiones
         generadas por el técnico cartografo 
         *** Nota *** Solo se toman en cuenta las manzanas menores a 10,000 ya que estas son virtuales  */
        try {
          const mzPolRedFaltantes = `WITH inter_mz_manzanas AS (SELECT manzana FROM "${schema}".${tablePolRedInterMz}) SELECT jsonb_build_object('type', 'FeatureCollection', 'features', jsonb_agg(jsonb_build_object('type', 'Feature', 'geometry', ST_AsGeoJSON(a.the_geom)::jsonb, 'properties', jsonb_build_object('gid', a.gid, 'localidad', a.localidad, 'manzana', a.manzana)))) as the_geom FROM ${tableMzReseccionamiento} a WHERE a.manzana NOT IN (SELECT manzana FROM inter_mz_manzanas);`;
          const resultMzPolRedFaltantes = await executeQuery(mzPolRedFaltantes);
          comparacionManzanas.mzPolRedFaltantes = resultMzPolRedFaltantes.rows;
          if (
            comparacionManzanas.mzPolRedFaltantes[0].the_geom.features === null
          ) {
            validacion.mzPolRedFaltantes = 1;
          } else {
            validacion.mzPolRedFaltantes = 0;
          }
        } catch (error) {
          logger.error(
            'Error validating missing manzanas in pol_red_inter_mz layer',
            error
          );
        }
      }

      /* Esta consulta obtiene todas las manzanas que tienen el mismo valor en su campo geometría
      pero fue alterado el valor en su campo manzana */
      try {
        const mzGeomIgualNumDif = `
          WITH geom_match AS (
            SELECT 
              orig.the_geom AS orig_geom, 
              orig.manzana AS orig_manzana, 
              mod.the_geom AS mod_geom, 
              mod.manzana AS mod_manzana,
              orig.entidad, 
              orig.distrito, 
              orig.seccion, 
              orig.localidad, 
              orig.nombre
            FROM ${tableMzComparacion} orig
            JOIN ${tableMzReseccionamiento} mod 
            ON ST_Equals(orig.the_geom, mod.the_geom)
          )
          SELECT jsonb_build_object(
            'type', 'FeatureCollection',
            'features', jsonb_agg(
              jsonb_build_object(
                'type', 'Feature',
                'geometry', ST_AsGeoJSON(orig_geom)::jsonb,
                'properties', jsonb_build_object(
                  'entidad', entidad,
                  'distrito', distrito,
                  'seccion', seccion,
                  'localidad', localidad,
                  'orig_manzana', orig_manzana,
                  'mod_manzana', mod_manzana,
                  'nombre', nombre
                )
              )
            ORDER BY orig_manzana
            )
          ) as the_geom
          FROM geom_match
          WHERE orig_manzana != mod_manzana;
        `;
        const resultMzGeomIgualNumDif = await executeQuery(mzGeomIgualNumDif);
        comparacionTableMzComparacion.manzanasAlteradas =
          resultMzGeomIgualNumDif.rows;
        if (
          comparacionTableMzComparacion.manzanasAlteradas[0].the_geom
            .features === null
        ) {
          validacion.manzanasAlteradas = 1;
        } else {
          validacion.manzanasAlteradas = 0;
        }
      } catch (error) {
        logger.error(
          'Error comparing geometries with different manzana numbers',
          error
        );
      }

      try {
        const mzGeomIgualNumDifPol = `
          WITH geom_match AS (
            SELECT 
              orig.the_geom AS orig_geom, 
              orig.manzana AS orig_manzana, 
              mod.the_geom AS mod_geom, 
              mod.manzana AS mod_manzana,
              orig.entidad, 
              orig.distrito, 
              orig.seccion, 
              orig.localidad, 
              orig.nombre
            FROM ${tableMzComparacion} orig
            JOIN "${schema}".${tablePolRedInterMz} mod 
            ON ST_Equals(orig.the_geom, mod.the_geom)
          )
          SELECT jsonb_build_object(
            'type', 'FeatureCollection',
            'features', jsonb_agg(
              jsonb_build_object(
                'type', 'Feature',
                'geometry', ST_AsGeoJSON(orig_geom)::jsonb,
                'properties', jsonb_build_object(
                  'entidad', entidad,
                  'distrito', distrito,
                  'seccion', seccion,
                  'localidad', localidad,
                  'orig_manzana', orig_manzana,
                  'mod_manzana', mod_manzana,
                  'nombre', nombre
                )
              )
            ORDER BY orig_manzana
            )
          ) as the_geom
          FROM geom_match
          WHERE orig_manzana != mod_manzana;
        `;
        const resultMzGeomIgualNumDif = await executeQuery(
          mzGeomIgualNumDifPol
        );
        comparacionTableMzComparacion.manzanasAlteradasPol =
          resultMzGeomIgualNumDif.rows;
        if (
          comparacionTableMzComparacion.manzanasAlteradasPol[0].the_geom
            .features === null
        ) {
          validacion.manzanasAlteradasPol = 1;
        } else {
          validacion.manzanasAlteradasPol = 0;
        }
      } catch (error) {
        logger.error(
          'Error comparing geometries with different manzana numbers',
          error
        );
      }

      /* Esta consulta obtiene todas las manzanas que tienen el mismo valor en su campo manzana
      pero su geometría fue alterada */
      try {
        const mzNumIgualGeomDif = `
          WITH num_match AS (
            SELECT 
              orig.the_geom AS orig_geom, 
              mod.the_geom AS mod_geom, 
              orig.manzana, 
              orig.entidad, 
              orig.distrito, 
              orig.seccion, 
              orig.localidad, 
              orig.nombre
            FROM ${tableMzComparacion} orig
            JOIN ${tableMzReseccionamiento} mod 
            ON orig.manzana = mod.manzana
          )
          SELECT jsonb_build_object(
            'type', 'FeatureCollection',
            'features', jsonb_agg(
              jsonb_build_object(
                'type', 'Feature',
                'geometry', ST_AsGeoJSON(orig_geom)::jsonb,
                'properties', jsonb_build_object(
                  'entidad', entidad,
                  'distrito', distrito,
                  'seccion', seccion,
                  'localidad', localidad,
                  'manzana', manzana,
                  'nombre', nombre,
                  'orig_geom', jsonb_build_object(
                    'type', 'FeatureCollection',
                    'features', jsonb_build_array(
                      jsonb_build_object(
                        'type', 'Feature',
                        'geometry', ST_AsGeoJSON(orig_geom)::jsonb,
                        'properties', jsonb_build_object(
                          'manzana', manzana
                        )
                      )
                    )
                  ),
                  'mod_geom', jsonb_build_object(
                    'type', 'FeatureCollection',
                    'features', jsonb_build_array(
                      jsonb_build_object(
                        'type', 'Feature',
                        'geometry', ST_AsGeoJSON(mod_geom)::jsonb,
                        'properties', jsonb_build_object(
                          'manzana', manzana
                        )
                      )
                    )
                  )
                )
              )
            ORDER BY manzana
            )
          ) as the_geom
          FROM num_match
          WHERE NOT ST_Equals(orig_geom, mod_geom);
        `;
        const resultMzNumIgualGeomDif = await executeQuery(mzNumIgualGeomDif);
        comparacionTableMzComparacion.manzanaAlteradaGeometria =
          resultMzNumIgualGeomDif.rows;
        if (
          comparacionTableMzComparacion.manzanaAlteradaGeometria[0].the_geom
            .features === null
        ) {
          validacion.manzanaAlteradaGeometria = 1;
        } else {
          validacion.manzanaAlteradaGeometria = 0;
        }
      } catch (error) {
        logger.error(
          'Error comparing manzanas with different geometries',
          error
        );
      }

      try {
        const mzNumIgualGeomDifPol = `
          WITH num_match AS (
            SELECT 
              orig.the_geom AS orig_geom, 
              mod.the_geom AS mod_geom, 
              orig.manzana, 
              orig.entidad, 
              orig.distrito, 
              orig.seccion, 
              orig.localidad, 
              orig.nombre
            FROM ${tableMzComparacion} orig
            JOIN "${schema}".${tablePolRedInterMz} mod 
            ON orig.manzana = mod.manzana
          )
          SELECT jsonb_build_object(
            'type', 'FeatureCollection',
            'features', jsonb_agg(
              jsonb_build_object(
                'type', 'Feature',
                'geometry', ST_AsGeoJSON(orig_geom)::jsonb,
                'properties', jsonb_build_object(
                  'entidad', entidad,
                  'distrito', distrito,
                  'seccion', seccion,
                  'localidad', localidad,
                  'manzana', manzana,
                  'nombre', nombre,
                  'orig_geom', jsonb_build_object(
                    'type', 'FeatureCollection',
                    'features', jsonb_build_array(
                      jsonb_build_object(
                        'type', 'Feature',
                        'geometry', ST_AsGeoJSON(orig_geom)::jsonb,
                        'properties', jsonb_build_object(
                          'manzana', manzana
                        )
                      )
                    )
                  ),
                  'mod_geom', jsonb_build_object(
                    'type', 'FeatureCollection',
                    'features', jsonb_build_array(
                      jsonb_build_object(
                        'type', 'Feature',
                        'geometry', ST_AsGeoJSON(mod_geom)::jsonb,
                        'properties', jsonb_build_object(
                          'manzana', manzana
                        )
                      )
                    )
                  )
                )
              )
            ORDER BY manzana
            )
          ) as the_geom
          FROM num_match
          WHERE NOT ST_Equals(orig_geom, mod_geom);
        `;
        const resultMzNumIgualGeomDif = await executeQuery(
          mzNumIgualGeomDifPol
        );
        comparacionTableMzComparacion.manzanaAlteradaGeometriaPol =
          resultMzNumIgualGeomDif.rows;
        if (
          comparacionTableMzComparacion.manzanaAlteradaGeometriaPol[0].the_geom
            .features === null
        ) {
          validacion.manzanaAlteradaGeometriaPol = 1;
        } else {
          validacion.manzanaAlteradaGeometriaPol = 0;
        }
      } catch (error) {
        logger.error(
          'Error comparing manzanas with different geometries',
          error
        );
      }

      //**********************************  ---Validacion---- ************************************/
      const pool2 = getConn('reseccionamientoBitacora');

      //validamos si ya estan las banderas en true
      const verificarTodo = (objeto) => {
        for (let key in objeto) {
          if (
            Object.prototype.hasOwnProperty.call(objeto, key) &&
            key !== 'stamp' &&
            key !== 'user'
          ) {
            if (objeto[key] !== 1) {
              return false;
            }
          }
        }
        return true;
      };

      const attended_three = verificarTodo(validacion);
      const current_date_val = new Date().toLocaleString('es-MX', {
        timeZone: 'America/Mexico_City',
      });
      validacion.stamp = current_date_val;
      const queryValidacionEtapaTres = `
      UPDATE
          public.reporte2024
      SET
          attended_three = $1,
          logbook_three = COALESCE(logbook_three, '[]' :: jsonb) || $2 :: jsonb,
          current_date_val = $3
      WHERE
          id=$4
      `;

      await getQuery(pool2, queryValidacionEtapaTres, [
        attended_three,
        JSON.stringify(validacion),
        current_date_val,
        id,
      ]);

      res
        .setHeader(
          'Strict-Transport-Security',
          'max-age=31536000; includeSubDomains; preload'
        )
        .json({
          code: '02',
          data: {
            aux,
            validarGeometriaRed,
            validarGeometriaRedInvalidas,
            validarGeometriaMz,
            nodosDuplicadosRed,
            geometriasDuplicadasRed,
            nulosEscuelaLista,
            verificaNombresPol,
            sobreposicionPolRed,
            sobreposicionRedPolRed,
            totalPolMzCumple,
            validacion,
            fraccionamientos,
            polRedInterMz,
            comparacionManzanas,
            comparacionTableMzComparacion,
          },
        });
    } else {
      res
        .setHeader(
          'Strict-Transport-Security',
          'max-age=31536000; includeSubDomains; preload'
        )
        .json({
          code: '02',
          data: {
            validacion,
          },
        });
    }
  } catch (error) {
    logger.error('Unexpected error', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
