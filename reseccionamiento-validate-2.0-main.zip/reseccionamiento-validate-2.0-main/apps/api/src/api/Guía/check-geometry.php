<?php
$auth = $this->load('auth', array('return' => null, 'refresh_session' => true, 'necessary' => true, 'duration' => null, 'permissions' => array('admin', 'tac') ));
$conn = $this->load('pgsql', $_C['reseccionamientopostgres']);
$conn_r = $this->load('mysql', $_C['validacionmysql']);

$permisos = array_column($_S['dat']['pri'], 'nom');

if(in_array('tac', $permisos)){
    $cve_entidad = (int)$_S['dat']['cen'];
}
else{
    $cve_entidad = $conn->to_int($this->get_var('e', true, 'Necesitas enviar una entidad'), true);
}

$cve_df = $conn->to_int($this->get_var('d', true, 'Necesitas enviar un distrito'), true);

$s = $this->get_var('s', true, 'Necesitas enviar una seccion');
$et = $this->get_var('et', true, 'Necesitas enviar una etapa');

$e = $conn->to_int($cve_entidad, true);
$d = $conn->to_int($cve_df, true);
$et = $conn->to_int($et, true);

$entidad_ = strlen($e)==1?'0'.$e:$e;
$distrito_ = strlen($d)==1?'0'.$d:$d;
$s = $conn->to_int($s, true);

if ($s < 10) {
    $seccion_ = '000' . $s;
} else if ($s < 100) {
    $seccion_ = '00' . $s;
} else if ($s < 1000) {
    $seccion_ = '0' . $s;
} else {
    $seccion_ = $s;
}

/*Genera nombre de tablas*/
$schema = '"'.$entidad_.'dto'.$distrito_.'"';
$table_red = "$schema.red".$seccion_;
$table_mz_reseccionamiento = "$schema.mz_reseccionamiento".$seccion_;
$table_pol_red_inter_mz = "$schema.pol_red_inter_mz".$seccion_;
$table_escuela = "$schema.escuela".$seccion_;
$table_poligonos_red = "$schema.poligonos_red".$seccion_;
$schema_temp = $entidad_.'dto'.$distrito_;


$validacion = [
    'usuario' => $conn_r->to_varchar($_S['dat']['usr'], true),
    'entidad' => $e,
    'distrito' => $d,
    'seccion' => $s,
    'etapa' => $et,
    'geometria_red' => 0,
    'geometria_mz' => 0,
    'nodos_duplicados_red' => 0,
    'redes_duplicadas' => 0,
    'sobreposicion_mz' => 0,
    'sobreposicion_red_sobre_mz' => 0,
    'categoria_red' => 0,
    'sobreposicion_red' => 0,
    'manzana_repetida_geom' => 0,
    'manzana_repetida_datos' => 0,
    'manzana_datos_nulos_otros' => 0,
    'existe_tabla_poligonos' => 0,
    'existe_tabla_poligonos_campo_gid' => 0,
    'existe_tabla_poligonos_campo_geom' => 0,
    'manzana_sin_poligono' => 0,
    'manzanas_intersectan_poligonos' => 0,
    'poligono_con_mas_manzanas' => 0,
    'poligonos_sin_manzanas' => 0,
    'existe_tabla_pol_red' => 0,
    'existe_tabla_pol_red_campo_geom' => 0,
    'totales' => 0,
    'sobreposicion_pol_red' => 0,
    'sobreposicion_red_sobre_pol_red' => 0,
    'existe_tabla_pol_red_campo_poligono' => 0,
    'fraccionamientos' => 0,
    'nulos_escuela' => 0
];


/*----------------------------Comprobar geometria en la capa red-----------------------------*/
try{
    $_R['validar_geometria_red'] = [];
    $sql_check_geometry = "SELECT the_geom, gid FROM $table_red WHERE NOT ST_isValid(the_geom) OR ST_Length(the_geom) = 0 OR the_geom IS NULL;";
    $query_result = $conn->query($sql_check_geometry);

    $i = 0;
    $gids = [];
    foreach($query_result as $result){
        $_R['validar_geometria_red'][$i]['gid'] = $this->j_int($result->gid, true);
        array_push($gids, $this->j_int($result->gid, true));
        $i++;
    }

    if(count($gids)){
        $gids_str = implode(',', $gids);
        //TODO Elimina geometrias invalidas o nulas
        $sql_delete = "DELETE FROM $table_red WHERE gid IN ($gids_str);";
        $query_result = $conn->query($sql_delete);
        $validacion['geometria_red'] = 0;
    }else{
        $validacion['geometria_red'] = 1;
    }
}catch(Exception $e){
    $_R['error']['validar_geometria_red'] = $e;
}

/*----------------------------Comprobar geometria mz-reseccionamiento-----------------------------*/
try{
    $_R['validar_geometria_mz'] = [];
    // Primero las geometrias no validas
    $sql_check_geometries = "SELECT manzana, gid FROM $table_mz_reseccionamiento WHERE NOT ST_isValid(the_geom);";
    $query_result = $conn->query($sql_check_geometries);

    $validacion['geometria_mz'] = 1;

    $i = 0;
    foreach($query_result as $result){
        $validacion['geometria_mz'] = 0;
        $gid = $this->j_int($result->gid, true);
        $manzana = $this->j_int($result->manzana, true);
        $_R['validar_geometria_mz'][$i]['i'] = $i+1;
        $_R['validar_geometria_mz'][$i]['manzana'] = isset($manzana)?$manzana:'nulo';
        $_R['validar_geometria_mz'][$i]['gid'] = $gid;
        $_R['validar_geometria_mz'][$i]['nula'] = 0;
        $i++;
    }

    /*Luego geometrías nulas*/
    $sql_null_geometries = "SELECT manzana, gid FROM $table_mz_reseccionamiento WHERE ST_Area(the_geom) = 0 OR ST_Perimeter(the_geom) = 0 OR the_geom IS NULL;";
    $query_result = $conn->query($sql_null_geometries);

    $gids = [];
    $j = 0;
    foreach($query_result as $result){
        $gid = $this->j_int($result->gid, true);
        $manzana = $this->j_int($result->manzana, true);
        $_R['validar_geometria_mz'][$i]['i'] = $j+1;
        $_R['validar_geometria_mz'][$i]['manzana'] = isset($manzana)?$manzana:'nulo';
        $_R['validar_geometria_mz'][$i]['gid'] = $gid;
        $_R['validar_geometria_mz'][$i]['nula'] = 1;
        if(!in_array($gid, $gids)){
            array_push($gids, $gid);
        }
        $i++;
        $j++;
    }

    if(count($gids)){
        $gids_str = implode(',', $gids);
        //TODO Elimina geometrias nulas
        $sql_delete = "DELETE FROM $table_mz_reseccionamiento WHERE gid IN ($gids_str);";
        $query_result = $conn->query($sql_delete);
        $validacion['geometria_mz'] = 0;
    }
}catch(Exception $e){
    $_R['error']['validar_geometria_mz'] = $e;
}

/*----------------------------Comprobar nodos duplicados en la capa red-----------------------------*/
try{
    $_R['nodos_duplicados_red']['nodos'] = null;
    $_R['nodos_duplicados_red']['total'] = 0;
    $sql_duplicate_nodes = "SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb, 'properties', '{}'::jsonb) AS the_geom, gid, COUNT(*) FROM (SELECT (ST_Dump(ST_Points(the_geom))).geom as the_geom, gid FROM $table_red as red WHERE red.gid NOT IN (SELECT gid FROM $table_red WHERE ST_RemoveRepeatedPoints(the_geom) = the_geom) AND red.gid = 491) AS g GROUP BY the_geom, gid HAVING COUNT(*) > 1;";
    $query_result = $conn->query($sql_duplicate_nodes);

    $_R['nodos_duplicados_red']['total'] = count($query_result);

    $gids = [];
    $geometries = [];
    $gid_ordenados = [];
    foreach($query_result as $result){
        $gid = $this->j_int($result->gid, true);
        $geometry = $this->j_varchar($result->the_geom, true);

        if(!in_array($geometry, $geometries))
            array_push($geometries, $geometry);

        if(!in_array($gid, $gids)){
            array_push($gids, $gid);
            $gid_ordenados[$gid]['gid'] = $gid;
            $gid_ordenados[$gid]['contador'] = 1;
        }else{
            $gid_ordenados[$gid]['contador']++;
        }
    }

    if(count($gids)){

        /*$_R['nodos_duplicados_red']['lineas_gid'] = $gids;*/
        $i = 0;
        foreach($gid_ordenados as $gid_){
            $_R['nodos_duplicados_red']['lista'][$i]['i'] = $i+1;
            $_R['nodos_duplicados_red']['lista'][$i]['gid'] = $gid_['gid'];
            $_R['nodos_duplicados_red']['lista'][$i]['repetidos'] =  $gid_['contador'];
            $i++;
        }

        $_R['nodos_duplicados_red']['nodos'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries).']}';;

        $gids_str = implode(',', $gids);
        //TODO Elimina nodos duplicados
        $sql_repair = "UPDATE $table_red SET the_geom = ST_RemoveRepeatedPoints(the_geom) WHERE gid IN ($gids_str)";
        $query_result = $conn->query($sql_repair);
        
        
        $sql_lineas = "SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb, 'properties', to_jsonb(r.*) - 'the_geom') AS the_geom FROM $table_red as r WHERE gid IN ($gids_str)";
        $query_result = $conn->query($sql_lineas);

        $geometries = [];
        foreach($query_result as $result){
            array_push($geometries, $this->j_varchar($result->the_geom, true));
        }

        $_R['nodos_duplicados_red']['lineas'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries).']}';
        $validacion['nodos_duplicados_red'] = 0;
    }else{
        $validacion['nodos_duplicados_red'] = 1;
    }
    
}catch(Exception $e){
    $_R['error']['nodos_duplicados_red'] = $e;
}

/*----------------------------Comprobar geometrias red duplicadas y eliminar-----------------------------*/
try{
    $_R['geometrias_duplicadas_red']['lista'] = [];
    //$sql_duplicate_geometries = "SELECT gid, ST_AsGeoJSON(ST_Transform(r.the_geom, 4326)) as the_geom FROM (SELECT the_geom FROM $table_red WHERE NOT(NOT ST_isValid(the_geom) OR ST_Length(the_geom) = 0 OR the_geom IS NULL) GROUP BY the_geom HAVING COUNT(*) > 1) as g, $table_red as r WHERE g.the_geom = r.the_geom;";
    $sql_duplicate_geometries = "SELECT gid, r.the_geom as the_geom, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(r.the_geom, 4326))::jsonb, 'properties', to_jsonb(r.*) - 'the_geom') AS the_geom_b FROM ( SELECT the_geom FROM $table_red WHERE NOT(NOT ST_isValid(the_geom) OR ST_Length(the_geom) = 0 OR the_geom IS NULL) GROUP BY the_geom HAVING COUNT(*) > 1) as g, $table_red as r WHERE g.the_geom = r.the_geom;";
    $query_result = $conn->query($sql_duplicate_geometries);

    $i = 0;
    $gids = [];
    $geometries = [];
    $geometries_b = [];
    $gid_ordenados = [];
    foreach($query_result as $result){
        $gid = $this->j_int($result->gid, true);
        $geometry = $this->j_varchar($result->the_geom, true);
        $geometry_b = $this->j_varchar($result->the_geom_b, true);
        //$_R['geometrias_duplicadas_red']['lista'][$i]['gid'] = $gid;
        if(in_array($geometry, $geometries)){
            array_push($gid_ordenados[$geometry]['repetidos'], $gid);
            array_push($gids, $gid);
        }else{
            $gid_ordenados[$geometry]['gid'] = $gid;
            $gid_ordenados[$geometry]['repetidos'] = [];
            array_push($geometries, $geometry);
            array_push($geometries_b, $geometry_b);
        }
        $i++;
    }

    if(count($gids)){
        $_R['geometrias_duplicadas_red']['duplicados'] = count($geometries);
        $i = 0;
        foreach($gid_ordenados as $gid_){
            $_R['geometrias_duplicadas_red']['lista'][$i]['i'] = $i+1;
            $_R['geometrias_duplicadas_red']['lista'][$i]['gid'] = $gid_['gid'];
            $_R['geometrias_duplicadas_red']['lista'][$i]['repetidos'] =  implode(', ', $gid_['repetidos']);
            $i++;
        }
        $_R['geometrias_duplicadas_red']['geometry'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries_b).']}';
        $gids_str = implode(',', $gids);
        //TODO Elimina geometrias duplicadas
        $sql_delete = "DELETE FROM $table_red WHERE gid IN ($gids_str);";
        //$query_result = $conn->query($sql_delete);
        $validacion['redes_duplicadas'] = 0;
    }else{
        $validacion['redes_duplicadas'] = 1;
    }
}catch(Exception $e){
    $_R['error']['geometrias_duplicadas_red'] = $e;
}

if($et == 1){

    /*----------------------------Comprobar sobreposicion en mz-reseccionamiento-----------------------------*/
    try{
        $_R['sobreposicion_mz']['lista'] = [];
        $sql_overlap_geometry = "SELECT a.gid as gid_a, b.gid as gid_b, a.manzana as manzana_a, b.manzana as manzana_b, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') AS geom_a, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom') AS geom_b, ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326)) as intersection FROM (SELECT the_geom, gid, manzana FROM $table_mz_reseccionamiento) AS a, (SELECT the_geom, gid, manzana FROM $table_mz_reseccionamiento) AS b WHERE a.gid != b.gid AND a.gid < b.gid AND (ST_Overlaps(a.the_geom,b.the_geom) OR (ST_Intersects(a.the_geom, st_buffer(b.the_geom, -0.000001)) AND ((ST_Contains(a.the_geom, st_buffer(b.the_geom, -0.000001)) AND b.manzana = 9999) OR (ST_Contains(b.the_geom, st_buffer(a.the_geom, -0.000001)) AND a.manzana = 9999)))) AND NOT(a.the_geom = b.the_geom) ORDER BY a.gid, b.gid;";
        //$_R['query'] = $sql_overlap_geometry;
        $query_result = $conn->query($sql_overlap_geometry);


        $geometrias_mz_a = [];
        $geometrias_mz_b = [];
        $geometrias_interseccion = [];
        $intersecciones = [];
        foreach($query_result as $result){
            $gid_a = $this->j_int($result->gid_a, true);
            $mz_a = $this->j_int($result->manzana_a, true);
            $mz_b = $this->j_int($result->manzana_b, true);
            $geometria_a = $this->j_varchar($result->geom_a, true);
            $geometria_b = $this->j_varchar($result->geom_b, true);
            $geometria_interseccion = $this->j_varchar($result->intersection, true);

            if(!in_array($geometria_a, $geometrias_mz_a)){
                array_push($geometrias_mz_a, $geometria_a);
                $intersecciones[$gid_a]['gid'] = $gid_a;
                $intersecciones[$gid_a]['mz'] = $mz_a;
                $intersecciones[$gid_a]['mz_interseccion'] = [$mz_b];
            }else{
                array_push($intersecciones[$gid_a]['mz_interseccion'], $mz_b);
            }

            if(!in_array($geometria_b, $geometrias_mz_b))
                array_push($geometrias_mz_b, $geometria_b);

            if(!in_array($geometria_interseccion, $geometrias_interseccion))
                array_push($geometrias_interseccion, $geometria_interseccion);

            /*$_R['sobreposicion_mz'][$i]['geometry_mz_a'] = $this->j_varchar($result->geom_a, true);
            $_R['sobreposicion_mz'][$i]['geometry_mz_b'] = $this->j_varchar($result->geom_b, true);
            $_R['sobreposicion_mz'][$i]['interseccion'] = $this->j_varchar($result->intersection, true);*/
            /*$_R['sobreposicion_mz']['lista'][$i]['gid_a'] = $this->j_int($result->gid_a, true);
            $_R['sobreposicion_mz']['lista'][$i]['gid_b'] = $this->j_int($result->gid_b, true);
            $_R['sobreposicion_mz']['lista'][$i]['manzana_a'] = $this->j_int($result->manzana_a, true);
            $_R['sobreposicion_mz']['lista'][$i]['manzana_b'] = $this->j_int($result->manzana_b, true);*/
            
            $i++;
        }

        $len = count($query_result);
        if($len){
            $i=0;
            foreach($intersecciones as $inter){
                $_R['sobreposicion_mz']['lista'][$i]['i'] = $i+1;
                $_R['sobreposicion_mz']['lista'][$i]['gid'] = $inter['gid'];
                $_R['sobreposicion_mz']['lista'][$i]['manzana'] = $inter['mz'];
                $_R['sobreposicion_mz']['lista'][$i]['contenidas'] = implode(', ',$inter['mz_interseccion']);
                $i++;
            }

            $_R['sobreposicion_mz']['mz_a'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_mz_a).']}';
            $_R['sobreposicion_mz']['mz_b'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_mz_b).']}';
            $_R['sobreposicion_mz']['interseccion'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_interseccion).']}';
            $validacion['sobreposicion_mz'] = 0;
        }else{
            $validacion['sobreposicion_mz'] = 1;
        }
    }catch(Exception $e){
        $_R['error']['sobreposicion_mz'] = $e;
    }

    /*----------------------------Comprobar sobreposicion red sobre mz-reseccionamiento-----------------------------*/
    try{
        $_R['sobreposicion_red_mz']['lista'] = [];
        //$sql_overlap_geometry = "SELECT a.gid as gid_a, b.gid as gid_b, b.manzana as manzana, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') AS geom_a, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom') AS geom_b, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326))::jsonb, 'properties', CONCAT('{\"gid\":',a.gid,',\"categoria\":',a.categoria,'}')::jsonb) as intersection FROM (SELECT the_geom, id, gid FROM $table_red) AS a, (SELECT ST_Buffer(the_geom, -0.00001) AS the_geom, gid, manzana FROM $table_mz_reseccionamiento) AS b WHERE ST_Overlaps(a.the_geom,b.the_geom) OR ST_Crosses(a.the_geom,b.the_geom) OR ST_Intersects(a.the_geom,b.the_geom) ORDER BY manzana;";
        $sql_overlap_geometry = "SELECT a.gid as gid_a, b.gid as gid_b, b.manzana as manzana, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') AS geom_a, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom') AS geom_b, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as intersection FROM (SELECT the_geom, id, gid, categoria FROM $table_red) AS a, (SELECT ST_Buffer(the_geom, -0.00001) AS the_geom, gid, manzana FROM $table_mz_reseccionamiento) AS b WHERE ST_Overlaps(a.the_geom,b.the_geom) OR ST_Crosses(a.the_geom,b.the_geom) OR ST_Intersects(a.the_geom,b.the_geom) ORDER BY manzana;";
        //$_R['QUERY']= $sql_overlap_geometry;
        $query_result = $conn->query($sql_overlap_geometry);

        $geometrias_red = [];
        $geometrias_mz = [];
        $geometrias_interseccion = [];
        $intersecciones = [];
        foreach($query_result as $result){
            $gid_red = $this->j_int($result->gid_a, true);
            $manzana = $this->j_int($result->manzana, true);
            $red = $this->j_varchar($result->geom_a, true);
            $mz = $this->j_varchar($result->geom_b, true);
            $interseccion = $this->j_varchar($result->intersection, true);

            if(!in_array($red, $geometrias_red)){
                $intersecciones[$gid_red]['gid'] = $gid_red;
                $intersecciones[$gid_red]['mz_intersecciones'] = [$manzana];
                array_push($geometrias_red, $red);
            }else{
                array_push($intersecciones[$gid_red]['mz_intersecciones'], $manzana);
            }

            if(!in_array($mz, $geometrias_mz))
                array_push($geometrias_mz, $mz);

            if(!in_array($interseccion, $geometrias_interseccion))
                array_push($geometrias_interseccion, $interseccion);

        }


        $len = count($query_result);
        if($len){
            $i=0;
            foreach($intersecciones as $inter){
                $_R['sobreposicion_red_mz']['lista'][$i]['i'] = $i+1;
                $_R['sobreposicion_red_mz']['lista'][$i]['gid'] = $inter['gid'];
                $_R['sobreposicion_red_mz']['lista'][$i]['repetidos'] = implode(', ',$inter['mz_intersecciones']);
                $i++;
            }
            $_R['sobreposicion_red_mz']['red'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_red).']}';
            $_R['sobreposicion_red_mz']['mz'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_mz).']}';
            $_R['sobreposicion_red_mz']['interseccion'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_interseccion).']}';
            $validacion['sobreposicion_red_sobre_mz'] = 0;
        }else{
            $validacion['sobreposicion_red_sobre_mz'] = 1;
        }

    }catch(Exception $e){
        $_R['error']['sobreposicion_red_mz'] = $e;
    }

    /*----------------------------Comprobar categoria en red-----------------------------*/
    try{
        $_R['validar_categoria_red']['lista'] = [];
        $sql_check_geometry = "SELECT gid, categoria FROM $table_red WHERE categoria NOT IN (1,2,3,5);";
        $query_result = $conn->query($sql_check_geometry);
    
        $i = 0;
        $gids = [];
        foreach($query_result as $result){
            $_R['validar_categoria_red']['lista'][$i]['i'] = $i+1;
            $_R['validar_categoria_red']['lista'][$i]['red'] = $this->j_int($result->gid, true);
            $_R['validar_categoria_red']['lista'][$i]['categoria'] = $this->j_int($result->categoria, true);
            array_push($gids, $this->j_int($result->gid, true));
            $i++;
        }

        if(count($query_result)){
            $validacion['categoria_red'] = 0;
        }else{
            $validacion['categoria_red'] = 1;
        }
    
    }catch(Exception $e){
        $_R['error']['validar_categoria_red'] = $e;
    }

    /*----------------------------Comprobar manzanas contenedoras-----------------------------*/
    try{
        $_R['mz_contenedoras']['lista'] = [];
        $sql_overlap_geometry = "SELECT ST_Contains(a.the_geom, st_buffer(b.the_geom, -0.000001)) as a_c_b, ST_Contains(b.the_geom, st_buffer(a.the_geom, -0.000001)) as b_c_a, a.gid as gid_a, b.gid as gid_b, a.manzana as manzana_a, b.manzana as manzana_b, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') AS geom_a, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom') AS geom_b, ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326)) as intersection FROM (SELECT the_geom, gid, manzana FROM $table_mz_reseccionamiento) AS a, (SELECT the_geom, gid, manzana FROM $table_mz_reseccionamiento) AS b WHERE a.gid != b.gid AND a.gid < b.gid AND ST_Intersects(a.the_geom, st_buffer(b.the_geom, -0.000001)) AND NOT(a.the_geom = b.the_geom) AND ((ST_Contains(a.the_geom, st_buffer(b.the_geom, -0.000001)) AND b.manzana != 9999) OR (ST_Contains(b.the_geom, st_buffer(a.the_geom, -0.000001)) AND a.manzana != 9999)) ORDER BY a.gid, b.gid;";
        $query_result = $conn->query($sql_overlap_geometry);

        $geometrias_mz_a = [];
        $geometrias_mz_b = [];
        $manzanas = [];

        $sql_verify_field_gid = "SELECT NOT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = '$schema_temp' and table_name = 'mz_reseccionamiento$seccion_' and column_name = 'contenida') as contenida_exists";
        $not_exists_contenida = $conn->query($sql_verify_field_gid)[0]->contenida_exists;
        $_R['mz_contenedoras']['contenida'] = $not_exists_contenida == 't';
        
        if($not_exists_contenida == 't'){
            $sql_add_contenida = "ALTER TABLE $table_mz_reseccionamiento ADD COLUMN contenida SMALLINT DEFAULT 0;";
            $conn->query($sql_add_contenida);
            $_R['mz_contenedoras']['create_contenida'] = true;
        }

        $query_update_contenida_0 = "UPDATE $table_mz_reseccionamiento SET contenida = 0";
        $conn->query($query_update_contenida_0);
        
        foreach($query_result as $result){
            $acb = $this->j_bool($result->a_c_b, true);
            if($acb){
                $gid_a = $this->j_int($result->gid_a, true);
                $manzana_a = $this->j_int($result->manzana_a, true);
                $gid_b = $this->j_int($result->gid_b, true);
                $manzana_b = $this->j_int($result->manzana_b, true);
                $geometria_a = $this->j_varchar($result->geom_a, true);
                $geometria_b = $this->j_varchar($result->geom_b, true);

                $sql_update_contenedora = "UPDATE $table_mz_reseccionamiento SET contenida = 1 WHERE gid = $gid_b";
            }else{
                $gid_a = $this->j_int($result->gid_b, true);
                $manzana_a = $this->j_int($result->manzana_b, true);
                $gid_b = $this->j_int($result->gid_a, true);
                $manzana_b = $this->j_int($result->manzana_a, true);
                $geometria_a = $this->j_varchar($result->geom_b, true);
                $geometria_b = $this->j_varchar($result->geom_a, true);

                $sql_update_contenedora = "UPDATE $table_mz_reseccionamiento SET contenida = 1 WHERE gid = $gid_b";
            }

            $conn->query($sql_update_contenedora);

            if(!in_array($geometria_a, $geometrias_mz_a)){
                $manzanas[$gid_a]['gid'] = $gid_a;
                $manzanas[$gid_a]['manzana'] = $manzana_a;
                $manzanas[$gid_a]['contenidas'] = [$manzana_b];
                array_push($geometrias_mz_a, $geometria_a);
            } else{
                array_push($manzanas[$gid_a]['contenidas'], $manzana_b);
            }

            if(!in_array($geometria_b, $geometrias_mz_b)){
                array_push($geometrias_mz_b, $geometria_b);
            }

        }

        $len = count($query_result);
        if($len){
            $i = 0;
            foreach($manzanas as $manzana){
                $_R['mz_contenedoras']['lista'][$i]['gid'] = $manzana['gid'];
                $_R['mz_contenedoras']['lista'][$i]['manzana'] = $manzana['manzana'];
                $_R['mz_contenedoras']['lista'][$i]['contenidas'] = implode(', ',$manzana['contenidas']);
                $_R['mz_contenedoras']['lista'][$i]['i'] = $i+1;
                $i++;
            }
            $_R['mz_contenedoras']['mz_contenedora'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_mz_a).']}';
            $_R['mz_contenedoras']['mz_contenidas'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_mz_b).']}';
        }
    }catch(Exception $e){
        $_R['error']['mz_contenedoras'] = $e;
    }

}else if($et == 2){
    /*----------------------------Comprobar sobreposicion en red-----------------------------*/
    try{
        $_R['sobreposicion_red']['lista'] = [];
        $sql_overlap_geometry = "SELECT a.gid as gid_a, b.gid as gid_b, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as geom_a, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom') as geom_b, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom') as intersection FROM (SELECT the_geom, gid, id FROM $table_red) AS a, (SELECT the_geom, gid, id FROM $table_red) AS b WHERE a.gid != b.gid AND a.gid < b.gid AND (ST_Overlaps(a.the_geom,b.the_geom) OR ST_Contains(b.the_geom, a.the_geom) OR ST_Contains(a.the_geom, b.the_geom)) ORDER BY gid_a, gid_b;";
        $query_result = $conn->query($sql_overlap_geometry);

        $geometrias_mz_a = [];
        $geometrias_mz_b = [];
        $geometrias_interseccion = [];
        $interseccion_repetidos = [];
        foreach($query_result as $result){
            $gid_a = $this->j_int($result->gid_a, true);
            $gid_b = $this->j_int($result->gid_b, true);
            $geometria_a = $this->j_varchar($result->geom_a, true);
            $geometria_b = $this->j_varchar($result->geom_b, true);
            $geometria_interseccion = $this->j_varchar($result->intersection, true);

            if(!in_array($geometria_a, $geometrias_mz_a)){
                $interseccion_repetidos[$gid_a]['gid']=$gid_a;
                $interseccion_repetidos[$gid_a]['repetidos']=[$gid_b];
                array_push($geometrias_mz_a, $geometria_a);
            }else{
                array_push($interseccion_repetidos[$gid_a], $gid_b);
            }

            if(!in_array($geometria_b, $geometrias_mz_b))
                array_push($geometrias_mz_b, $geometria_b);

            if(!in_array($geometria_interseccion, $geometrias_interseccion))
                array_push($geometrias_interseccion, $geometria_interseccion);

            /*$_R['sobreposicion_red']['lista'][$i]['geometry_red_a'] = $this->j_varchar($result->geom_a, true);
            $_R['sobreposicion_red']['lista'][$i]['geometry_red_b'] = $this->j_varchar($result->geom_b, true);
            $_R['sobreposicion_red']['lista'][$i]['interseccion'] = $this->j_varchar($result->intersection, true);
            $_R['sobreposicion_red']['lista'][$i]['gid_a'] = $this->j_int($result->gid_a, true);
            $_R['sobreposicion_red']['lista'][$i]['gid_b'] = $this->j_int($result->gid_b, true);*/

        }

        $len = count($query_result);
        if($len){
            $i=0;
            foreach($interseccion_repetidos as $inter){
                $_R['sobreposicion_red']['lista'][$i]['i'] = $i+1;
                $_R['sobreposicion_red']['lista'][$i]['gid'] = $inter['gid'];
                $_R['sobreposicion_red']['lista'][$i]['repetidos'] = implode(', ',$inter['repetidos']);
                $i++;
            }
            $_R['sobreposicion_red']['red_a'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_mz_a).']}';
            $_R['sobreposicion_red']['red_b'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_mz_b).']}';
            $_R['sobreposicion_red']['interseccion'] = '{"type":"FeatureCollection","features":['.implode(',',$geometrias_interseccion).']}';
            $validacion['sobreposicion_red'] = 0;
        }else{
            $validacion['sobreposicion_red'] = 1;
        }
    }catch(Exception $e){
        $_R['error']['sobreposicion_red'] = $e;
    }  

    /*----------------------------Comprobar manzanas repetidas (geometrias)-----------------------------*/
    try{
        $_R['manzana_repetida_geom']['lista'] = [];
        $sql_duplicate_block = "SELECT gid, manzana, the_geom, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb, 'properties', to_jsonb(mz.*) - 'the_geom') as geom FROM $table_mz_reseccionamiento as mz WHERE the_geom IN (SELECT the_geom FROM $table_mz_reseccionamiento GROUP BY the_geom HAVING COUNT(*) > 1);";
        $query_result = $conn->query($sql_duplicate_block);

        $i = 0;
        $gids = [];
        $geometries = [];
        $geometries_mz = [];
        $manzanas_duplicadas = [];
        foreach($query_result as $result){
            $gid = $this->j_int($result->gid, true);
            $manzana = $this->j_int($result->manzana, true);
            $geom = $this->j_varchar($result->geom, true);
            $geometry = $this->j_varchar($result->the_geom, true);
            if(in_array($geometry, $geometries)){
                array_push($manzanas_duplicadas[$geometry]['repetidos'], $manzana);
                array_push($gids, $gid);
            }else{
                $manzanas_duplicadas[$geometry]['manzana'] = $manzana;
                $manzanas_duplicadas[$geometry]['repetidos'] = [];
                array_push($geometries, $geometry);
                array_push($geometries_mz, $geom);
                /*$_R['manzana_repetida_geom']['lista'][$i]['geometry'] = $geometry;
                $_R['manzana_repetida_geom']['lista'][$i]['manzana'] = $this->j_int($result->manzana, true);
                $_R['manzana_repetida_geom']['lista'][$i]['gid'] = $gid;*/
                $i++;
            }
        }

        if(count($gids)){
            $i = 0;
            foreach($manzanas_duplicadas as $mz_){
                $_R['manzana_repetida_geom']['lista'][$i]['i'] = $i+1;
                $_R['manzana_repetida_geom']['lista'][$i]['manzana'] = $mz_['manzana'];
                $_R['manzana_repetida_geom']['lista'][$i]['repetidos'] =  implode(', ', $mz_['repetidos']);
                $i++;
            }
            $_R['manzana_repetida_geom']['geometries'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries_mz).']}';
            $validacion['manzana_repetida_geom'] = 0;
            //No se elimina
            /*$gids_str = implode(',', $gids);
            //TODO Elimina geometrias duplicadas
            $sql_delete = "DELETE FROM $table_mz_reseccionamiento WHERE gid IN ($gids_str);";
            //$query_result = $conn->query($sql_delete);*/
        }else{
            $validacion['manzana_repetida_geom'] = 1;
        }
    }catch(Exception $e){
        $_R['error']['manzana_repetida_geom'] = $e;
    }

    /*----------------------------Comprobar manzanas repetidas (datos)-----------------------------*/
    try{
        $_R['manzana_repetida_datos']['lista'] = [];
        $sql_duplicate_block = "SELECT COUNT(*), entidad, distrito, municipio, seccion, localidad, manzana FROM $table_mz_reseccionamiento GROUP BY entidad, distrito, municipio, seccion, localidad, manzana HAVING COUNT(*) > 1;";
        $query_result = $conn->query($sql_duplicate_block);

        $j = 0;
        $gids = [];
        foreach($query_result as $manzana){
            $entidad = $conn->to_int($manzana->entidad, true);
            $distrito = $conn->to_int($manzana->distrito, true);
            $municipio = $conn->to_int($manzana->municipio, true);
            $seccion = $conn->to_int($manzana->seccion, true);
            $localidad = $conn->to_int($manzana->localidad, true);
            $manzana = $conn->to_int($manzana->manzana, true);

            $temp = [];
            $_R['manzana_repetida_datos']['lista'][$j]['entidad'] = $entidad;
            $_R['manzana_repetida_datos']['lista'][$j]['distrito'] = $distrito;
            $_R['manzana_repetida_datos']['lista'][$j]['seccion'] = $seccion;
            $_R['manzana_repetida_datos']['lista'][$j]['municipio'] = $municipio;
            $_R['manzana_repetida_datos']['lista'][$j]['localidad'] = $localidad;
            $_R['manzana_repetida_datos']['lista'][$j]['manzana'] = $manzana;
            
            $sql_get_gids = "SELECT gid FROM $table_mz_reseccionamiento WHERE entidad = $entidad AND distrito = $distrito AND municipio = $municipio AND seccion = $seccion AND localidad = $localidad AND manzana = $manzana;";
            $query_result = $conn->query($sql_get_gids);
            $gid_0 = $this->j_int($query_result[0]->gid, true);
            array_push($temp, $gid_0);
            for($i=1; $i<count($query_result); $i++){
                $gid = $this->j_int($query_result[$i]->gid, true);
                array_push($temp, $gid);
                if(!in_array($gid, $gids)){
                    array_push($gids, $gid);
                }
            }

            $_R['manzana_repetida_datos']['lista'][$j]['gid'] = implode(', ',$temp);

            $j++;
        }

        if(count($gids)){
            $gids_str = implode(',', $gids);
            //TODO Elimina manzanas repetidas (datos)
            $sql_delete = "DELETE FROM $table_mz_reseccionamiento WHERE gid IN ($gids_str);";
            $validacion['manzana_repetida_datos'] = 0;
            //$query_result = $conn->query($sql_delete);
        }else{
            $validacion['manzana_repetida_datos'] = 1;
        }
    }catch(Exception $e){
        $_R['error']['manzana_repetida_datos'] = $e;
    }

    /*----------------------------Comprobar datos nulos mz_reseccionamiento-----------------------------*/
    try{
        $_R['nulos_mz']['lista'] = [];
        $sql_check_null= "SELECT gid, entidad, distrito, municipio, seccion, localidad, manzana, (entidad != $e) AS entidad_distinto, (distrito != $d) AS distrito_distinto, (seccion != $s) AS seccion_distinto, (entidad IS NULL OR entidad = 0) AS val_entidad, (distrito IS NULL OR distrito = 0) AS val_distrito, (municipio IS NULL OR municipio = 0) AS val_municipio, (seccion IS NULL OR seccion = 0) AS val_seccion,  (localidad IS NULL) AS val_localidad,  (manzana IS NULL OR manzana = 0) AS val_manzana FROM $table_mz_reseccionamiento WHERE (entidad IS NULL OR entidad = 0) OR (distrito IS NULL OR distrito = 0) OR (municipio IS NULL OR municipio = 0) OR (seccion IS NULL OR seccion = 0) OR (localidad IS NULL) OR (manzana IS NULL OR manzana = 0) OR entidad != $e OR distrito != $d OR seccion != $s;";
        $query_result = $conn->query($sql_check_null);

        $i = 0;
        foreach($query_result as $result){
            $_R['nulos_mz']['lista'][$i]['gid'] = $this->j_int($result->gid, true);
            $_R['nulos_mz']['lista'][$i]['entidad'] = $this->j_bool($result->val_entidad, true) ? 1 : ($this->j_bool($result->entidad_distinto, true) ? 1 : 0);
            $_R['nulos_mz']['lista'][$i]['distrito'] = $this->j_bool($result->val_distrito, true) ? 1 : ($this->j_bool($result->distrito_distinto, true) ? 1 : 0);
            $_R['nulos_mz']['lista'][$i]['seccion'] = $this->j_bool($result->val_seccion, true) ? 1 : ($this->j_bool($result->seccion_distinto, true) ? 1 : 0);
            $_R['nulos_mz']['lista'][$i]['municipio'] = $this->j_bool($result->val_municipio, true) ? 1 : 0;
            $_R['nulos_mz']['lista'][$i]['localidad'] = $this->j_bool($result->val_localidad, true) ? 1 : 0;
            $_R['nulos_mz']['lista'][$i]['manzana'] = $this->j_bool($result->val_manzana, true) ? 1 : 0;
            $_R['nulos_mz']['lista'][$i]['detalleEntidad'] = $result->entidad;
            $_R['nulos_mz']['lista'][$i]['detalleDistrito'] = $result->distrito;
            $_R['nulos_mz']['lista'][$i]['detalleMunicipio'] = $result->municipio;
            $_R['nulos_mz']['lista'][$i]['detalleSeccion'] = $result->seccion;
            $_R['nulos_mz']['lista'][$i]['detalleLocalidad'] = $result->localidad;
            $_R['nulos_mz']['lista'][$i]['detalleManzana'] = $result->manzana;
            $i++;
        }

        $_R['LISTA_NULOS'] = $query_result;

        if(count($query_result)){
            $validacion['manzana_datos_nulos_otros'] = 0;
        }else{
            $validacion['manzana_datos_nulos_otros'] = 1;
        }
    }catch(Exception $e){
        $_R['error']['nulos_mz'] = $e;
    }

    /*----------------------------Comprobar que entidad, distrito y seccion sean los adecuados en mz_reseccionamiento-----------------------------*/
    /*try{
        $_R['otros_mz']['lista'] = [];
        $sql_check_null= "SELECT gid, entidad, distrito, seccion FROM $table_mz_reseccionamiento WHERE entidad != $e OR distrito != $d OR seccion != $s;";
        $query_result = $conn->query($sql_check_null);

        $i = 0;
        foreach($query_result as $result){
            $_R['otros_mz']['lista'][$i]['gid'] = $this->j_int($result->gid, true);
            $_R['otros_mz']['lista'][$i]['entidad'] = $this->j_int($result->entidad, true);
            $_R['otros_mz']['lista'][$i]['distrito'] = $this->j_int($result->distrito, true);
            $_R['otros_mz']['lista'][$i]['seccion'] = $this->j_int($result->seccion, true);
            $i++;
        }
    }catch(Exception $e){
        $_R['error']['otros_mz'] = $e;
    }*/

    /*----------------------------Verificar nombre tabla y columna - Poligonos -----------------------------*/
    try{
        $_R['verifica_nombres'] = [];
        $sql_verify_table_poligonos = "SELECT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = '$schema_temp' and table_name = 'poligonos_red$seccion_') as table_exists";
        $exists_table = $conn->query($sql_verify_table_poligonos)[0]->table_exists;
        $_R['verifica_nombres']['table'] = $exists_table == 't';

        //Si existe la tabla, se hacen las validaciones respectivas
        if($exists_table == 't'){
            $validacion['existe_tabla_poligonos'] = 1;
            $sql_verify_field_gid = "SELECT NOT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = '$schema_temp' and table_name = 'poligonos_red$seccion_' and column_name = 'gid') as gid_exists";
            $not_exists_gid = $conn->query($sql_verify_field_gid)[0]->gid_exists;
            $_R['verifica_nombres']['gid'] = $not_exists_gid == 't';

            if($not_exists_gid == 't'){
                $sql_verify_field_id = "SELECT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = '$schema_temp' and table_name = 'poligonos_red$seccion_' and column_name = 'id') as id_exists";
                $exists_id = $conn->query($sql_verify_field_id)[0]->id_exists;
                if($exists_id == 't'){
                    $sql_rename_gid = "ALTER TABLE $table_poligonos_red RENAME COLUMN id TO gid;";
                    $conn->query($sql_rename_gid);
                    $_R['verifica_nombres']['gid_check'] = true;
                    $validacion['existe_tabla_poligonos_campo_gid'] = 1;
                }else{
                    $_R['verifica_nombres']['gid_check'] = false;
                    $validacion['existe_tabla_poligonos_campo_gid'] = 0;
                    $validacion['manzana_sin_poligono'] = 0;
                    $validacion['manzanas_intersectan_poligonos'] = 0;
                    $validacion['poligono_con_mas_manzanas'] = 0;
                    $validacion['poligonos_sin_manzanas'] = 0;
                    $conn_r->insert('historial_validaciones', $validacion);
                    $this->end();
                }
            }else{
                $validacion['existe_tabla_poligonos_campo_gid'] = 1;
            }

            $sql_verify_field_the_geom = "SELECT NOT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = '$schema_temp' and table_name = 'poligonos_red$seccion_' and column_name = 'the_geom') as the_geom_exists";
            $not_exists_the_geom = $conn->query($sql_verify_field_the_geom)[0]->the_geom_exists;
            $_R['verifica_nombres']['the_geom'] = $not_exists_the_geom == 't';

            if($not_exists_the_geom == 't'){
                $sql_verify_field_geom = "SELECT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = '$schema_temp' and table_name = 'poligonos_red$seccion_' and column_name = 'geom') as geom_exists";
                $exists_geom = $conn->query($sql_verify_field_geom)[0]->geom_exists;
                if($exists_geom == 't'){
                    $sql_rename_the_geom = "ALTER TABLE $table_poligonos_red RENAME COLUMN geom TO the_geom;";
                    $conn->query($sql_rename_the_geom);
                    $_R['verifica_nombres']['check_the_geom'] = true;
                    $validacion['existe_tabla_poligonos_campo_geom'] = 1;
                }else{
                    $_R['verifica_nombres']['check_the_geom'] = false;
                    $validacion['existe_tabla_poligonos_campo_geom'] = 0;
                    $validacion['manzana_sin_poligono'] = 0;
                    $validacion['manzanas_intersectan_poligonos'] = 0;
                    $validacion['poligono_con_mas_manzanas'] = 0;
                    $validacion['poligonos_sin_manzanas'] = 0;
                    $conn_r->insert('historial_validaciones', $validacion);
                    $this->end();
                }
            }else{
                $validacion['existe_tabla_poligonos_campo_geom'] = 1;
            }

            /*----------------------------Comprobar que manzanas no están dentro de un poligono o sobrepuestas con poligono_red-----------------------------*/
            try{
                $_R['manzana_sin_poligono']['lista'] = [];
                $sql_block_in_polygon = "SELECT gid, manzana, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb, 'properties', to_jsonb(mz.*) - 'the_geom') as geom, the_geom FROM $table_mz_reseccionamiento AS mz WHERE manzana NOT IN (SELECT b.manzana FROM (SELECT the_geom, id FROM $table_poligonos_red) AS a, (SELECT ST_Buffer(the_geom, -0.00001) as the_geom, gid, manzana FROM $table_mz_reseccionamiento) AS b WHERE ST_Contains(a.the_geom, b.the_geom) ORDER BY manzana);";
                $query_result = $conn->query($sql_block_in_polygon);
        
                $i = 0;
                $geometries = [];
                $geometries_mz = [];
                $geometries_poligono = [];
                $intersecta = [];
                $j = 0;
                $k = 0;
                $encontro_intersecta = 1;
                foreach($query_result as $result){
                    $gid = $this->j_int($result->gid, true);
                    $geom = $this->j_varchar($result->geom, true);
                    $the_geom = $conn->to_varchar($result->the_geom, true);

                    /*$_R['manzana_sin_poligono'][$i]['the_geom'] = $geom;*/
                    $_R['manzana_sin_poligono']['lista'][$i]['gid'] = $gid;
                    $_R['manzana_sin_poligono']['lista'][$i]['manzana'] = $this->j_int($result->manzana, true);
                    $_R['manzana_sin_poligono']['lista'][$i]['intersecta'] = 0;
        
                    $sql_intersects = "SELECT gid, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb, 'properties', to_jsonb(pr.*) - 'the_geom') as the_geom FROM $table_poligonos_red as pr WHERE ST_Overlaps($the_geom, the_geom);";
                    $query_result_2 = $conn->query($sql_intersects);
        
                    if(count($query_result_2)){
                        $encontro_intersecta = 0;

                        if(!in_array($geom, $geometries_mz))
                            array_push($geometries_mz, $geom);
                        $_R['manzana_sin_poligono']['lista'][$i]['i'] = $j+1;
                        $_R['manzana_sin_poligono']['lista'][$i]['intersecta'] = 1;
                        $_R['manzana_sin_poligono']['lista'][$i]['repetidos'] = [];
                        $j++;
                        foreach($query_result_2 AS $result2){
                            $geom_poli = $this->j_varchar($result2->the_geom, true);
                            $geom_inter = $this->j_varchar($result2->intersection, true);

                            if(!in_array($geom_poli, $geometries_poligono))
                                array_push($geometries_poligono, $geom_poli);

                            /*$aux['geom'] = $this->j_varchar($result2->the_geom, true);*/
                            $temp_gid = $this->j_int($result2->gid, true);
                            array_push($_R['manzana_sin_poligono']['lista'][$i]['repetidos'], $temp_gid);
                        }
                        $_R['manzana_sin_poligono']['lista'][$i]['repetidos'] = implode(', ',$_R['manzana_sin_poligono']['lista'][$i]['repetidos']);
                    }else{
                        $_R['manzana_sin_poligono']['lista'][$i]['i'] = $k+1;
                        $k++;
                        if(!in_array($geom, $geometries))
                            array_push($geometries, $geom);
                    }
                    $i++;
                }

                $validacion['manzanas_intersectan_poligonos'] = $encontro_intersecta;
                if(count($query_result)){
                    $_R['manzana_sin_poligono']['geometries'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries).']}';
                    $_R['manzana_sin_poligono']['geometries_mz'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries_mz).']}';
                    $_R['manzana_sin_poligono']['geometries_poligonos'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries_poligono).']}';
                    $validacion['manzana_sin_poligono'] = 0;
                    
                }else{
                    $validacion['manzana_sin_poligono'] = 1;
                }
            }catch(Exception $e){
                $_R['error']['manzana_sin_poligono'] = $e;
            }
            
            /*----------------------------Comprobar que poligono tiene más de una manzana-----------------------------*/
            try{
                $_R['poligono_con_mas_manzanas']['lista'] = [];
                $sql_polygon_with_more_than_one_block = "SELECT count(*), a.gid as gid, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', CONCAT('{\"gid\":',a.gid,'}')::jsonb) as geom, a.the_geom FROM (SELECT the_geom, gid FROM $table_poligonos_red) AS a, (SELECT ST_Buffer(the_geom, -0.00001) as the_geom, gid, manzana FROM $table_mz_reseccionamiento) AS b WHERE ST_Contains(a.the_geom, b.the_geom) GROUP BY a.gid, a.the_geom HAVING COUNT(*) > 1;";
                $query_result = $conn->query($sql_polygon_with_more_than_one_block);
                $i = 0;
                $geometries = [];
                $geometries_mz = [];
                foreach($query_result as $result){
                    $geom = $conn->to_varchar($result->the_geom, true);
                    $the_geom = $this->j_varchar($result->geom, true);
                    if(!in_array($the_geom, $geometries)){
                        array_push($geometries, $the_geom);
                    }
                    /*$_R['poligono_con_mas_manzanas'][$i]['the_geom'] = $this->j_varchar($result->the_geom, true);*/
                    $_R['poligono_con_mas_manzanas']['lista'][$i]['i'] = $i+1;
                    $_R['poligono_con_mas_manzanas']['lista'][$i]['gid'] = $this->j_int($result->gid, true);
                    $sql_contains = "SELECT gid, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb, 'properties', to_jsonb(mz.*) - 'the_geom') as the_geom, manzana FROM $table_mz_reseccionamiento AS mz WHERE ST_Contains($geom, the_geom);";
                    $query_result_2 = $conn->query($sql_contains);
        
                    $_R['poligono_con_mas_manzanas']['lista'][$i]['repetidos'] = [];
                    foreach($query_result_2 AS $result2){
                        $temp_geom = $this->j_varchar($result2->the_geom, true);
                        if(!in_array($temp_geom, $geometries_mz)){
                            array_push($geometries_mz, $temp_geom);
                        }

                        /*$aux['geom'] = $this->j_varchar($result2->the_geom, true);*/
                        /*$aux['gid'] = $this->j_int($result2->gid, true);*/
                        /*$aux['manzana'] = $this->j_int($result2->manzana, true);*/
                        $aux = $this->j_int($result2->manzana, true);
                        array_push($_R['poligono_con_mas_manzanas']['lista'][$i]['repetidos'], $aux);
                    }
                    sort($_R['poligono_con_mas_manzanas']['lista'][$i]['repetidos']);
                    $_R['poligono_con_mas_manzanas']['lista'][$i]['repetidos'] = implode(', ',$_R['poligono_con_mas_manzanas']['lista'][$i]['repetidos']);
                    $i++;
                }

                if(count($query_result)){
                    $_R['poligono_con_mas_manzanas']['geometries'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries).']}';
                    $_R['poligono_con_mas_manzanas']['geometries_mz'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries_mz).']}';
                    $validacion['poligono_con_mas_manzanas'] = 0;
                }else{
                    $validacion['poligono_con_mas_manzanas'] = 1;
                }
            }catch(Exception $e){
                $_R['error']['poligono_con_mas_manzanas'] = $e;
            }
            
            /*----------------------------Comprobar que poligono no tiene alguna manzana y no está sobrepuesta -----------------------------*/
            try{
                $_R['poligono_sin_manzana']['lista'] = [];
                $sql_polygon_without_one_block = "SELECT gid, the_geom, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(the_geom, 4326))::jsonb, 'properties', to_jsonb(pr.*) - 'the_geom') AS geom FROM $table_poligonos_red AS pr WHERE gid NOT IN (SELECT a.gid FROM (SELECT the_geom, gid FROM $table_poligonos_red) AS a, (SELECT ST_Buffer(the_geom, -0.00001) as the_geom, gid, manzana FROM $table_mz_reseccionamiento) AS b WHERE ST_Contains(a.the_geom, b.the_geom));";
                $query_result = $conn->query($sql_polygon_without_one_block);
                $i = 0;
                $geometries = [];
                foreach($query_result as $result){
                    $geom = $this->j_varchar($result->geom, true);
                    $the_geom = $conn->to_varchar($result->the_geom, true);
                    $sql_contains = "SELECT ST_Intersects($the_geom, the_geom) as intersecta FROM $table_mz_reseccionamiento WHERE ST_Overlaps($the_geom, the_geom);";
                    $query_result_2 = $conn->query($sql_contains);
        
                    if(count($query_result_2) == 0){
                        if(!in_array($geom, $geometries)){
                            array_push($geometries, $geom);
                        }
                        $_R['poligono_sin_manzana']['lista'][$i]['i'] = $i+1;
                        /*Se cambia a 'manzana' en vez de gid*/
                        $_R['poligono_sin_manzana']['lista'][$i]['manzana'] = $this->j_int($result->gid, true);
                        //$_R['poligono_sin_manzana'][$i]['the_geom'] = $this->j_varchar($result->the_geom, true);
                        $i++;
                    }
                }

                if(count($query_result)){
                    $_R['poligono_sin_manzana']['geometries'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries).']}';
                    $validacion['poligonos_sin_manzanas'] = 0;
                }else{
                    $validacion['poligonos_sin_manzanas'] = 1;
                }
            }catch(Exception $e){
                $_R['error']['poligono_sin_manzana'] = $e;
            }

            if(count($_R['manzana_sin_poligono']) OR count($_R['poligono_con_mas_manzanas'])  OR count($_R['poligono_sin_manzana'])){
                //TODO Eliminar toda la tabla
                $sql_delete = "DROP TABLE $table_poligonos_red;";
                //$query_result = $conn->query($sql_delete);
            }
        }else{
            $validacion['existe_tabla_poligonos'] = 0;
            $validacion['existe_tabla_poligonos_campo_gid'] = 0;
            $validacion['existe_tabla_poligonos_campo_geom'] = 0;
            $validacion['manzana_sin_poligono'] = 0;
            $validacion['manzanas_intersectan_poligonos'] = 0;
            $validacion['poligono_con_mas_manzanas'] = 0;
            $validacion['poligonos_sin_manzanas'] = 0;
        }

    }catch(Exception $e){
        $_R['error']['verifica_nombres'] = $e;
    } 
    
}
else if($et == 3){
    /*----------------------------Comprobar datos nulos escuela-----------------------------*/
    try{
        $_R['nulos_escuela']['lista'] = [];
        $sql_overlaps_geometry = "SELECT gid, entidad, distrito, seccion, (entidad != $e) AS entidad_distinto, (distrito != $d) AS distrito_distinto, (seccion != $s) AS seccion_distinto, (entidad IS NULL OR entidad = 0) AS val_entidad, (distrito IS NULL OR distrito = 0) AS val_distrito, (seccion IS NULL OR seccion = 0) AS val_seccion, (tipo IS NULL OR tipo = '') AS val_tipo, tipo NOT IN ('Escuela','Oficina gubernamental','Oficina municipal','Central de autobús','Centro comercial','Centro cultural','Centro recreativo','Instalaciones deportivas','Mercado','Plaza o Monumento') as val_tipo_cat, tipo FROM $table_escuela WHERE (entidad IS NULL OR entidad = 0) OR(distrito IS NULL OR distrito = 0) OR (seccion IS NULL OR seccion = 0) OR (tipo IS NULL OR tipo = '') OR LOWER(tipo) NOT IN ('escuela','oficina gubernamental','oficina municipal','central de autobús','centro comercial','centro cultural','centro recreativo','instalaciones deportivas','mercado','plaza','monumento') OR entidad != $e OR distrito != $d OR seccion != $s ORDER BY gid;";
        $query_result = $conn->query($sql_overlaps_geometry);

        $i = 0;
        foreach($query_result as $result){
            $_R['nulos_escuela']['lista'][$i]['gid'] = $this->j_int($result->gid, true);
            $_R['nulos_escuela']['lista'][$i]['entidad'] = $this->j_bool($result->val_entidad, true) ? 1 : ($this->j_bool($result->entidad_distinto, true) ? 1 : 0);
            $_R['nulos_escuela']['lista'][$i]['distrito'] = $this->j_bool($result->val_distrito, true) ? 1 : ($this->j_bool($result->distrito_distinto, true) ? 1 : 0);
            $_R['nulos_escuela']['lista'][$i]['seccion'] = $this->j_bool($result->val_seccion, true) ? 1 : ($this->j_bool($result->seccion_distinto, true) ? 1 : 0);
            $_R['nulos_escuela']['lista'][$i]['detalleEntidad'] = $this->j_int($result->entidad, true);
            $_R['nulos_escuela']['lista'][$i]['detalleDistrito'] = $this->j_int($result->distrito, true);
            $_R['nulos_escuela']['lista'][$i]['detalleSeccion'] = $this->j_int($result->seccion, true);
            $_R['nulos_escuela']['lista'][$i]['tipo'] = $this->j_bool($result->val_tipo, true) ? 1 : ($this->j_bool($result->val_tipo_cat, true) ? 1 : 0);
            $_R['nulos_escuela']['lista'][$i]['detalleTipo'] = $this->j_varchar($result->tipo, true);
            $i++;
        }

        if(count($query_result)){
            $validacion['nulos_escuela'] = 0;
        }else{
            $validacion['nulos_escuela'] = 1;
        }
    }catch(Exception $e){
        $_R['error']['nulos_escuela'] = $e;
    }

    /*----------------------------Comprobar que entidad, distrito y seccion sean los adecuados en escuelas-----------------------------*/
    /*try{
        $_R['otros_escuela']['lista'] = [];
        $sql_overlaps_geometry = "SELECT gid, entidad, distrito, seccion FROM $table_escuela WHERE entidad != $e OR distrito != $d OR seccion != $s;";
        $query_result = $conn->query($sql_overlaps_geometry);

        $i = 0;
        foreach($query_result as $result){
            $_R['otros_escuela']['lista'][$i]['gid'] = $this->j_int($result->gid, true);
            $_R['otros_escuela']['lista'][$i]['entidad'] = $this->j_int($result->entidad, true);
            $_R['otros_escuela']['lista'][$i]['distrito'] = $this->j_int($result->distrito, true);
            $_R['otros_escuela']['lista'][$i]['seccion'] = $this->j_int($result->seccion, true);
            $i++;
        }
    }catch(Exception $e){
        $_R['error']['otros_escuela'] = $e;
    }*/

    $_R['verifica_nombres_pol'] = [];
    $sql_verify_table_pol = "SELECT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = '$schema_temp' and table_name = 'pol_red_inter_mz$seccion_') as table_exists";
    $exists_table = $conn->query($sql_verify_table_pol)[0]->table_exists;
    $_R['verifica_nombres_pol']['table'] = $exists_table == 't';

    //Si existe la tabla, se hacen las validaciones respectivas
    if($exists_table == 't'){
        $validacion['existe_tabla_pol_red'] = 1;
        $sql_verify_field_the_geom = "SELECT NOT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = '$schema_temp' and table_name = 'pol_red_inter_mz$seccion_' and column_name = 'the_geom') as the_geom_exists";
        $not_exists_the_geom = $conn->query($sql_verify_field_the_geom)[0]->the_geom_exists;
        $_R['verifica_nombres_pol']['the_geom'] = $not_exists_the_geom == 't';

        if($not_exists_the_geom == 't'){
            $sql_verify_field_geom = "SELECT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = '$schema_temp' and table_name = 'pol_red_inter_mz$seccion_' and column_name = 'geom') as geom_exists";
            $exists_geom = $conn->query($sql_verify_field_geom)[0]->geom_exists;
            if($exists_geom == 't'){
                $sql_rename_the_geom = "ALTER TABLE $table_pol_red_inter_mz RENAME COLUMN geom TO the_geom;";
                $conn->query($sql_rename_the_geom);
                $_R['verifica_nombres_pol']['check_the_geom'] = true;
                $validacion['existe_tabla_pol_red_campo_geom'] = 1;
            }else{
                $_R['verifica_nombres_pol']['check_the_geom'] = false;
                $validacion['existe_tabla_pol_red_campo_geom'] = 0;
                $validacion['totales'] = 0;
                $validacion['sobreposicion_pol_red'] = 0;
                $validacion['sobreposicion_red_sobre_pol_red'] = 0;
                $validacion['existe_tabla_pol_red_campo_poligono'] = 0;
                $validacion['fraccionamientos'] = 0;
                $validacion['nulos_escuela'] = 0;
                $conn_r->insert('historial_validaciones', $validacion);
                $this->end();
            }
        }
        $validacion['existe_tabla_pol_red_campo_geom'] = 1;

        /*----------------------------Comprobar sobreposicion en pol_red_inter_mz-----------------------------*/
        try{
            $_R['sobreposicion_pol_red']['lista'] = [];
            $sql_overlaps_geometry = "SELECT a.gid as gid_a, b.gid as gid_b, a.manzana as manzana_a, b.manzana as manzana_b, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as geom_a, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom') as geom_b, ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom),4326)) as intersection FROM (SELECT the_geom, gid, manzana FROM $table_pol_red_inter_mz) AS a, (SELECT the_geom, gid, manzana FROM $table_pol_red_inter_mz) AS b WHERE a.manzana != b.manzana AND a.manzana < b.manzana AND (ST_Overlaps(a.the_geom,b.the_geom) OR ST_Contains(b.the_geom, a.the_geom) OR ST_Contains(a.the_geom, b.the_geom)) ORDER BY a.manzana, b.manzana;";
            $query_result = $conn->query($sql_overlaps_geometry);

            $geometries_a = [];
            $geometries_b = [];
            $intersecciones = [];
            $intersecciones_repetidos = [];
            foreach($query_result as $result){
                $gid_a = $this->j_int($result->gid_a, true);
                $manzana_a = $this->j_int($result->manzana_a, true);
                $manzana_b = $this->j_int($result->manzana_b, true);
                $geom_a = $this->j_varchar($result->geom_a, true);
                $geom_b = $this->j_varchar($result->geom_b, true);
                $interseccion = $this->j_varchar($result->intersection, true);

                if(!in_array($geom_a, $geometries_a)){
                    $intersecciones_repetidos[$gid_a]['manzana'] = $manzana_a;
                    $intersecciones_repetidos[$gid_a]['repetidos'] = [$manzana_b];
                    array_push($geometries_a, $geom_a);
                }else{
                    array_push($intersecciones_repetidos[$gid_a], $manzana_b);
                }
                
                if(!in_array($geom_b, $geometries_b))
                    array_push($geometries_b, $geom_b);
                
                if(!in_array($interseccion, $intersecciones))
                    array_push($intersecciones, $interseccion);
                
                /*$_R['sobreposicion_pol_red']['lista'][$i]['geom_a'] = $this->j_varchar($result->geom_a, true);
                $_R['sobreposicion_pol_red']['lista'][$i]['geom_b'] = $this->j_varchar($result->geom_b, true);
                $_R['sobreposicion_pol_red']['lista'][$i]['interseccion'] = $this->j_varchar($result->intersection, true);
                $_R['sobreposicion_pol_red']['lista'][$i]['gid_a'] = $this->j_int($result->gid_a, true);
                $_R['sobreposicion_pol_red']['lista'][$i]['gid_b'] = $this->j_int($result->gid_b, true);
                $_R['sobreposicion_pol_red']['lista'][$i]['manzana_a'] = $this->j_int($result->manzana_a, true);
                $_R['sobreposicion_pol_red']['lista'][$i]['manzana_b'] = $this->j_int($result->manzana_b, true);*/
            }

            if(count($query_result)){
                $i=0;
                foreach($intersecciones_repetidos as $inter){
                    $_R['sobreposicion_pol_red']['lista'][$i]['i'] = $i+1;
                    $_R['sobreposicion_pol_red']['lista'][$i]['manzana'] = $inter['manzana'];
                    $_R['sobreposicion_pol_red']['lista'][$i]['repetidos'] = implode(', ', $inter['repetidos']);
                    $i++;
                }
                $_R['sobreposicion_pol_red']['geometries_a'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries_a).']}';
                $_R['sobreposicion_pol_red']['geometries_b'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries_b).']}';
                $_R['sobreposicion_pol_red']['intersecciones'] = '{"type":"FeatureCollection","features":['.implode(',',$intersecciones).']}';
                $validacion['sobreposicion_pol_red'] = 0;
            }else{
                $validacion['sobreposicion_pol_red'] = 1;
            }

        }catch(Exception $e){
            $_R['error']['sobreposicion_pol_red'] = $e;
        }

        /*----------------------------Comprobar sobreposicion red sobre pol_red_inter_mz-----------------------------*/
        try{
            $_R['sobreposicion_red_pol_red']['lista'] = [];
            $sql_overlaps_geometry = "SELECT a.categoria as categoria, a.gid as gid_a, b.gid as gid_b, b.manzana as manzana, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as geom_a, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(b.the_geom, 4326))::jsonb, 'properties', to_jsonb(b.*) - 'the_geom') as geom_b, jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(ST_Intersection(a.the_geom, b.the_geom), 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as intersection FROM (SELECT the_geom, id, gid, categoria FROM $table_red WHERE categoria IN (1,5)) AS a, 	(SELECT ST_Buffer(the_geom, -0.00001) AS the_geom, gid, manzana FROM $table_pol_red_inter_mz) AS b WHERE ST_Intersects(a.the_geom,b.the_geom) ORDER BY gid_a;";
            $query_result = $conn->query($sql_overlaps_geometry);

            $geometries_a = [];
            $geometries_b = [];
            $intersecciones = [];
            $interseccion_repetidos = [];
            foreach($query_result as $result){
                $gid_a =  $this->j_int($result->gid_a, true);
                $manzana_b = $this->j_int($result->manzana, true);
                $geom_a = $this->j_varchar($result->geom_a, true);
                $geom_b = $this->j_varchar($result->geom_b, true);
                $interseccion = $this->j_varchar($result->intersection, true);
                $categoria = $this->j_int($result->categoria, true);

                if(!in_array($geom_a, $geometries_a)){
                    $interseccion_repetidos[$gid_a]['gid'] = $gid_a;
                    $interseccion_repetidos[$gid_a]['categoria'] = $categoria;
                    $interseccion_repetidos[$gid_a]['repetidos'] = [$manzana_b];
                    array_push($geometries_a, $geom_a);
                }else{
                    array_push($interseccion_repetidos[$gid_a]['repetidos'], $manzana_b);
                }
                
                if(!in_array($geom_b, $geometries_b))
                    array_push($geometries_b, $geom_b);
                
                if(!in_array($interseccion, $intersecciones))
                    array_push($intersecciones, $interseccion);
                
                /*$_R['sobreposicion_red_pol_red']['lista'][$i]['geom_a'] = $this->j_varchar($result->geom_a, true);
                $_R['sobreposicion_red_pol_red']['lista'][$i]['geom_b'] = $this->j_varchar($result->geom_b, true);
                $_R['sobreposicion_red_pol_red']['lista'][$i]['interseccion'] = $this->j_varchar($result->intersection, true);*/
                /*$_R['sobreposicion_red_pol_red']['lista'][$i]['gid_a'] = $this->j_int($result->gid_a, true);
                $_R['sobreposicion_red_pol_red']['lista'][$i]['gid_b'] = $this->j_int($result->gid_b, true);
                $_R['sobreposicion_red_pol_red']['lista'][$i]['manzana'] = $this->j_int($result->manzana, true);*/
            }

            if(count($query_result)){
                $i=0;
                foreach($interseccion_repetidos as $inter){
                    $_R['sobreposicion_red_pol_red']['lista'][$i]['i'] = $i+1;
                    $_R['sobreposicion_red_pol_red']['lista'][$i]['gid'] = $inter['gid'];
                    $_R['sobreposicion_red_pol_red']['lista'][$i]['categoria'] = $inter['categoria'];
                    $_R['sobreposicion_red_pol_red']['lista'][$i]['repetidos'] = implode(', ', $inter['repetidos']);
                    $i++;
                }
                $_R['sobreposicion_red_pol_red']['geometries_a'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries_a).']}';
                $_R['sobreposicion_red_pol_red']['geometries_b'] = '{"type":"FeatureCollection","features":['.implode(',',$geometries_b).']}';
                $_R['sobreposicion_red_pol_red']['intersecciones'] = '{"type":"FeatureCollection","features":['.implode(',',$intersecciones).']}';
                $validacion['sobreposicion_red_sobre_pol_red'] = 0;
            }else{
                $validacion['sobreposicion_red_sobre_pol_red'] = 1;
            }

        }catch(Exception $e){
            $_R['error']['sobreposicion_red_pol_red'] = $e;
        }

        /*----------------------------Comprobar total manzanas vs total poligonos-----------------------------*/
        try{
            $_R['total_pol_mz']['cumple'] = 1;
            /* Poligonos duplicados */
            $get_duplicados_poligonos = "SELECT count(*), mz.localidad, mz.manzana FROM $table_pol_red_inter_mz pol LEFT JOIN $table_mz_reseccionamiento mz ON pol.localidad = mz.localidad AND pol.manzana = mz.manzana GROUP BY mz.localidad, mz.manzana HAVING count(*) > 1 ORDER BY mz.localidad, mz.manzana;";
            $total_poligonos_duplicados = $conn->query($get_duplicados_poligonos);
            
            if(count($total_poligonos_duplicados)){
                $_R['total_pol_mz']['cumple'] = 0;
                $_R['total_pol_mz']['tipo'] = 0;
                $_R['total_pol_mz']['manzanas'] = [];
                $i=1;
                foreach($total_poligonos_duplicados as $poligono){
                    $duplicado = [];
                    $duplicado['localidad'] = isset($poligono->localidad) ? $poligono->localidad : 'null';
                    $duplicado['manzana'] = isset($poligono->manzana) ? $poligono->manzana : 'null';
                    $duplicado['i'] = $i++;
                    array_push($_R['total_pol_mz']['manzanas'], $duplicado);
                }
                $validacion['totales'] = 0;
            }

            /* Falta poligonos */
            $get_falta_poligonos = "SELECT mz.manzana, mz.localidad FROM $table_pol_red_inter_mz pol RIGHT JOIN $table_mz_reseccionamiento mz ON pol.localidad = mz.localidad AND pol.manzana = mz.manzana WHERE pol.localidad IS NULL ORDER BY mz.manzana;";
            $total_poligonos_faltantes = $conn->query($get_falta_poligonos);
            
            if(count($total_poligonos_faltantes)){
                $_R['total_pol_mz']['cumple'] = 0;
                $_R['total_pol_mz']['tipo'] = 1;
                $_R['total_pol_mz']['manzanas'] = [];
                $i=1;
                foreach($total_poligonos_faltantes as $poligono){
                    $duplicado = [];
                    $duplicado['localidad'] = isset($poligono->localidad) ? $poligono->localidad : 'null';
                    $duplicado['manzana'] = isset($poligono->manzana) ? $poligono->manzana : 'null';
                    $duplicado['i'] = $i++;
                    array_push($_R['total_pol_mz']['manzanas'], $duplicado);
                }
                $validacion['totales'] = 0;
            }else{
                /* Falta manzanas */
                $get_falta_manzanas = "SELECT pol.manzana, pol.localidad FROM $table_pol_red_inter_mz pol LEFT JOIN $table_mz_reseccionamiento mz ON pol.localidad = mz.localidad AND pol.manzana = mz.manzana WHERE mz.localidad IS NULL ORDER BY pol.manzana";
                $total_manzanas_faltantes = $conn->query($get_falta_manzanas);
                
                if(count($total_manzanas_faltantes)){
                    $_R['total_pol_mz']['cumple'] = 0;
                    $_R['total_pol_mz']['tipo'] = 2;
                    $_R['total_pol_mz']['manzanas'] = [];
                    $i=1;
                    foreach($total_manzanas_faltantes as $poligono){
                        $duplicado = [];
                        $duplicado['localidad'] = isset($poligono->localidad) ? $poligono->localidad : 'null';
                        $duplicado['manzana'] = isset($poligono->manzana) ? $poligono->manzana : 'null';
                        $duplicado['i'] = $i++;
                        array_push($_R['total_pol_mz']['manzanas'], $duplicado);
                    }
                    $validacion['totales'] = 0;
                }
            }

            $validacion['totales'] = $_R['total_pol_mz']['cumple'];
        }catch(Exception $e){
            $_R['error']['total_pol_mz'] = $e;
        }

        /*----------------------------Comprobar columna poligono_ sobre pol_red_inter_mz-----------------------------*/
        $sql_verify_field_the_geom = "SELECT NOT EXISTS(SELECT column_name FROM information_schema.columns WHERE table_schema = '$schema_temp' and table_name = 'pol_red_inter_mz$seccion_' and column_name = 'poligono_') as the_geom_exists";
        $not_exists_the_geom = $conn->query($sql_verify_field_the_geom)[0]->the_geom_exists;
        $_R['verifica_nombres_pol']['poligono'] = $not_exists_the_geom == 't';

        if($not_exists_the_geom == 't'){
            $validacion['existe_tabla_pol_red_campo_poligono'] = 0;
            $validacion['fraccionamientos'] = 0;
            $conn_r->insert('historial_validaciones', $validacion);
            $this->end();
        }else{
            $validacion['existe_tabla_pol_red_campo_poligono'] = 1;
        }

        /*----------------------------Comprobar fraccionamientos-----------------------------*/
        try{
            $_R['fraccionamientos']['lista'] = [];
            $get_poligonos = "SELECT poligono_ AS poligono, COUNT(*) AS total FROM $table_pol_red_inter_mz WHERE poligono_ IS NOT NULL GROUP BY poligono_ ORDER BY poligono_;";
            $query_result = $conn->query($get_poligonos);

            $poligonos = [];
            foreach($query_result as $result){
                $poligono =  $this->j_int($result->poligono, true);
                $total =  $this->j_int($result->total, true);
                array_push($poligonos, ['poligono'=>$poligono, 'total'=>$total]);
            }

            $get_poligonos_red_1_5 = "SELECT (ST_Dump(ST_Polygonize(the_geom))).geom as the_geom FROM (SELECT ST_Union(the_geom) as the_geom FROM $table_red WHERE categoria IN (1,5)) as a;";
            $query_result = $conn->query($get_poligonos_red_1_5);

            $sin_repetir = [];
            $manzana_pol_red = [];
            $bad_poligonos = [];

            $j = 1;
            $poligonos_red = [];
            foreach($query_result as $result){
                $poligono_red_1_5 = $conn->to_varchar($result->the_geom, true);
                /*Verificamos cuantos poligonos contiene el poligono_red de categoria 1 y 5*/
                $get_contains_manzanas_in_red = "SELECT count(*) as total FROM $table_pol_red_inter_mz WHERE ST_Contains($poligono_red_1_5, ST_Buffer(the_geom, -0.00001));";
                $query_total = $conn->query($get_contains_manzanas_in_red);
                $total_contenidos = $this->j_int($query_total[0]->total, true);
                array_push($poligonos_red, ['the_geom'=>$poligono_red_1_5, 'total_contenidos'=>$total_contenidos]);
            }

            $_R['contadores'] = [];
            foreach($poligonos as $poligon){
                $poligono = $poligon['poligono'];
                $total_poligonos = $poligon['total'];
                $counter = 0;
                foreach($poligonos_red as $poligon_red){
                    $poligono_red_1_5 = $poligon_red['the_geom'];
                    $total_contenidos = $poligon_red['total_contenidos'];
                    
                    //Obtenemos si todos los poligonos_ con el mismo identificador están dentro de un mismo poligono_red con categoria 1 y 5
                    $get_contencion_poligonos = "SELECT count(*) as total FROM $table_pol_red_inter_mz WHERE ST_Contains($poligono_red_1_5, ST_Buffer(the_geom, -0.00001)) AND poligono_ = $poligono;";
                    $query_result2 = $conn->query($get_contencion_poligonos);
            
                    $total_contenidos_mismo_id = $this->j_int($query_result2[0]->total, true);
                    if($total_contenidos_mismo_id != 0){
                        if($total_contenidos != $total_contenidos_mismo_id || ($total_contenidos == $total_contenidos_mismo_id && $total_contenidos != $total_poligonos) ){
                            if(!in_array($poligono, $sin_repetir)){
                                array_push($sin_repetir, $poligono);
                                array_push($bad_poligonos, ['i'=>$j++, 'poligono'=>$poligono]);
                                $get_bad_poligonos = "SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as the_geom FROM $table_pol_red_inter_mz as a WHERE poligono_ = $poligono;";
                                $query_result2 = $conn->query($get_bad_poligonos);
                                foreach($query_result2 as $poligono2){
                                    array_push($manzana_pol_red, $poligono2->the_geom);
                                }
                            }
                        }
                    }else{
                        $counter++;
                    }
                }

                if($counter == count($poligonos_red)){
                    array_push($sin_repetir, $poligono);
                    array_push($bad_poligonos, ['i'=>$j++, 'poligono'=>$poligono]);
                    $get_bad_poligonos = "SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as the_geom FROM $table_pol_red_inter_mz as a WHERE poligono_ = $poligono;";
                    $query_result2 = $conn->query($get_bad_poligonos);
                    foreach($query_result2 as $poligono2){
                        array_push($manzana_pol_red, $poligono2->the_geom);
                    }
                }
            }
            

            //$_R['poligonos'] = $bad_poligonos;
            $get_toda_red_1_5 = "SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as the_geom FROM $table_red as a WHERE categoria IN (1,5);";
            $query_result = $conn->query($get_toda_red_1_5);
            $redes = [];
            foreach($query_result as $red){
                array_push($redes, $red->the_geom);
            }
            if(count($redes))
                $_R['fraccionamientos']['red15'] = '{"type":"FeatureCollection","features":['.implode(',',$redes).']}';
            else
                $_R['fraccionamientos']['red15'] = null;
            
            if(count($bad_poligonos)){
                $get_red_1_5 = "SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as the_geom FROM $table_red as a WHERE categoria IN (1,5);";
                $query_result = $conn->query($get_red_1_5);
                $redes = [];
                foreach($query_result as $red){
                    array_push($redes, $red->the_geom);
                }
                $_R['fraccionamientos']['lista'] = $bad_poligonos;
                $_R['fraccionamientos']['red'] = '{"type":"FeatureCollection","features":['.implode(',',$redes).']}';
                $_R['fraccionamientos']['poligonos'] = '{"type":"FeatureCollection","features":['.implode(',',$manzana_pol_red).']}';
                $validacion['fraccionamientos'] = 0;
            }else{
                $validacion['fraccionamientos'] = 1;
            }

            $get_todo_pol_red= "SELECT jsonb_build_object('type','Feature','geometry', ST_AsGeoJSON(ST_Transform(a.the_geom, 4326))::jsonb, 'properties', to_jsonb(a.*) - 'the_geom') as the_geom FROM $table_pol_red_inter_mz as a;";
            $query_result = $conn->query($get_todo_pol_red);
            $pol_red = [];
            foreach($query_result as $pol){
                array_push($pol_red, $pol->the_geom);
            }
            $_R['pol_red_inter_mz'] = '{"type":"FeatureCollection","features":['.implode(',',$pol_red).']}';

        }catch(Exception $e){
            $_R['error']['fraccionamientos'] = $e;
        }

        
    }else{
        $validacion['existe_tabla_pol_red'] = 0;
        $validacion['existe_tabla_pol_red_campo_geom'] = 0;
        $validacion['totales'] = 0;
        $validacion['sobreposicion_pol_red'] = 0;
        $validacion['sobreposicion_red_sobre_pol_red'] = 0;
        $validacion['existe_tabla_pol_red_campo_poligono'] = 0;
        $validacion['fraccionamientos'] = 0;
        $validacion['nulos_escuela'] = 0;
    }
}

try{
    $conn_r->insert('historial_validaciones', $validacion);
}catch(Exception $e){
    var_dump($e);
}

