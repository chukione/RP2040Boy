const functions = require('firebase-functions');
const express = require('express');
const helmet = require('helmet');
const api = express();
const cors = require('cors');
const { searchAPI } = require('./search/index');
const { checkGeomAPI } = require('./checkGeom/index');

const { pdfAPI } = require('./pdf/index');

const { deletePoligonosRedAPI } = require('./delete/index');

api.use(
  helmet.hsts({ maxAge: 63072000, includeSubDomains: true, preload: true })
);
api.use(cors({ origin: '*', methods: ['GET', 'POST', 'OPTIONS'] }));
api.use(express.json());
api.use(express.urlencoded({ extended: true }));

api.use('/search', searchAPI);
api.use('/pdf', pdfAPI);
api.use('/checkGeom', checkGeomAPI);
api.use('/delete', deletePoligonosRedAPI);

//* default
api.all('*', (req, res) =>
  res
    .setHeader(
      'Strict-Transport-Security',
      'max-age=31536000; includeSubDomains; preload'
    )
    .json({ status: true, data: `Validación - Reseccionamiento API V1.0.0` })
);

exports.api = functions.https.onRequest(api);
