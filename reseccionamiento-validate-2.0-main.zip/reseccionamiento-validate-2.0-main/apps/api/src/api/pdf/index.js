const express = require('express');
const pdfAPI = express();

const { getBuildPdf } = require('./buildPdf');

pdfAPI.get('/generate', getBuildPdf);

pdfAPI.all('*', (req, res) => {
  res
    .setHeader(
      'Strict-Transport-Security',
      'max-age=31536000; includeSubDomains; preload'
    )
    .status(404)
    .json({
      message: 'API Validación - Reseccionamiento (PDF): Recurso no encontrado',
    });
});

exports.pdfAPI = pdfAPI;
