// const PDFDocument = require('pdfkit');
const PDFDocument = require('pdfkit-table');
const { getConn, getQuery } = require('./../../services/sql');
const { validateParams, handleError } = require('./../../services/common');
const { logger } = require('firebase-functions');
const path = require('path');
const goverments = require('./../../services/goverments');

const pool = getConn('reseccionamiento2024');

exports.getBuildPdf = async (req, res) => {
  logger.info(`Build PDF ${req.originalUrl}`);
  const e = Number(req.query.e);
  const d = Number(req.query.d);
  let s = Number(req.query.s);
  let entidad = req.query.e.toString().length === 1 ? '0' + e : e;
  let distrito = req.query.d.toString().length === 1 ? '0' + d : d;
  let seccion;
  s = parseInt(s, 10);
  if (s < 10) {
    seccion = '000' + s;
  } else if (s < 100) {
    seccion = '00' + s;
  } else if (s < 1000) {
    seccion = '0' + s;
  } else {
    seccion = s;
  }
  const payload = { entidad, distrito, seccion, e };
  const stream = res.writeHead(200, {
    'Content-Type': 'application/pdf',
    'Content-Disposition': 'attachment; filename=ReporteValidaciones.pdf',
  });
  buildPDF(
    payload,
    (data) => stream.write(data),
    () => stream.end()
  );
};

async function buildPDF(payload, dataCallback, endCallback) {
  const doc = new PDFDocument({ layout: 'landscape', size: 'LEGAL' });
  doc.on('data', dataCallback);
  doc.on('end', endCallback);
  //* header
  doc.rect(0, 0, doc.page.width, doc.page.height).fill('#252756');
  const imagePath = path.join(__dirname, 'public', 'img', 'ine.png'); // Ruta a tu imagen
  doc.image(imagePath, 40, 15, { width: 80 });
  doc
    .fontSize(14)
    .fill('#FFFFFF')
    .text('Sistema de Validación - Reseccionamiento 2024', 200, 20);
  //* body
  doc.rect(0, 50, doc.page.width, 500).fill('#FFFFFF');
  //*Title
  const fontSize = 14;
  const texto = 'REPORTE DE VALIDACIONES';
  const posY = 60;
  const textWidth = doc.widthOfString(texto);
  const posX = (doc.page.width - textWidth) / 2;
  doc
    .fontSize(fontSize)
    .fill('#512f73')
    .font('Helvetica-Bold')
    .text(texto, posX, posY);
  //* Table Entidad - Distrito - Seccion
  const restReport = await getStages(payload);
  console.log('$$$$', restReport);
  const currentDate = new Date().toLocaleString('es-MX', {
    timeZone: 'America/Mexico_City',
  });
  const validateColors = (
    value,
    indexColumn,
    indexRow,
    row,
    rectRow,
    rectCell
  ) => {
    const { x, y, width, height } = rectCell;
    if (!value) {
      const text = 'X';
      const textWidth = doc.widthOfString(text);
      const textHeight = doc.heightOfString(text);
      const centerX = x + (width - textWidth) / 2;
      const centerY = y + (height - textHeight) / 2;
      doc.fillColor('red');
      doc.text(text, centerX, centerY, {
        width: width,
        height: height,
        align: 'left',
      });
    } else {
      const text = 'OK';
      const textWidth = doc.widthOfString(text);
      const textHeight = doc.heightOfString(text);
      const centerX = x + (width - textWidth) / 2;
      const centerY = y + (height - textHeight) / 2;
      doc.fillColor('green');
      doc.text(text, centerX, centerY, {
        width: width,
        height: height,
        align: 'left',
      });
    }
  };
  const table = {
    headers: [
      { label: 'Entidad', property: 'entidadx', width: 100, renderer: null },
      {
        label: 'Distrito',
        property: 'distritox',
        width: 60,
        renderer: null,
      },
      { label: 'Sección', property: 'seccionx', width: 60, renderer: null },
      {
        label: 'Geometría',
        property: 'geometriax',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Poligonos Red',
        property: 'polredx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Pol Red Inter Mz',
        property: 'polredintermzx',
        width: 80,
        renderer: validateColors,
      },
      { label: 'Fecha', property: 'fechax', width: 100, renderer: null },
    ],
    rows: [
      [
        goverments[payload.e].name,
        payload.distrito,
        payload.seccion,
        restReport.attended_one,
        restReport.attended_two,
        restReport.attended_three,
        currentDate,
      ],
      // [...],
    ],
  };
  await doc.table(table, {
    width: 3000,
    x: 40,
    y: 90,
  });
  //* Table Geometria red
  //*Title
  const fontSizeGeom = 14;
  const textoGeom = 'GEOMETRÍA';
  const posYGeom = 128;
  const textWidthGeom = doc.widthOfString(textoGeom);
  const posXGeom = (doc.page.width - textWidthGeom) / 2;
  doc
    .fontSize(fontSizeGeom)
    .fill('#512f73')
    .font('Helvetica-Bold')
    .text(textoGeom, 60, posYGeom);
  //*
  const parseoStageOne = JSON.parse(restReport.logbook_one_last);
  const tableX = {
    headers: [
      {
        label: 'Red Invalidas',
        property: 'Redinvalidasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Red Nulas',
        property: 'Rednulasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Red Duplicadas',
        property: 'Redduplicadasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Red Nodos Duplicados',
        property: 'Redduplicadasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Mz_R Invalidas/Nulas',
        property: 'mxnulasx',
        width: 100,
        renderer: validateColors,
      },
      {
        label: 'Mz_R Red Mz',
        property: 'mzredmz',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Mz_R Mz',
        property: 'mzresecmz',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Red Categoría',
        property: 'redcatgeria',
        width: 60,
        renderer: validateColors,
      },
    ],
    rows: [
      [
        parseoStageOne?.geometriaRedInvalidas,
        parseoStageOne?.geometriaRedNull,
        parseoStageOne?.redesDuplicadas,
        parseoStageOne?.nodosDuplicadosRed,
        parseoStageOne?.geometriaMz,
        parseoStageOne?.sobreposicionRedSobreMz,
        parseoStageOne?.sobreposicionMz,
        parseoStageOne?.categoriaRed,
      ],
      // [...],
    ],
  };
  doc.table(tableX, {
    width: 2000,
    x: 40,
    y: 150,
  });
  //* Table Poligonos red
  //*Title
  const fontSizeRed = 14;
  const textoRed = 'POLÍGONOS RED';
  const posYRed = 200;
  const textWidthRed = doc.widthOfString(textoRed);
  const posXRed = (doc.page.width - textWidthRed) / 2;
  doc
    .fontSize(fontSizeRed)
    .fill('#512f73')
    .font('Helvetica-Bold')
    .text(textoRed, 60, posYRed);
  //*
  const parseoStageTwo = JSON.parse(restReport.logbook_two_last);
  const tableZ = {
    headers: [
      {
        label: 'Red Invalidas',
        property: 'Redinvalidasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Red Nulas',
        property: 'Rednulasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Red Duplicadas',
        property: 'Redduplicadasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Red Nodos Duplicados',
        property: 'Redduplicadasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Mz_R Inva/Nul',
        property: 'mxnulasx',
        width: 100,
        renderer: validateColors,
      },
      {
        label: 'Mz_R Dupli',
        property: 'mzDuplex',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Sobre Red',
        property: 'sobreposicionred',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Mz sin Pol.',
        property: 'mzsinpol',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Mz Inters Pol.',
        property: 'mzinterspol',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Pol c/ + Mz',
        property: 'mzmasmz',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Pol sin Mz',
        property: 'polsinmz',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Mz Captura',
        property: 'mzcaptura',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Mz Datos Dup',
        property: 'mzdsup',
        width: 60,
        renderer: validateColors,
      },
    ],
    rows: [
      [
        parseoStageTwo?.geometriaRedInvalidas,
        parseoStageTwo?.geometriaRedNull,
        parseoStageTwo?.redesDuplicadas,
        parseoStageTwo?.nodosDuplicadosRed,
        parseoStageTwo?.validarMzasNulas,
        parseoStageTwo?.validarMzasDuplicadas,
        parseoStageTwo?.sobreposicionGeom,
        parseoStageTwo?.validarMzaSinPoligonos,
        parseoStageTwo?.validarMzaInterPoligonos,
        parseoStageTwo?.validarPoligonosMza, // pending
        parseoStageTwo?.validarPoligonosSinMza,
        parseoStageTwo?.validarMzaSinPoligonos, // pending
        parseoStageTwo?.validarMzasOtrosDatos,
      ],
      // [...],
    ],
  };
  doc.table(tableZ, {
    width: 2000,
    x: 40,
    y: 220,
  });
  //* Table Pol Red Inter Mz
  //*Title
  const fontSizePolRedInter = 14;
  const textoPolRedInter = 'POL RED INTER MZ';
  const posYPolRedInter = 270;
  const textWidthPolRedInter = doc.widthOfString(textoPolRedInter);
  const posXPolRedInter = (doc.page.width - textWidthPolRedInter) / 2;
  doc
    .fontSize(fontSizePolRedInter)
    .fill('#512f73')
    .font('Helvetica-Bold')
    .text(textoPolRedInter, 60, posYPolRedInter);
  //*

  const parseoStageThree = JSON.parse(restReport.logbook_three_last);
  const tableY = {
    headers: [
      {
        label: 'Red Invalidas',
        property: 'Redinvalidasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Red Nulas',
        property: 'Rednulasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Manzanas con otros datos',
        property: 'geometriaMz',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Red Duplicadas',
        property: 'Redduplicadasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Red Nodos Duplicados',
        property: 'Redduplicadasx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Totales de Pol Red Inter Mz',
        property: 'polredintermzx',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Sobreposicion de Pol Red Inter Mz',
        property: 'respolredintermz',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Sobreposicion de Red Pol Red Inter Mz',
        property: 'respolredintermz',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Fraccionamientos',
        property: 'fraccionamientos',
        width: 80,
        renderer: validateColors,
      },
      {
        label: 'Inconsistencias de Escuela',
        property: 'escuela',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Manzanas Duplicadas Pol Red Inter MZ',
        property: 'ManzanaDuplicada',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Manzanas Faltantes en Resecc',
        property: 'ManzanaResseccionamientoFalt',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Manzanas Faltantes en Pol Red',
        property: 'ManzanaPolRedFalt',
        width: 60,
        renderer: validateColors,
      },
    ],
    rows: [
      [
        parseoStageThree?.geometriaRedInvalidas,
        parseoStageThree?.geometriaRedNull,
        parseoStageThree?.geometriaMz,
        parseoStageThree?.redesDuplicadas,
        parseoStageThree?.nodosDuplicadosRed,
        parseoStageThree?.totales,
        parseoStageThree?.sobreposicionPolRed,
        parseoStageThree?.sobreposicionRedSobrePolRed,
        parseoStageThree?.fraccionamientos,
        parseoStageThree?.nulosEscuela,
        parseoStageThree?.duplicatedManzanas,
        parseoStageThree?.mzReseccionamientoFaltantes,
        parseoStageThree?.mzPolRedFaltantes,
      ],
      // [...],
    ],
  };
  doc.table(tableY, {
    width: 2000,
    x: 40,
    y: 290,
  });

  //* Table Pol Red Inter Mz
  //*Title
  const fontSizePolRedInterC = 14;
  const textoPolRedInterC = ' ';
  const posYPolRedInterC = 310;
  const textWidthPolRedInterC = doc.widthOfString(textoPolRedInterC);
  const posXPolRedInterC = (doc.page.width - textWidthPolRedInterC) / 2;
  doc
    .fontSize(fontSizePolRedInterC)
    .fill('#512f73')
    .font('Helvetica-Bold')
    .text(textoPolRedInterC, 60, posYPolRedInterC);
  //*

  const parseoStageThreeC = JSON.parse(restReport.logbook_three_last);
  const tableYC = {
    headers: [
      {
        label: 'Inconsistencias en Manzanas Alteradas',
        property: 'manzanasAlteradas',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Inconsistencias en Manzana Geometria Alterada',
        property: 'manzanaAlteradaGeometria',
        width: 60,
        renderer: validateColors,
      },
      {
        label: 'Inconsistencias en Manzanas Alteradas Pol',
        property: 'manzanasAlteradasPol',
        width: 60,
        renderer: validateColors,
      },
    ],
    rows: [
      [
        parseoStageThreeC?.manzanasAlteradas,
        parseoStageThreeC?.manzanaAlteradaGeometria,
        parseoStageThreeC?.manzanasAlteradasPol,
      ],
      // [...],
    ],
  };
  doc.table(tableYC, {
    width: 2000,
    x: 40,
    y: 360,
  });

  doc.end();
}

async function getStages(payload) {
  try {
    const pool2 = getConn('reseccionamientoBitacora');
    const id = `${payload.entidad}${payload.distrito}${payload.seccion}`;
    const queryReportGeometry = `SELECT id,
    attended_one,
    attended_two,
    attended_three,
    logbook_one->>(jsonb_array_length(logbook_one) - 1) AS logbook_one_last,
    logbook_two->>(jsonb_array_length(logbook_two) - 1) AS logbook_two_last,
    logbook_three->>(jsonb_array_length(logbook_three) - 1) AS logbook_three_last,
    entidad,
    distrito_federal,
    seccion,
    current_date_val
    FROM public.reporte2024 WHERE id=$1;`;
    const resValidateReport = await getQuery(pool2, queryReportGeometry, [id]);
    if (resValidateReport.rowCount > 0) {
      return resValidateReport.rows[0];
    }
  } catch (error) {
    console.log(error);
  }
}
