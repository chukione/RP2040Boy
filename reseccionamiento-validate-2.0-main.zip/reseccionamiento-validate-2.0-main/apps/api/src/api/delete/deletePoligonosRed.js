const { getConn, getQuery } = require('../../services/sql');
const { validateParams, handleError } = require('../../services/common');
const { logger } = require('firebase-functions');

const pool = getConn('reseccionamiento2024');

exports.deletePoligonosRed = async (req, res) => {
  logger.info(`deletePoligonosRed ${req.originalUrl}`);
  try {
    const response = await validateParams(req, {
      body: 'query',
      methods: ['get'],
      optional: ['e', 'd', 's'],
    });
    if (!response.status) {
      return handleError(req, res, response.message);
    }
    //* validamos entidad
    if (req.query.e !== undefined && req.query.e !== null) {
      if (isNaN(req.query.e)) {
        return handleError(req, res, '-entidad- debe ser un número');
      }
      const entidad = parseInt(req.query.e);
      if (!(entidad > 0 && entidad <= 32)) {
        return handleError(req, res, '-entidad- debe ser un valor de 1 a 32');
      }
      req.query.e = parseInt(req.query.e);
    } else {
      return handleError(
        req,
        res,
        '-entidad- es null o indefinido y debe ser un número'
      );
    }
    //* validamos distrito
    if (req.query.d !== undefined && req.query.d !== null) {
      if (isNaN(req.query.d)) {
        return handleError(req, res, '-distrito- debe ser un número');
      }
      const distrito = parseInt(req.query.d);
      if (!(distrito >= 1 && distrito <= 300)) {
        return handleError(req, res, '-distrito- debe ser un valor de 1 a 300');
      }
      req.query.d = parseInt(req.query.d);
    } else {
      return handleError(
        req,
        res,
        '-distrito- es null o indefinido y debe ser un número'
      );
    }

    //* validamos seccion
    if (req.query.s !== undefined && req.query.s !== null) {
      if (isNaN(req.query.s)) {
        return handleError(req, res, '-seccion- debe ser un número');
      }
      if (req.query.s.length > 4) {
        return handleError(req, res, '-seccion- debe contener hasta 4 cifras');
      }
      const seccion = parseInt(req.query.s);
      if (!(seccion > 0)) {
        return handleError(req, res, '-seccion- debe ser un valor mayor a 0');
      }
      req.query.s = parseInt(req.query.s);
    } else {
      return handleError(
        req,
        res,
        '-sección- es null o indefinido y debe ser un número'
      );
    }
    //* validamos etapa
    // if (req.query.et !== undefined && req.query.et !== null) {
    //   if (isNaN(req.query.et)) {
    //     return handleError(req, res, '-etapa- debe ser un número');
    //   }
    //   const etapa = parseInt(req.query.et);
    //   if (!(etapa >= 1 && etapa <= 3)) {
    //     return handleError(req, res, '-etapa- debe ser un valor de 1 a 3');
    //   }
    //   req.query.et = parseInt(req.query.et);
    // } else {
    //   return handleError(
    //     req,
    //     res,
    //     '-eatapa- es null o indefinido y debe ser un número'
    //   );
    // }

    const e = Number(req.query.e);
    const d = Number(req.query.d);
    // const se = Number(req.query.s);
    let s = Number(req.query.s);
    let entidad = req.query.e.toString().length === 1 ? '0' + e : e;
    let distrito = req.query.d.toString().length === 1 ? '0' + d : d;
    let seccion;
    s = parseInt(s, 10);
    if (s < 10) {
      seccion = '000' + s;
    } else if (s < 100) {
      seccion = '00' + s;
    } else if (s < 1000) {
      seccion = '0' + s;
    } else {
      seccion = s;
    }
    //* variables schemas
    const schema = `${entidad}dto${distrito}`;
    const tablePoligonosRed = `"${schema}"."poligonos_red${seccion}"`;

    // Borrar Tabla
    const deletePoligonosRed = `DROP table ${tablePoligonosRed}`;
    const resdeletedPoligonosRed = await getQuery(pool, deletePoligonosRed, []);

    res
      .setHeader(
        'Strict-Transport-Security',
        'max-age=31536000; includeSubDomains; preload'
      )
      .json({
        code: '02',
        data: {
          resdeletedPoligonosRed,
        },
      });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
