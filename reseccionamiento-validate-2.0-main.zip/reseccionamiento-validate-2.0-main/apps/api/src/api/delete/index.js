const express = require('express');
const deletePoligonosRedAPI = express();
const { deletePoligonosRed } = require('./deletePoligonosRed');

deletePoligonosRedAPI.get('/deletePoligonosRed', deletePoligonosRed);

deletePoligonosRedAPI.all('*', (req, res) => {
  res
    .setHeader(
      'Strict-Transport-Security',
      'max-age=31536000; includeSubDomains; preload'
    )
    .status(404)
    .json({
      message:
        'API Validación Check geometry - Reseccionamiento: Recurso no encontrado',
    });
});

exports.deletePoligonosRedAPI = deletePoligonosRedAPI;
