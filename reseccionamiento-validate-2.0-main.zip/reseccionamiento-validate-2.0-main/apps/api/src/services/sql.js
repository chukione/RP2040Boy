const pg = require('pg');
const functions = require('firebase-functions');
const { readFileSync } = require('fs');
require('dotenv').config();

exports.getConn = function (database) {
  const isDev = process.env.DCE_ENVIRONMENT === 'developer';
  const conn = functions.config().connvalidate
    ? functions.config().connvalidate
    : JSON.parse(process.env.DB_CONN || '{}');
  conn['database'] = database;
  conn['max'] = 1;
  if (!isDev) {
    //* Production Conection Config
    const GCP = conn['gcp'];
    conn[
      'host'
    ] = `/cloudsql/${GCP['project']}:${GCP['region']}:${GCP['instance']}`;
    delete conn['ssl'];
  } else {
    //* Developer Conection Config
    conn['ssl'] = {
      rejectUnauthorized: false,
      ca: readFileSync(conn.CA, 'utf-8'),
      key: readFileSync(conn.KEY, 'utf-8'),
      cert: readFileSync(conn.CERT, 'utf-8'),
    };
    delete conn['KEY'];
    delete conn['CA'];
    delete conn['CERT'];
    delete conn['GCP'];
  }
  return new pg.Pool(conn);
};
exports.getQuery = async function (pool, sentencia, values) {
  var result = await pool.query({
    text: sentencia,
    values,
  });
  return result;
};

exports.executeOnTransaction = async function (pool, commands) {
  try {
    await pool.query('BEGIN');
    for (const query of commands) {
      await pool.query(query);
    }
    await pool.query('COMMIT');
    return { status: true };
  } catch (error) {
    console.error(error);
    await pool.query('ROLLBACK');
    return { status: false, error };
  }
};
