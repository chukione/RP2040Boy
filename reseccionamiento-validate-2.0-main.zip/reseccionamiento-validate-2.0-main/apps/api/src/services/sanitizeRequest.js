exports.sanitize = function (values) {
  const reGex = /^([a-z])+$/;
  const validate = reGex.test(values);
  if (validate && values.length === 14) {
    return values;
  }
  return '';
};

exports.sanitizeVersion = function (values) {
  const reGex = /^([0-9])+$/;
  const validate = reGex.test(values);
  if (validate && values.length < 5) {
    return values;
  }
  return '';
};
