exports.padStart = function (val, length, fill) {
  return `${val}`.padStart(length, fill);
};
