const admin = require('firebase-admin');

//* auth
const auth = admin.auth();
exports.auth = auth;

//* firestore
const db = admin.firestore();
exports.db = db;
exports.FieldPath = admin.firestore.FieldPath;
exports.FieldValue = admin.firestore.FieldValue;
exports.Timestamp = admin.firestore.Timestamp;
exports.Transaction = admin.firestore.Transaction;

//* storage
const storage = admin.storage();
exports.storage = storage;

const customBucket = storage.bucket(); // TODO: custom bucket "storage.bucket('custom-name')""
exports.bucket = customBucket;
