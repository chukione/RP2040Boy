const { validate } = require('./../services/validate');
const { logger } = require('firebase-functions');

exports.validateParams = (req, options) => {
  const res = { status: false };
  const settings = Object.assign(
    { methods: ['post'], body: 'body', params: [], optional: [] },
    options
  );
  // - methods
  if (!settings.methods.includes(req.method.toLowerCase())) {
    return { ...res, message: 'Método de solicitud incorrecto.' };
  }
  // - valid params
  settings.params.forEach((param) => {
    if (!(param in req[settings.body])) {
      return { ...res, message: `El parámetro "${param}", no es valido.` };
    }
    if (!validate.string(req[settings.body][param])) {
      return { ...res, message: `El parámetro "${param}", no es valido.` };
    }
  });
  // - optional params
  settings.optional.forEach((param) => {
    if (param in req[settings.body]) {
      if (!validate.string(req[settings.body][param])) {
        return { ...res, message: `El parámetro "${param}", no es valido.` };
      }
    }
  });
  // - valid domain
  /*
  const host =
    'undefined' !== typeof req.get('origin')
      ? url.parse(req.get('origin')).host
      : ''
  if (!service.domain.includes(host)) {
    return {
      ...res,
      message: `El dominio '${host}' no esta registrado en el servicio '${service.id}'.`
    })
  }
  */
  res.status = true;
  return res;
};

exports.handleError = (req, res, message) => {
  res
    .setHeader(
      'Strict-Transport-Security',
      'max-age=31536000; includeSubDomains; preload'
    )
    .json({
      status: false,
      message,
    });
  return false;
};
