module.exports = {
    endOfLine: 'auto',
    semi: true,
    arrowParens: 'always',
    singleQuote: true,
  };
  