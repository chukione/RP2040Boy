const admin = require('firebase-admin');
require('dotenv').config();

/**
 * Setup Firebase admin
 */
admin.initializeApp();

//* api //
const { api } = require('./src/api/index');

exports.validate = {
  api,
};
// TODO
