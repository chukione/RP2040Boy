// https://nuxt.com/docs/api/configuration/nuxt-config-
import settings from './settingsTailwind';
import { version } from './package.json';
export default defineNuxtConfig({
  ssr: false,
  devtools: { enabled: false },
  css: [
    '~/assets/sass/main.sass',
    '@/assets/css/main.css'
  ],
  options: {
    tailwind: settings
  },
  runtimeConfig: {
    // Private config that is only available on the server* //
    apiSecret: '*******',
    public: {
      packageVersion: version,
      FIREBASE_CONFIG: process.env.FIREBASE_CONFIG,
      serviceId: process.env.SERVICE_ID,
      SSO_KEY_SIGNIN: process.env.SSO_KEY_SIGNIN,
      SSO_REDIRECT_URL_VERIFY: process.env.SSO_REDIRECT_URL_VERIFY,
      SSO_REDIRECT_URL_PROTECTED: process.env.SSO_REDIRECT_URL_PROTECTED,
      DOMAIN_URL: process.env.DOMAIN_URL,
      isDev: process.env.ENVIROMENT_MODE,
      apiUrl: process.env.API_URL
    }
  },
  modules: ['@carto-ine/jupiter', //* Doc: https://www.npmjs.com/package/@pinia/nuxt
    '@pinia/nuxt', //* Doc: https://tailwindcss.nuxtjs.org/getting-started/setup
    '@nuxtjs/google-fonts',
    '@pinia-plugin-persistedstate/nuxt',
    'nuxt3-leaflet',
    'nuxt-gtag'],
  gtag: {
    id: process.env.GA_TRACKING_ID4
  },
  googleFonts: {
    families: {
      Roboto: true,
      Quicksand: true,
      'Open Sans': true
    }
  }
});
// TODO EXPORT TO PACKAGE INE-LAB's
