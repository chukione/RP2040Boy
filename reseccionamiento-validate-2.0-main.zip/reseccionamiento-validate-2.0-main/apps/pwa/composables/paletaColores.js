export function usePoligonoColors () {
  const colors = [
    '#FFFF00',
    '#FB5607',
    '#B5179E',
    '#FF006E',
    '#7209B7',
    '#CA1E2B',
    '#bf889e',
    '#1a535c',
    '#DE4D86',
    '#3a0ca3',
    '#00b4d8',
    '#fafafa',
    '#ff6b6b',
    '#4ecdc4',
    '#ffe66d',
    '#6a0572',
    '#d4a373',
    '#ffbf69',
    '#606c38',
    '#bb3e03',
    '#370617',
    '#d00000',
    '#0353a4',
    '#007200',
    '#8ac926',
    '#2b9348',
    '#a9def9',
    '#ff477e'
  ];

  function getColorBySt (st) {
    return colors[st] || '#000000'; // Default to black if st is out of range
  }

  return {
    getColorBySt
  };
}
