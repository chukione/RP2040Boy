// import { ssoStore } from './../store/sso';
// const store = ssoStore();

export const navList = {
  public: [
    {
      icon: 'dashboard',
      name: 'Tablero',
      to: { name: 'console' },
      isSubmenu: false,
      show: true
    }
  ]
};
