export const govermentsUpdate: any = {
  1: {
    capital: 'Aguascalientes',
    distrito: { federal: 3, local: 18 },
    name: 'Aguascalientes',
    slug: 'aguascalientes'
  },
  2: {
    capital: 'Mexicali',
    distrito: { federal: 9, local: 17 },
    name: 'Baja California',
    slug: 'baja-california'
  },
  3: {
    capital: 'La Paz',
    distrito: { federal: 2, local: 16 },
    name: 'Baja California Sur',
    slug: 'baja-california-sur'
  },
  4: {
    capital: 'Campeche',
    distrito: { federal: 2, local: 21 },
    name: 'Campeche',
    slug: 'campeche'
  },
  5: {
    capital: 'Saltillo',
    distrito: { federal: 8, local: 16 },
    name: 'Coahuila',
    slug: 'coahuila'
  },
  6: {
    capital: 'Colima',
    distrito: { federal: 2, local: 16 },
    name: 'Colima',
    slug: 'colima'
  },
  7: {
    capital: 'Tuxtla Gutiérrez',
    distrito: { federal: 13, local: 24 },
    name: 'Chiapas',
    slug: 'chiapas'
  },
  8: {
    capital: 'Chihuahua',
    distrito: { federal: 9, local: 22 },
    name: 'Chihuahua',
    slug: 'chihuahua'
  },
  9: {
    capital: 'Ciudad de México',
    distrito: { federal: 22, local: 33 },
    name: 'Ciudad de México',
    slug: 'ciudad-de-mexico'
  },
  10: {
    capital: 'Durango',
    distrito: { federal: 4, local: 15 },
    name: 'Durango',
    slug: 'durango'
  },
  11: {
    capital: 'Guanajuato',
    distrito: { federal: 15, local: 22 },
    name: 'Guanajuato',
    slug: 'guanajuato'
  },
  12: {
    capital: 'Chilpancingo',
    distrito: { federal: 8, local: 28 },
    name: 'Guerrero',
    slug: 'guerrero'
  },
  13: {
    capital: 'Pachuca',
    distrito: { federal: 7, local: 18 },
    name: 'Hidalgo',
    slug: 'hidalgo'
  },
  14: {
    capital: 'Guadalajara',
    distrito: { federal: 20, local: 20 },
    name: 'Jalisco',
    slug: 'jalisco'
  },
  15: {
    capital: 'Toluca',
    distrito: { federal: 40, local: 45 },
    name: 'Estado de México',
    slug: 'estado-de-mexico'
  },
  16: {
    capital: 'Morelia',
    distrito: { federal: 11, local: 24 },
    name: 'Michoacán',
    slug: 'michoacan'
  },
  17: {
    capital: 'Cuernavaca',
    distrito: { federal: 5, local: 12 },
    name: 'Morelos',
    slug: 'morelos'
  },
  18: {
    capital: 'Tepic',
    distrito: { federal: 3, local: 18 },
    name: 'Nayarit',
    slug: 'nayarit'
  },
  19: {
    capital: 'Monterrey',
    distrito: { federal: 14, local: 26 },
    name: 'Nuevo León',
    slug: 'nuevo-leon'
  },
  20: {
    capital: 'Oaxaca',
    distrito: { federal: 10, local: 25 },
    name: 'Oaxaca',
    slug: 'oaxaca'
  },
  21: {
    capital: 'Puebla',
    distrito: { federal: 16, local: 26 },
    name: 'Puebla',
    slug: 'puebla'
  },
  22: {
    capital: 'Querétaro',
    distrito: { federal: 6, local: 15 },
    name: 'Querétaro',
    slug: 'queretaro'
  },
  23: {
    capital: 'Chetumal',
    distrito: { federal: 4, local: 15 },
    name: 'Quintana Roo',
    slug: 'quintana-roo'
  },
  24: {
    capital: 'San Luis Potosí',
    distrito: { federal: 7, local: 15 },
    name: 'San Luis Potosí',
    slug: 'san-luis-potosí'
  },
  25: {
    capital: 'Culiacán',
    distrito: { federal: 7, local: 24 },
    name: 'Sinaloa',
    slug: 'sinaloa'
  },
  26: {
    capital: 'Hermosillo',
    distrito: { federal: 7, local: 21 },
    name: 'Sonora',
    slug: 'sonora'
  },
  27: {
    capital: 'Villahermosa',
    distrito: { federal: 6, local: 21 },
    name: 'Tabasco',
    slug: 'tabasco'
  },
  28: {
    capital: 'Ciudad Victoria',
    distrito: { federal: 8, local: 22 },
    name: 'Tamaulipas',
    slug: 'tamaulipas'
  },
  29: {
    capital: 'Tlaxcala',
    distrito: { federal: 3, local: 15 },
    name: 'Tlaxcala',
    slug: 'tlaxcala'
  },
  30: {
    capital: 'Xalapa',
    distrito: { federal: 19, local: 30 },
    name: 'Veracruz',
    slug: 'veracruz'
  },
  31: {
    capital: 'Mérida',
    distrito: { federal: 6, local: 21 },
    name: 'Yucatán',
    slug: 'yucatan'
  },
  32: {
    capital: 'Zacatecas',
    distrito: { federal: 4, local: 18 },
    name: 'Zacatecas',
    slug: 'zacatecas'
  }
};

export const goverments = govermentsUpdate;
