import {
  booleanPointInPolygon,
  circle,
  multiPolygon,
  point,
  pointOnFeature,
  bbox
} from '@turf/turf';

export default process.server
  ? {}
  : {
      booleanPointInPolygon,
      circle,
      multiPolygon,
      point,
      pointOnFeature,
      bbox
    };
