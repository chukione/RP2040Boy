import {
  // collectionGroup,
  collection,
  getDocs,
  // getDoc,
  addDoc,
  deleteDoc,
  updateDoc,
  doc,
  query,
  orderBy,
  // where,
  setDoc,
  Timestamp
} from 'firebase/firestore';

const { $db } = useNuxtApp();

export const timestamp = Timestamp;
export const queryByCollection = async (col: string, db: any) => {
  // @ts-ignore
  const colRef = collection(db, col);
  const snapshot = await getDocs(colRef);

  const docs = Array.from(snapshot.docs).map((doc) => {
    return {
      ...doc.data(),
      id: doc.id
    };
  });

  return docs;
};
export const generateRef = async (db:any, colRef:any, object:any) => {
  // @ts-ignore
  const docRef = await addDoc(colRef, object);
  return docRef;
};
export const queryByCollectionOrder = async (col: string, db: any) => {
  const colRef = collection(db, col);
  const q = query(colRef, orderBy('create_at', 'desc'));
  const snapshot = await getDocs(q);
  const docs = snapshot.docs.map((doc) => {
    return {
      ...doc.data(),
      id: doc.id
    };
  });
  return docs;
};
export const set = async (col: string, document: Object) => {
  await setDoc(doc(collection($db, col)), document, { merge: true });
};

export const add = async (col: string, document: Object, db: any) => {
  // @ts-ignore
  const colRef = collection(db, col);
  const docRef = await addDoc(colRef, document);
  return docRef;
};

export const add2 = async (col: string, document: Object, db: any, id: any) => {
  // @ts-ignore
  const colRef = collection(db, col);
  const docRef = doc(colRef, id);
  await setDoc(docRef, document);
  return docRef;
};

export const del = async (col: any, id: any, db: any) => {
  const docRef = doc(db, col, id);
  return await deleteDoc(docRef);
};

export const update = async (col: any, id: any, document: any, db: any) => {
  const docRef = doc(db, col, id);
  return await updateDoc(docRef, document);
};
