<template>
  <div>
    <NuxtPage />
  </div>
</template>
<script setup>
definePageMeta({
  middleware: ['ssoDce'],
  layout: 'console'
});
</script>
