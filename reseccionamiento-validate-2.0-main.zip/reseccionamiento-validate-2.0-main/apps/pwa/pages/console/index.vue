<template>
  <div
    class="w-full grid grid-cols-1 gap-3 overflow-auto"
    :style="{ height: `${dataAltoMain}px` }"
  >
    <!-- Tile -->
    <div v-if="etapa !==0 && section !==0 && Object.keys(resultsValidaciones).length !== 0 && ClearDesktop === false" class="h-16 bg-white flex justify-center items-center text-ineAzul text-[24px] font-semibold border-b-[4px] border-ineAzul sticky top-0 z-[99999]">
      <h1>REPORTE DE VALIDACIONES</h1>
    </div>
    <!-- Mapa Incial -->
    <div v-if="section !== 0" class="flex items-center justify-center py-2 pb-9">
      <div class="w-[600px] h-[400px]">
        <div class="bg-ineAzul text-white flex justify-center items-center rounded-t-md py-1">
          <h1>Mapa inicial</h1>
        </div>
        <div class="w-full h-full">
          <ConsoleMapLeaflet />
        </div>
      </div>
    </div>
    <!-- Validaciones Globales -->
    <!-- TODO Estas validaciones se repiten en las etapas 1,2 y 3 -->
    <div v-if="etapa !==0 && section !==0 && Object.keys(resultsValidaciones).length !== 0 && ClearDesktop === false" class="flex flex-col gap-5">
      <ValidacionesGlobales />
    </div>
    <!-- Stages Components -->
    <div v-if="ClearDesktop === false" class="flex flex-col gap-5">
      <StageOne v-if="etapa === 1 || etapa === 2 || etapa === 3" />
      <StageTwo v-if="etapa === 2 || etapa === 3" />
      <StageThree v-if="etapa === 3" />
    </div>
  </div>
</template>
<script setup>
import { medidasStores } from '@/store/medidasStores';
import { sideBarStore } from '@/store/sideBar';
const dataSidebar = sideBarStore();
const { etapa, resultsValidaciones, section, ClearDesktop } = storeToRefs(dataSidebar);
// *** Manejo de Stores ***
const storeMedidas = medidasStores();
const { dataAltoMain } = storeToRefs(storeMedidas);
</script>
