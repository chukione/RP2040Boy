import { defineNuxtPlugin } from '#app';
import { initializeApp, getApps } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth, sendSignInLinkToEmail, signInWithEmailLink, isSignInWithEmailLink, signOut } from 'firebase/auth';

import { getStorage, ref, uploadBytes, listAll, getDownloadURL, deleteObject } from 'firebase/storage';
import { useRuntimeConfig } from '#imports';
export default defineNuxtPlugin({
  name: 'firebase',
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  setup (nuxtApp) {
    if (getApps().length < 1) {
      const config = useRuntimeConfig();
      const credential = JSON.parse(config.public.FIREBASE_CONFIG);
      initializeApp(credential);
      const auth = getAuth();
      const db = getFirestore();
      const storage = getStorage();
      return { provide: { auth, db, storage, ref, uploadBytes, listAll, getDownloadURL, deleteObject, sendSignInLinkToEmail, signInWithEmailLink, isSignInWithEmailLink, signOut } };
    }
  }
});
