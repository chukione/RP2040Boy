const settings = {
  content: [
    './components/**/*.{js,vue,ts}',
    './layouts/**/*.vue',
    './pages/**/*.vue',
    './plugins/**/*.{js,ts}',
    './nuxt.config.{js,ts}'
  ],
  theme: {
    extend: {
      fontFamily: {
        body: 'Open Sans',
        display: 'Quicksand'
      },
      colors: {
        body: '#4a4a4a',
        ine: '#ED008C',
        melon: '#f5847c',
        HeadViewPublic: '#D22F84',
        ButtonViewPublic: '#B83A95',
        TextRevocacion: '#61045F',
        TextDays: '#A3005C',
        navBar: '#561982',
        labelsStats: '#9A186A',
        buttonsEnviar: '#4F46E5',
        MainPublic: '#903C9F',
        BackHeaders: '#F3EFFF',
        AvailableModule: '#20BD5F',
        OrangeNeon: '#FF6700',
        nav: '#458269',
        backGroundNav: '#b6206a',
        hoverNavBar: '#961e57',
        ineAzul: '#252756',
        ineMorado: '#512f73',
        ineRosa: '#bf889e',
        inePurpura: '#80416b',
        ineLila: '#ae80b7'
      }
    }
  },
  plugins: [
    require('@tailwindcss/forms')
    // ...
  ]
};

module.exports = settings;
