<template>
  <div>
    <div class="flex flex-col min-h-[100vh] bg-white">
      <!-- App Waiting -->
      <AppWaiting v-if="waiting" />
      <ValidateLoading v-if="activeSpinnerData" />
      <!-- Header -->
      <div ref="headerRef" class="sticky top-0 z-[99]">
        <AppWaiting v-if="waiting" />
        <ConsoleHeader />
      </div>

      <!-- Main Content -->
      <div class="flex flex-grow" @keyup.esc="setSidebar(false)">
        <!-- Sidebar -->
        <div ref="sidebarRef" class="bg-white">
          <ConsoleNavDesktop />
        </div>

        <div class="flex-grow">
          <slot />
        </div>

        <!-- Alerts -->
        <notifications-list class="mt-10" />
      </div>

      <!-- Footer -->
      <div ref="footerRef" class="z-10">
        <ConsoleFooter />
      </div>
    </div>
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { consoleStore } from '@/store/console';
import { indexStore } from '@/store';
import { medidasStores } from '@/store/medidasStores';
import { sideBarStore } from '@/store/sideBar';

const storeSideBar = sideBarStore();
const { activeSpinnerData } = storeToRefs(storeSideBar);

// *** Manejo de Stores ***
const storeMedidas = medidasStores();
const storeConsole = consoleStore();
// const { sidebarWithDelay, title } = storeToRefs(storeConsole);
const storeIndex = indexStore();
const { waiting } = storeToRefs(storeIndex);

const setSidebar = (val) => {
  storeConsole.setSidebar(val);
};

let resizeObserver;
onMounted(() => {
  // *** Alto Disponible ***
  // Observar el redimensionamiento de la ventana
  resizeObserver = new ResizeObserver(updateDimensions);
  resizeObserver.observe(document.body);

  updateDimensions();
});

onUnmounted(() => {
  // Asegúrate de limpiar el observador cuando el componente se desmonte
  if (resizeObserver) {
    resizeObserver.disconnect();
  }
});

// *** Medidas Disponibles Dinamicas ***
const headerRef = ref(null);
const footerRef = ref(null);
const sidebarRef = ref(null);
const availableHeight = ref(null);
const availableMainHeight = ref(null);
const availableMainWidth = ref(null);
const updateDimensions = () => {
  const headerHeight = headerRef.value ? headerRef.value.clientHeight : 0;
  // console.log('headerHeight', headerHeight);
  const footerHeight = footerRef.value ? footerRef.value.clientHeight : 0;
  const sidebarWidth = sidebarRef.value ? sidebarRef.value.clientWidth : 0;
  // console.log('footerHeight', footerHeight);
  availableHeight.value = window.innerHeight - headerHeight;
  availableMainHeight.value = window.innerHeight - headerHeight - footerHeight;
  availableMainWidth.value = window.innerWidth - sidebarWidth;
  storeMedidas.setDataAltoMain(availableMainHeight.value);
  // setAltoDisponible(availableHeight.value);
  // setAltoDisponibleMain(availableMainHeight.value);
  // setAnchoDisponible(availableMainWidth.value);
};
</script>
