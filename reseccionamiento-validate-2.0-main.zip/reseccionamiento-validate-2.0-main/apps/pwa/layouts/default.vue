<template>
  <div class="w-full lg:mx-auto lg:max-w-5xl xl:max-w-7xl shadow-md">
    <slot />
  </div>
</template>
