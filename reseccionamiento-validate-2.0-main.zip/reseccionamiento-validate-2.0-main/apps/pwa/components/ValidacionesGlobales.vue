<template>
  <div v-if="'data' in resultsValidaciones">
    <!-- Title -->
    <div class="text-center bg-ineMorado text-white h-12 flex items-center justify-center text-lg font-semibold">
      <h2>Validación de geometrías</h2>
    </div>
    <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold">
      <h2>Capa red</h2>
    </div>
    <!-- Geometrías -->
    <div>
      <!-- Geometrías nulas-->
      <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
        <h2>Geometrías nulas</h2>
      </div>
      <div class="flex items-center justify-center gap-10 px-5 text-center">
        <!-- Table -->
        <div v-if="resultsValidaciones.data.validarGeometriaRed.length>0">
          <p
            v-if="resultsValidaciones.data.validarGeometriaRed.length>1"
          >
            Se encontró un total de <span class="text-red-500 font-bold">{{ resultsValidaciones.data.validarGeometriaRed.length }}</span> geometrías y fueron removidas de la base.
          </p>
          <p
            v-else
          >
            Se encontró <span class="text-red-500 font-bold">1</span> geometría y fue removida de la base.
          </p>
          <p>
            {{ getIds() }}
          </p>
        </div>
        <div v-else>
          <p>
            No se encontraron geometrías nulas.
          </p>
        </div>
      </div>
      <!-- Geometrías inválidas-->
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
          <h2>Geometrías invalidas</h2>
        </div>
        <div class="flex justify-center gap-10 px-5">
          <!-- Table -->
          <div v-if="resultsValidaciones.data.validarGeometriaRedInvalidas && resultsValidaciones.data.validarGeometriaRedInvalidas.lista.length > 0" class="flex items-center justify-center">
            <div class="h-[400px] overflow-auto flex items-center justify-center">
              <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
                <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                  <tr>
                    <th scope="col" class="px-6 py-3">
                      #
                    </th>
                    <th scope="col" class="px-6 py-3">
                      GID(s) invalidos
                    </th>
                  </tr>
                </thead>
                <tbody class="text-center">
                  <tr
                    v-for="(item, index) in resultsValidaciones.data.validarGeometriaRedInvalidas.lista"
                    :key="`gid-${item.key}`"
                    class="bg-white border-b"
                  >
                    <td class="px-6 py-4">
                      {{ index + 1 }}
                    </td>
                    <td class="px-6 py-4">
                      {{ item.gid }}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div v-else class="flex items-center justify-center gap-10 px-5 mb-2 text-center">
            <p>
              No se encontraron geometrías invalidas.
            </p>
          </div>
          <!-- Map -->
          <div v-if="resultsValidaciones.data.validarGeometriaRedInvalidas && resultsValidaciones.data.validarGeometriaRedInvalidas.geometry" class="w-[600px] h-[400px]">
            <EtapaUnoMapaGeometryInvalidas :geometry="resultsValidaciones.data.validarGeometriaRedInvalidas.geometry" />
          </div>
        </div>
      </div>
      <!-- Geometrías duplicadas -->
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
          <h2>Geometrías duplicadas</h2>
        </div>
        <div class="flex items-center justify-center gap-10 px-5 mb-2">
          <div v-if="resultsValidaciones.data.geometriasDuplicadasRed && resultsValidaciones.data.geometriasDuplicadasRed.lista.length>0">
            <p
              v-if="resultsValidaciones.data.geometriasDuplicadasRed.lista.length>1"
            >
              Se encontró un total de <span class="text-red-500 font-bold">{{ resultsValidaciones.data.geometriasDuplicadasRed.lista.length }}</span> líneas duplicadas.
            </p>
            <p
              v-else
              class="pb-5"
            >
              Se encontró <span class="text-red-500 font-bold">1</span> línea duplicada.
            </p>
          </div>
          <div v-else>
            <p>
              No se encontraron líneas duplicadas.
            </p>
          </div>
        </div>
        <div v-if="resultsValidaciones.data.geometriasDuplicadasRed && resultsValidaciones.data.geometriasDuplicadasRed.lista.length>0" class="flex justify-center gap-10 px-5">
          <!-- Table -->
          <div>
            <div class="h-[400px] overflow-auto flex items-center justify-center">
              <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
                <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                  <tr>
                    <th scope="col" class="px-6 py-3">
                      GID
                    </th>
                    <th scope="col" class="px-6 py-3">
                      GID(s) repetido(s)
                    </th>
                  </tr>
                </thead>
                <tbody class="text-center">
                  <tr
                    v-for="item in resultsValidaciones.data.geometriasDuplicadasRed.lista"
                    :key="`gid-${item.key}`"
                    class="bg-white border-b"
                  >
                    <td class="px-6 py-4">
                      {{ item.gid }}
                    </td>
                    <td class="px-6 py-4">
                      {{ item.repetidos.join(', ') }}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <ConsoleMapGeometryDuplicated :geometry="resultsValidaciones.data.geometriasDuplicadasRed.geometry" />
          </div>
        </div>
      </div>
      <!-- nodos Duplicados -->
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
          <h2>Nodos duplicados</h2>
        </div>
        <!-- Se encontró un total de 9 nodos duplicados y fueron removidos de la base -->
        <div class="flex items-center justify-center gap-10 px-5 mb-2">
          <div v-if="resultsValidaciones.data.nodosDuplicadosRed.total>0">
            <p
              v-if="resultsValidaciones.data.nodosDuplicadosRed.total>1"
            >
              Se encontró un total de <span class="text-red-500 font-bold">{{ resultsValidaciones.data.nodosDuplicadosRed.total }}</span> nodos duplicados y fueron removidos de la base.
            </p>
            <p
              v-else
              class="pb-5"
            >
              Se encontró <span class="text-red-500 font-bold">1</span> nodos duplicado y fue removido de la base.
            </p>
          </div>
          <div v-else>
            <p>
              No se encontraron nodos duplicados.
            </p>
          </div>
        </div>
        <div v-if="resultsValidaciones.data.nodosDuplicadosRed.total>0" class="flex justify-center gap-10 px-5">
          <!-- Table -->
          <div>
            <div class="h-[400px] overflow-auto flex items-center justify-center">
              <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
                <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                  <tr>
                    <th scope="col" class="px-6 py-3">
                      GID
                    </th>
                    <th scope="col" class="px-6 py-3">
                      Cantidad de nodos repetidos
                    </th>
                  </tr>
                </thead>
                <tbody class="text-center">
                  <tr
                    v-for="item in resultsValidaciones.data.nodosDuplicadosRed.nodosDuplicados"
                    :key="`gid-${item.key}`"
                    class="bg-white border-b"
                  >
                    <td class="px-6 py-4">
                      {{ item.gid }}
                    </td>
                    <td class="px-6 py-4">
                      {{ item.contador }}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <ConsoleMapNodosDuplicados :geometry="resultsValidaciones.data.nodosDuplicadosRed.nodos" :lines="resultsValidaciones.data.nodosDuplicadosRed.lines" />
          </div>
        </div>
      </div>
      <!-- /nodosDuplicados -->
      <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold mt-6">
        <h2>Capa Mz_Reseccionamiento</h2>
      </div>
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
          <h2>
            Geometrías inválidas
          </h2>
        </div>
        <div class="flex items-center justify-center gap-10 px-5 mb-2">
          <div v-if="resultsValidaciones.data.validarGeometriaMz.invalidas.length>0">
            <p
              v-if="resultsValidaciones.data.validarGeometriaMz.invalidas.length>0"
            >
              Se encontraron <span class="text-red-500 font-bold">{{ resultsValidaciones.data.validarGeometriaMz.invalidas.length }}</span> manzanas.
            </p>
            <p
              v-else
              class="pb-5"
            >
              Se encontró <span class="text-red-500 font-bold">1</span> manzana.
            </p>
          </div>
          <div v-else>
            <p>
              No se encontraron manzanas invalidas.
            </p>
          </div>
        </div>
        <div v-if="resultsValidaciones.data.validarGeometriaMz.invalidas.length>0" class="flex justify-center gap-10 px-5">
          <!-- Table -->
          <div>
            <div class="h-[400px] overflow-auto flex items-center justify-center">
              <table class="w-full text-sm text-left rtl:text-right text-gray-500 border">
                <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                  <tr>
                    <th scope="col" class="px-6 py-3">
                      Manzana
                    </th>
                    <th scope="col" class="px-6 py-3">
                      GID
                    </th>
                  </tr>
                </thead>
                <tbody class="text-center">
                  <tr
                    v-for="item in resultsValidaciones.data.validarGeometriaMz.invalidas"
                    :key="`gid-${item.key}`"
                    class="bg-white border-b"
                  >
                    <td class="px-6 py-4">
                      {{ item.manzana }}
                    </td>
                    <td class="px-6 py-4">
                      {{ item.gid }}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- /mzNulas invalidas -->
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
          <h2>
            Geometrías nulas
          </h2>
        </div>
        <div class="flex items-center justify-center gap-10 px-5 mb-2">
          <div v-if="resultsValidaciones.data.validarGeometriaMz.nulas.length>0">
            <p
              v-if="resultsValidaciones.data.validarGeometriaMz.nulas.length>0"
            >
              Se encontraron <span class="text-red-500 font-bold">{{ resultsValidaciones.data.validarGeometriaMz.nulas.length }}</span> manzanas nulas.
            </p>
            <p
              v-else
              class="pb-5"
            >
              Se encontró <span class="text-red-500 font-bold">1</span> manzana nula.
            </p>
          </div>
          <div v-else>
            <p class="pb-5">
              No se encontraron geometrías nulas en la capa.
            </p>
          </div>
        </div>
        <div v-if="resultsValidaciones.data.validarGeometriaMz.nulas.length>0" class="flex justify-center gap-10 px-5">
          <!-- Table -->
          <div>
            <div class="h-[400px] overflow-auto flex items-center justify-center">
              <table class="w-full text-sm text-left rtl:text-right text-gray-500 border">
                <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                  <tr>
                    <th scope="col" class="px-6 py-3">
                      Manzana
                    </th>
                    <th scope="col" class="px-6 py-3">
                      GID
                    </th>
                  </tr>
                </thead>
                <tbody class="text-center">
                  <tr
                    v-for="item in resultsValidaciones.data.validarGeometriaMz.nulas"
                    :key="`gid-${item.key}`"
                    class="bg-white border-b"
                  >
                    <td class="px-6 py-4">
                      {{ item.manzana === null ? 'null' : item.manzana }}
                    </td>
                    <td class="px-6 py-4">
                      {{ item.gid }}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- /nulas -->
      <div v-if="etapa === 1">
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
          <h2>Manzanas Contenedoras</h2>
        </div>
        <!-- Se encontró un total de 9 nodos duplicados y fueron removidos de la base -->
        <div class="flex items-center justify-center gap-10 px-5 mb-2">
          <div v-if="resultsValidaciones.data.mz_contenedoras && resultsValidaciones.data.mz_contenedoras.lista.length>0">
            <p
              v-if="resultsValidaciones.data.mz_contenedoras.lista.length>1"
            >
              Se encontraron un total de <span class="text-red-500 font-bold">{{ resultsValidaciones.data.mz_contenedoras.lista.length }}</span> manzanas contenedoras:
            </p>
            <p
              v-else
            >
              Se encontró <span class="text-red-500 font-bold">1</span> manzana contenedora.
            </p>
          </div>
          <div v-else>
            <p class="pb-5">
              No se encontraron manzanas contenedoras.
            </p>
          </div>
        </div>
        <div v-if="resultsValidaciones.data.mz_contenedoras && resultsValidaciones.data.mz_contenedoras.lista.length>0" class="flex justify-center gap-10 px-5">
          <!-- Table -->
          <div>
            <div class="h-[400px] overflow-auto flex items-center justify-center">
              <table class="w-full text-sm text-left rtl:text-right text-gray-500 border">
                <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                  <tr>
                    <th scope="col" class="px-6 py-3">
                      #
                    </th>
                    <th scope="col" class="px-6 py-3">
                      Manzana Contenedora
                    </th>
                    <th scope="col" class="px-6 py-3">
                      Manzana(s) Contenida(s)
                    </th>
                  </tr>
                </thead>
                <tbody class="text-center">
                  <tr
                    v-for="(item, index) in resultsValidaciones.data.mz_contenedoras.lista"
                    :key="`gid-${item.key}`"
                    class="bg-white border-b"
                  >
                    <td class="px-6 py-4">
                      {{ (index+1) }}
                    </td>
                    <td class="px-6 py-4">
                      {{ item.manzanas }}
                    </td>
                    <td class="px-6 py-4">
                      {{ item.contenidas }}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaUnoMapaManzanasContenedoras :mz-contenedora="resultsValidaciones.data.mz_contenedoras.mz_contenedora" :mz-contenida="resultsValidaciones.data.mz_contenedoras.mz_contenidas" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from './../store/sideBar';
const storeSideBar = sideBarStore();
const { resultsValidaciones, etapa } = storeToRefs(storeSideBar);

// watch(resultsValidaciones, (newVal) => {
//   console.log(newVal.data.validarGeometriaRedInvalidas.lista);
// });

const getIds = () => {
  if (resultsValidaciones.value.data.validarGeometriaRed.length === 0) {
    return '';
  }
  const gids = resultsValidaciones.value.data.validarGeometriaRed.map(x => x.gid);
  return gids.join(', ');
};

</script>
