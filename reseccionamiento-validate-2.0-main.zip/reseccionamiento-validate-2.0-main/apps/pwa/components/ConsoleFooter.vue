<template>
  <div
    class="mt-auto bg-ineAzul text-white w-full px-4 py-2 flex gap-2 lg:flex-row md:flex-row flex-col lg:justify-between md:justify-between justify-center lg:items-start md:items-start lg:text-start md:text-start text-center items-center"
  >
    <!-- First Part -->
    <div>
      <p>Departamento de Desarrollo de Herramientas Geoelectorales</p>
      <p>Subdirección de Desarrollo de Sistemas Geográficos Electorales</p>
      <p>Dirección de Cartografía Electoral</p>
    </div>
    <!-- Second Part -->
    <div>
      <img class="w-[107px]" src="@/assets/img/INE_blanco.png">
    </div>
  </div>
</template>

<style scoped>
p {
  font-size: 12px !important;
}
</style>
