<template>
  <div class="flex items-center flex-shrink-0 px-5">
    <app-logo class="h-10 w-auto" />
    <div class="ml-2 text-ineAzul">
      <h2 class="font-display text-2xl font-extrabold leading-tight">
        DCE
      </h2>
      <p class="w-full text-xs text-ineAzul text-right leading-none">
        versión {{ packageVersion }}
      </p>
    </div>
  </div>
</template>
<script setup lang="ts">
const config = useRuntimeConfig();
const { packageVersion } = config.public;
</script>
