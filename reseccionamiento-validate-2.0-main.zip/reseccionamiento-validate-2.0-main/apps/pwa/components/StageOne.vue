<template>
  <div v-if=" 'data' in resultsValidaciones">
    <div class="text-center bg-ineMorado text-white h-12 flex items-center justify-center text-lg font-semibold">
      <h2>Sobreposición de geometrías</h2>
    </div>
    <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold">
      <h2>
        Capa Mz_Reseccionamiento
      </h2>
    </div>
    <!-- mz_reseccionamiento -->
    <div>
      <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
        <h2>
          Sobreposición Red sobre Mz_Reseccionamiento
        </h2>
      </div>
      <!-- Todo -->
      <div class="flex items-center justify-center gap-10 px-5 mb-2">
        <div v-if="resultsValidaciones.data.sobreposicion_red_mz && resultsValidaciones.data.sobreposicion_red_mz.lista.length>0">
          <p
            v-if="resultsValidaciones.data.sobreposicion_red_mz.lista.length>1"
          >
            Se encontró un total de <span class="text-red-500 font-bold">{{ resultsValidaciones.data.sobreposicion_red_mz.lista.length }}</span> segmentos sobrepuestos en mz_reseccionamiento:
          </p>
          <p
            v-else
          >
            Se encontró <span class="text-red-500 font-bold">1</span> segmento sobrepuesto en mz_reseccionamiento:
          </p>
        </div>
        <div v-else>
          <p>
            No se encontraron segmentos sobrepuestos.
          </p>
        </div>
      </div>
      <div v-if="resultsValidaciones.data.sobreposicion_red_mz && resultsValidaciones.data.sobreposicion_red_mz.lista.length>0" class="flex justify-center gap-10 px-5">
        <!-- Table -->
        <div>
          <div class="h-[400px] overflow-auto">
            <table class="w-full text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    GID Red
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana(s) sobrepuesta(s)
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr
                  v-for="(item, index) in resultsValidaciones.data.sobreposicion_red_mz.lista"
                  :key="`gid-${item.gid}`"
                  class="bg-white border-b"
                >
                  <td class="px-6 py-4">
                    {{ (index+1) }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.gid }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.repetidos }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <!-- Map -->
        <div class="w-[600px] h-[400px]">
          <EtapaUnoMapaSobreposicionGeoms :mz="resultsValidaciones.data.sobreposicion_red_mz.mz" :red="resultsValidaciones.data.sobreposicion_red_mz.red" :interseccion="resultsValidaciones.data.sobreposicion_red_mz.interseccion" />
        </div>
      </div>
    </div>
    <!-- sobreposicionMzReseccionamiento -->
    <div>
      <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
        <h2>
          Sobreposición en Mz_Reseccionamiento
        </h2>
      </div>
      <!-- Todo -->
      <div class="flex items-center justify-center gap-10 px-5 mb-2">
        <div v-if="resultsValidaciones.data.sobreposicion_mz && resultsValidaciones.data.sobreposicion_mz.lista.length>0">
          <p
            v-if="resultsValidaciones.data.sobreposicion_mz.lista.length>1"
          >
            Se encontró un total de <span class="text-red-500 font-bold">{{ resultsValidaciones.data.sobreposicion_mz.lista.length }}</span> geometrías sobrepuestas
          </p>
          <p
            v-else
          >
            Se encontró <span class="text-red-500 font-bold">1</span> geometría sobrepuesta
          </p>
        </div>
        <div v-else>
          <p>
            No se encontraron geometrías sobrepuestas.
          </p>
        </div>
      </div>
      <div v-if="resultsValidaciones.data.sobreposicion_mz && resultsValidaciones.data.sobreposicion_mz.lista.length>0" class="flex justify-center gap-10 px-5">
        <!-- Table -->
        <div class="h-[400px] overflow-auto">
          <table class="w-full text-sm text-left rtl:text-right text-gray-500 border">
            <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
              <tr>
                <th scope="col" class="px-6 py-3">
                  #
                </th>
                <th scope="col" class="px-6 py-3">
                  Manzana
                </th>
                <th scope="col" class="px-6 py-3">
                  Manzana(s) sobrepuesta(s)
                </th>
              </tr>
            </thead>
            <tbody class="text-center">
              <tr
                v-for="(item, index) in resultsValidaciones.data.sobreposicion_mz.lista"
                :key="`gid-${item.gid}`"
                class="bg-white border-b"
              >
                <td class="px-6 py-4">
                  {{ (index+1) }}
                </td>
                <td class="px-6 py-4">
                  {{ item.manzana }}
                </td>
                <td class="px-6 py-4">
                  {{ item.contenidas }}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <!-- Map -->
        <div class="w-[600px] h-[400px]">
          <EtapaUnoMapaStageOneSobreposicion :mza="resultsValidaciones.data.sobreposicion_mz.mz_a" :mzb="resultsValidaciones.data.sobreposicion_mz.mz_b" :interseccion="resultsValidaciones.data.sobreposicion_mz.interseccion" />
        </div>
      </div>
    </div>
    <div class="text-center bg-ineMorado text-white h-12 flex items-center justify-center text-lg font-semibold mt-6">
      <h2>Validación de campos</h2>
    </div>
    <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold">
      <h2>
        Capa Red
      </h2>
    </div>
    <div>
      <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
        <h2>
          Registros con diferente categoría
        </h2>
      </div>
      <!-- Todo -->
      <div class="flex items-center justify-center gap-10 px-5 mb-2">
        <div v-if="resultsValidaciones.data.validar_categoria_red && resultsValidaciones.data.validar_categoria_red.lista.length>0">
          <p
            v-if="resultsValidaciones.data.validar_categoria_red.lista.length>1"
          >
            Se encontró un total de <span class="text-red-500 font-bold">{{ resultsValidaciones.data.validar_categoria_red.lista.length }}</span> registros con alguna categoría diferente en la capa:
          </p>
          <p
            v-else
          >
            Se encontró <span class="text-red-500 font-bold">1</span> registro con categoría diferente en la capa:
          </p>
        </div>
        <div v-else>
          <p>
            No se encontraron registros con alguna categoría diferente en la capa
          </p>
        </div>
      </div>
      <div v-if="resultsValidaciones.data.validar_categoria_red && resultsValidaciones.data.validar_categoria_red.lista.length>0" class="flex justify-center gap-10 px-5">
        <!-- Table -->
        <div>
          <div class="h-[400px] overflow-auto">
            <table class="w-full text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    GID
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Categoría
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr
                  v-for="(item, index) in resultsValidaciones.data.validar_categoria_red.lista"
                  :key="`gid-${item.gid}`"
                  class="bg-white border-b"
                >
                  <td class="px-6 py-4">
                    {{ (index+1) }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.red }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.categoria }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from './../store/sideBar';
const storeSideBar = sideBarStore();
const { resultsValidaciones } = storeToRefs(storeSideBar);
</script>
