<template>
  <div v-if="'data' in resultsValidaciones" class="flex flex-col gap-5 pb-4">
    <!-- Part 3 -->
    <div>
      <!-- Title -->
      <div class="text-center bg-ineMorado text-white h-12 flex items-center justify-center text-lg font-semibold">
        <h2>Comparación de manzanas "pol_red_inter_mz0000" vs "mz_reseccionamiento0000"</h2>
      </div>
      <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold">
        <h2>Capa Pol_Red_Inter_Mz</h2>
      </div>
      <!-- Manzanas duplicadas en la capa pol_red_inter_mz0000 -->
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold pt-10 pb-7">
          <h2>Manzanas duplicadas en la capa pol_red_inter_mz0000</h2>
        </div>
        <div v-if="duplicatedManzanas.length > 0" class="flex justify-center pb-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ duplicatedManzanas.length }}</span> manzanas duplicadas</p>
        </div>
        <div v-else class="flex justify-center pb-5">
          <p>No se encontraron manzanas duplicadas</p>
        </div>
        <div v-if="duplicatedManzanas.length > 0" class="flex items-center justify-center gap-10 px-5">
          <!-- Table -->
          <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
            <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Gid
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Localidad
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr v-for="(item, index) in duplicatedManzanas" :key="index" class="bg-white border-b">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {{ index + 1 }}
                  </th>
                  <td class="px-6 py-4">
                    {{ item.properties.gid }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.localidad }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.manzana }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaManzanasDuplicadasPolRedInter />
          </div>
        </div>
      </div>
      <!-- Manzanas faltantes en la capa mz_reseccionamiento0000 y se encuentran en la capa
          pol_red_inter_mz0000 -->
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold pt-10 pb-7">
          <h2>
            Manzanas faltantes en la capa mz_reseccionamiento0000 y se encuentran en la capa
            pol_red_inter_mz0000
          </h2>
        </div>
        <div v-if="mzReseccionamientoFaltantes.length > 0" class="flex justify-center pb-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ mzReseccionamientoFaltantes.length }}</span> manzanas faltantes</p>
        </div>
        <div v-else class="flex justify-center pb-5">
          <p>No se encontraron manzanas faltantes</p>
        </div>
        <div v-if="mzReseccionamientoFaltantes.length > 0" class="flex items-center justify-center gap-10 px-5">
          <!-- Table -->
          <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
            <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Gid
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Localidad
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr v-for="(item, index) in mzReseccionamientoFaltantes" :key="index" class="bg-white border-b">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {{ index + 1 }}
                  </th>
                  <td class="px-6 py-4">
                    {{ item.properties.gid }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.localidad }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.manzana }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaMzReseccionamientoFaltantes />
          </div>
        </div>
      </div>
      <!-- Manzanas faltantes en la capa pol_red_inter_mz0000 y se encuentran en la capa
          mz_reseccionamiento0000 -->
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold pt-10 pb-7">
          <h2>
            Manzanas faltantes en la capa pol_red_inter_mz0000 y se encuentran en la capa
            mz_reseccionamiento0000
          </h2>
        </div>
        <div v-if="mzPolRedFaltantes.length > 0" class="flex justify-center pb-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ mzPolRedFaltantes.length }}</span> manzanas faltantes</p>
        </div>
        <div v-else class="flex justify-center pb-5">
          <p>No se encontraron manzanas faltantes</p>
        </div>
        <div v-if="mzPolRedFaltantes.length > 0" class="flex items-center justify-center gap-10 px-5">
          <!-- Table -->
          <div class="h-[400px] overflow-auto flex flex-col items-center">
            <table class="w-full my-auto overflow-auto text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Gid
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Localidad
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr v-for="(item, index) in mzPolRedFaltantes" :key="index" class="bg-white border-b">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {{ index + 1 }}
                  </th>
                  <td class="px-6 py-4">
                    {{ item.properties.gid }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.localidad }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.manzana }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaMzPolRedFaltantes />
          </div>
        </div>
      </div>
    </div>
    <!-- Part 1 -->
    <div>
      <!-- Title -->
      <div class="text-center bg-ineMorado text-white h-12 flex items-center justify-center text-lg font-semibold">
        <h2>Sobreposición de geometrías</h2>
      </div>
      <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold">
        <h2>Capa Pol_Red_Inter_Mz</h2>
      </div>
      <!-- Sobreposición en Pol_Red_Inter_Mz -->
      <div>
        <div class="text-center text-ineAzul flex items-center justify-center text-lg font-semibold py-4">
          <h2>Sobreposición en Pol_Red_Inter_Mz</h2>
        </div>
        <div v-if="sobreposicionPolRed.length > 0" class="flex justify-center pb-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ sobreposicionPolRed.length }}</span> manzanas sobrepuestas</p>
        </div>
        <div v-else class="flex justify-center pb-5">
          <p>No se encontraron manzanas sobrepuestas</p>
        </div>
        <div v-if="sobreposicionPolRed.length > 0" class="flex items-center justify-center gap-10 px-5">
          <!-- Table -->
          <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
            <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana(s) sobrepuesta(s)
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr v-for="(item, index) in sobreposicionPolRed" :key="index" class="bg-white border-b">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {{ item.i }}
                  </th>
                  <td class="px-6 py-4">
                    {{ item.manzana }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.repetidos }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaManzanasSobrepuestas />
          </div>
        </div>
      </div>
      <!-- Visualización y Sobreposición de Red categoría 1 y 5 sobre Pol Red Inter Mz -->
      <div v-if="Object.keys(fraccionamientosRed158).length > 0">
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold pt-10 pb-7">
          <h2>Visualización de categoría 1, 5 y 8 sobre "Pol Red Inter Mz"</h2>
        </div>
        <div v-if="categoriasLength !== 0" class="flex justify-center pb-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ categoriasLength }}</span> categorías</p>
        </div>
        <div v-if="Object.keys(fraccionamientosRed158).length > 0" class="flex items-center justify-center gap-10 px-5">
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaFraccionamientosRed158 />
          </div>
        </div>
      </div>
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold pt-10 pb-7">
          <h2>Sobreposición de categoría 1, 5 y 8 sobre "Pol Red Inter Mz"</h2>
        </div>
        <div v-if="sobreposicionRedPolRed.length > 0" class="flex justify-center pb-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ sobreposicionRedPolRed.length }}</span> manzanas sobrepuestas</p>
        </div>
        <div v-else class="flex justify-center pb-5">
          <p>No se encontraron manzanas sobrepuestas</p>
        </div>
        <div v-if="sobreposicionRedPolRed.length > 0" class="flex items-center justify-center gap-10 px-5">
          <!-- Table -->
          <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
            <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    GID
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Categoría
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana(s) sobrepuesta(s)
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr v-for="(item, index) in sobreposicionRedPolRed" :key="index" class="bg-white border-b">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {{ item.i }}
                  </th>
                  <td class="px-6 py-4">
                    {{ item.gid }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.categoria }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.repetidos }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaManzanasSobrepuestasRed158 />
          </div>
        </div>
      </div>
    </div>
    <!-- Part 2 -->
    <div>
      <!-- Title 2 -->
      <div class="text-center bg-ineMorado text-white h-12 flex items-center justify-center text-lg font-semibold">
        <h2>Validación de campos</h2>
      </div>
      <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold">
        <h2>Capa Escuela</h2>
      </div>
      <!-- Inconsistencias en captura -->
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold pt-10 pb-7">
          <h2>Inconsistencias en captura</h2>
        </div>
        <div v-if="nulosEscuelaLista.length > 0" class="flex justify-center pb-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ nulosEscuelaLista.length }}</span> servicios que no corresponden al catálogo oficial y un total de <span class="text-red-500 font-semibold">{{ fraccionamientosLength }}</span> fraccionamientos</p>
        </div>
        <div v-else class="flex justify-center pb-5">
          <p>No se encontraron servicios que no corresponden al catálogo oficial ni fraccionamientos</p>
        </div>
        <div v-if="nulosEscuelaLista.length > 0" class="flex items-center justify-center gap-10 px-5">
          <!-- Table -->
          <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
            <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    GID
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Entidad
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Distrito
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Sección
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Tipo
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr v-for="(item, index) in nulosEscuelaLista" :key="index" class="bg-white border-b">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {{ index + 1 }}
                  </th>
                  <td class="px-6 py-4">
                    {{ item.gid }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.detalleEntidad }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.detalleDistrito }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.detalleSeccion }}
                  </td>
                  <td class="px-6 py-4 capitalize">
                    {{ item.detalleTipo }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaInconsistenciasCaptura />
          </div>
        </div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold pt-10 pb-7">
          <h2>Inconsistencias en captura de Mz_Comparacion vs Mz_Reseccionamiento</h2>
        </div>
        <div v-if="mzGeomIgualNumDif.length > 0" class="flex justify-center pb-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ mzGeomIgualNumDif.length }}</span> manzanas que fueron modificadas en su campo "manzana"</p>
        </div>
        <div v-else class="flex justify-center pb-5">
          <p>No se encontraron manzanas que hayan sido modificadas en su campo "manzana"</p>
        </div>
        <div v-if="mzGeomIgualNumDif.length > 0" class="flex items-center justify-center gap-10 px-5">
          <!-- Table -->
          <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
            <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Localidad
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana original
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana modificada
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr v-for="(item, index) in mzGeomIgualNumDif" :key="index" class="bg-white border-b">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {{ index + 1 }}
                  </th>
                  <td class="px-6 py-4">
                    {{ item.properties.localidad }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.orig_manzana }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.mod_manzana }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaMzGeomIgualNumDif />
          </div>
        </div>
        <div v-if="mzNumIgualGeomDif.length > 0" class="flex justify-center py-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ mzNumIgualGeomDif.length }}</span> manzanas que fueron modificadas en su geometría, campo "the_geom"</p>
        </div>
        <div v-else class="flex justify-center py-5">
          <p>No se encontraron manzanas que hayan sido modificadas en su geometría campo "the geom"</p>
        </div>
        <div v-if="mzNumIgualGeomDif.length > 0" class="flex items-center justify-center gap-10 px-5">
          <!-- Table -->
          <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
            <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Localidad
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr v-for="(item, index) in mzNumIgualGeomDif" :key="index" class="bg-white border-b">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {{ index + 1 }}
                  </th>
                  <td class="px-6 py-4">
                    {{ item.properties.localidad }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.manzana }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaMzNumIgualGeomDif />
          </div>
        </div>

        <!-- Segunda comparacion -->
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold pt-10 pb-7">
          <h2>Inconsistencias en captura de Mz_Comparacion vs Pol_Red_Inter_Mz</h2>
        </div>
        <div v-if="mzGeomIgualNumDifPol.length > 0" class="flex justify-center pb-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ mzGeomIgualNumDifPol.length }}</span> manzanas que fueron modificadas en su campo "manzana"</p>
        </div>
        <div v-else class="flex justify-center pb-5">
          <p>No se encontraron manzanas que hayan sido modificadas en su campo "manzana"</p>
        </div>
        <div v-if="mzGeomIgualNumDifPol.length > 0" class="flex items-center justify-center gap-10 px-5">
          <!-- Table -->
          <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
            <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Localidad
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana original
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana modificada
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr v-for="(item, index) in mzGeomIgualNumDifPol" :key="index" class="bg-white border-b">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {{ index + 1 }}
                  </th>
                  <td class="px-6 py-4">
                    {{ item.properties.localidad }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.orig_manzana }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.mod_manzana }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <!-- Map -->
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaMzGeomIgualNumDifPol />
          </div>
        </div>
        <!-- <div v-if="mzNumIgualGeomDifPol.length > 0" class="flex justify-center py-5">
          <p>Se encontró un total de <span class="text-red-500 font-semibold">{{ mzNumIgualGeomDifPol.length }}</span> manzanas que fueron modificadas en su geometría, campo "the_geom"</p>
        </div>
        <div v-else class="flex justify-center py-5">
          <p>No se encontraron manzanas que hayan sido modificadas en su geometría campo "the geom"</p>
        </div>
        <div v-if="mzNumIgualGeomDifPol.length > 0" class="flex items-center justify-center gap-10 px-5">
          <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
            <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
              <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    #
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Localidad
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Manzana
                  </th>
                </tr>
              </thead>
              <tbody class="text-center">
                <tr v-for="(item, index) in mzNumIgualGeomDifPol" :key="index" class="bg-white border-b">
                  <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                    {{ index + 1 }}
                  </th>
                  <td class="px-6 py-4">
                    {{ item.properties.localidad }}
                  </td>
                  <td class="px-6 py-4">
                    {{ item.properties.manzana }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="w-[600px] h-[400px]">
            <EtapaTresMapsComponentsMapaMzNumIgualGeomDifPol />
          </div>
        </div> -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/store/sideBar';
const storeSideBar = sideBarStore();
const { resultsValidaciones, fraccionamientosLength, categoriasLength } = storeToRefs(storeSideBar);

// Llena tabla Sobreposición en Pol_Red_Inter_Mz
const sobreposicionPolRed = ref([]);
// Llena tabla Sobreposición en Pol_Red_Inter_Mz
const sobreposicionRedPolRed = ref([]);
// Llena tabla Inconsistencias en captura
const nulosEscuelaLista = ref([]);
const duplicatedManzanas = ref([]);
const mzReseccionamientoFaltantes = ref([]);
const mzPolRedFaltantes = ref([]);
const mzGeomIgualNumDif = ref([]);
const mzGeomIgualNumDifPol = ref([]);
const mzNumIgualGeomDif = ref([]);
const mzNumIgualGeomDifPol = ref([]);
const fraccionamientosRed158 = ref([]);

// Recibimos la data de nuestra store
watch(resultsValidaciones, (newVal) => {
  if (newVal && newVal.data) {
    sobreposicionPolRed.value = newVal.data.sobreposicionPolRed?.lista || [];
    sobreposicionRedPolRed.value = newVal.data.sobreposicionRedPolRed?.lista || [];
    nulosEscuelaLista.value = newVal.data.nulosEscuelaLista || [];

    duplicatedManzanas.value = newVal.data.comparacionManzanas?.duplicatedManzanas ? (newVal.data.comparacionManzanas.duplicatedManzanas[0]?.the_geom?.features || []) : [];
    mzReseccionamientoFaltantes.value = newVal.data.comparacionManzanas?.mzReseccionamientoFaltantes ? (newVal.data.comparacionManzanas.mzReseccionamientoFaltantes[0]?.the_geom?.features || []) : [];
    mzPolRedFaltantes.value = newVal.data.comparacionManzanas?.mzPolRedFaltantes ? (newVal.data.comparacionManzanas.mzPolRedFaltantes[0]?.the_geom?.features || []) : [];
    mzGeomIgualNumDif.value = newVal.data.comparacionTableMzComparacion?.manzanasAlteradas ? (newVal.data.comparacionTableMzComparacion.manzanasAlteradas[0]?.the_geom?.features || []) : [];
    mzGeomIgualNumDifPol.value = newVal.data.comparacionTableMzComparacion?.manzanasAlteradasPol ? (newVal.data.comparacionTableMzComparacion.manzanasAlteradasPol[0]?.the_geom?.features || []) : [];
    mzNumIgualGeomDif.value = newVal.data.comparacionTableMzComparacion?.manzanaAlteradaGeometria ? (newVal.data.comparacionTableMzComparacion.manzanaAlteradaGeometria[0]?.the_geom?.features || []) : [];
    mzNumIgualGeomDifPol.value = newVal.data.comparacionTableMzComparacion?.manzanaAlteradaGeometriaPol ? (newVal.data.comparacionTableMzComparacion.manzanaAlteradaGeometriaPol[0]?.the_geom?.features || []) : [];

    fraccionamientosRed158.value = newVal.data.fraccionamientos?.red15 ? newVal.data.fraccionamientos?.red15 : [];
  }
}, { immediate: true, deep: true });

</script>
