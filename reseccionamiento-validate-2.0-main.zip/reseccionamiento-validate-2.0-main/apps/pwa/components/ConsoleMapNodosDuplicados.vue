<template>
  <LMap
    ref="myMap"
    class="w-full h-full"
    :zoom="zoom"
    :center="center"
    :bounds="bounds"
  >
    <LGeoJson
      :geojson="geoJsonLines"
      :options-style="styleFunctionLines"
    />
    <LGeoJson
      :geojson="geoJsonLinesDup"
      :options-style="styleFunctionLines"
    />
  </LMap>
</template>

<script setup>

const props = defineProps({
  geometry: {
    required: true,
    type: String
  },
  lines: {
    required: true,
    type: String
  }
});
const geoJsonLines = ref(JSON.parse(props.geometry));
const geoJsonLinesDup = ref(JSON.parse(props.lines));
const center = [0, 0];
const zoom = ref(6);
const myMap = ref(null);
const bounds = ref(null);
const styleFunctionLines = computed(() => {
  return () => {
    return {
      weight: 5,
      color: '#EBFF39',
      opacity: 1,
      fillColor: '',
      fillOpacity: 0
    };
  };
});

</script>
<style>
.leaflet-container {
  background: #292d3e !important;
  outline: 0;
}
</style>
