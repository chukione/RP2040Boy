<template>
  <div class="h-full w-[250px] flex flex-col border-r shadow-md py-4">
    <!-- Logo -->
    <div>
      <ConsoleNavLogo />
    </div>
    <!-- Selects -->
    <div class="px-5 flex flex-col gap-4 py-4">
      <!-- Entidad -->
      <div class="flex flex-col gap-1">
        <label class="font-semibold text-ineAzul">Entidad</label>
        <select
          v-if="storeDce.legacyCredentialsApp.goverment === 0"
          v-model="govermentSelected"
          class="shadow-sm border-gray-300 focus:outline-none focus:ring-ineAzul focus:border-ineAzul sm:text-sm rounded-md w-full"
          @change="changeGoverment"
        >
          <option
            v-for="gov in optionsGoverment"
            :key="`goverment-${gov.key}`"
            :value="gov.key"
          >
            {{ gov.text }}
          </option>
        </select>
        <legend v-else class="font-bold text-labelsStats">
          {{ legendGoverment }}
        </legend>
      </div>
      <!-- Distrito -->
      <div class="flex flex-col gap-1">
        <label class="font-semibold text-ineAzul">Distrito</label>
        <select
          v-if="storeDce.legacyCredentialsApp.district === 0"
          v-model="districtSelected"
          class="shadow-sm border-gray-300 focus:outline-none focus:ring-ineAzul focus:border-ineAzul sm:text-sm rounded-md w-full"
          @change="changeDistrict"
        >
          <option
            v-for="dis in optionsDistrict"
            :key="`district-${dis.key}`"
            :value="dis.key"
          >
            {{ dis.text }}
          </option>
        </select>
        <legend v-else class="font-bold text-labelsStats px-5">
          {{ storeDce.legacyCredentialsApp.district }}
        </legend>
      </div>
      <!-- Sección -->
      <div class="flex flex-col gap-1">
        <label class="font-semibold text-ineAzul">Sección</label>
        <select
          v-model="sectionSelected"
          class="shadow-sm border-gray-300 focus:outline-none focus:ring-ineAzul focus:border-ineAzul sm:text-sm rounded-md w-full"
          @change="changeSection"
        >
          <option
            v-for="sec in optionsSeccions"
            :key="`sec-${sec.key}`"
            :value="sec.key"
          >
            {{ sec.text }}
          </option>
        </select>
      </div>
      <!-- Etapa -->
      <div v-if="govermentSelected !== 0 && districtSelected !== 0 && sectionSelected !== 0" class="flex flex-col gap-1">
        <label class="font-semibold text-ineAzul">Etapa</label>
        <select
          v-model="etapaSelected"
          class="shadow-sm border-gray-300 focus:outline-none focus:ring-ineAzul focus:border-ineAzul sm:text-sm rounded-md w-full"
          @change="changeEtapa"
        >
          <option v-for="sec in etapas" :key="`sec-${sec.id}`" :value="sec.id">
            {{ sec.name }}
          </option>
        </select>
      </div>
      <!-- Validate Button -->
      <button
        :class="govermentSelected === 0 || districtSelected === 0 || sectionSelected === 0 || etapaSelected === 0 ? 'disabled hidden' : 'cursor-pointer'"
        class="block text-xs shadow-sm ring-1 ring-inset ring-inePurpura text-white bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa focus-visible:ring-2 focus-visible:ring-primary-500 transition-hover duration-1000 py-[9px] rounded-md font-semibold mt-2"
        @click="validate"
      >
        Validar
      </button>
      <button
        :class="etapaSelected !== 3 || activaButttonReporte === 0 ? 'disabled hidden' : 'cursor-pointer'"
        class="block text-xs shadow-sm ring-1 ring-inset ring-inePurpura text-white bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa focus-visible:ring-2 focus-visible:ring-primary-500 transition-hover duration-1000 py-[9px] rounded-md font-semibold mt-2"
        @click="getPdf()"
      >
        Generar Reporte
      </button>
    </div>
  </div>
</template>

<script setup>
import { sideBarStore } from '@/store/sideBar';
import { indexStore } from '@/store';
import { govermentsLoggin } from '~/services/govermentsLoggin';
const storeDce = ssoStoreDce();
const user = ref(storeDce.user.userName);
const storeIndex = indexStore();
const { $notify } = useNuxtApp();
const { gtag } = useGtag();
const config = useRuntimeConfig();
const { apiUrl } = config.public;
const goverments = ref([]);
const storeSideBar = sideBarStore();
const govermentSelected = ref(0);
const districtSelected = ref(0);
const sectionSelected = ref(0);
const distritos = ref([]);
const activaButttonReporte = ref(0);

onMounted(() => {
  goverments.value = storeSideBar.getGoverments();
  if (storeDce.legacyCredentialsApp && storeDce.legacyCredentialsApp.goverment > 0) {
    govermentSelected.value = storeDce.legacyCredentialsApp.goverment;
    changeGoverment();
  }
  if (storeDce.legacyCredentialsApp && storeDce.legacyCredentialsApp.district > 0) {
    districtSelected.value = storeDce.legacyCredentialsApp.district;
    changeDistrict();
  }
  getEtapas();
});

const optionsGoverment = computed(() => {
  if (goverments.value.length < 0) {
    return;
  }
  const data = [];
  for (const item of goverments.value) {
    data.push({ key: Number(item.id), text: item.name });
  }
  return data;
});
const getPdf = async () => {
  try {
    storeIndex.setWaiting(true);
    const url = `${apiUrl}/pdf/generate?e=${govermentSelected.value}&d=${districtSelected.value}&s=${sectionSelected.value}`;
    const result = await $fetch(url, {
      method: 'GET',
      responseType: 'blob'
    });
    const blobUrl = URL.createObjectURL(result);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = `Reporte-Validacion-Reseccionamiento-${govermentSelected.value}-${districtSelected.value}-${sectionSelected.value}.pdf`; // Especificar el nombre del archivo
    link.click();
    const pdfWindow = window.open(blobUrl, '_blank');
    if (pdfWindow) {
      pdfWindow.focus();
    }
    URL.revokeObjectURL(blobUrl);
    storeIndex.setWaiting(false);
  } catch (error) {
    storeIndex.setWaiting(false);
    $notify({
      title: 'PDF',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger'
    });
  }
};
const getDistricts = async () => {
  if (Number(govermentSelected.value) <= 0) {
    return;
  }
  try {
    storeIndex.setWaiting(true);
    const url = `${apiUrl}/search/distritos?e=${govermentSelected.value}`;
    const result = await $fetch(url, {
      method: 'GET'
    });
    distritos.value = result.data.length > 0 ? result.data : [];
    storeIndex.setWaiting(false);
  } catch (error) {
    storeIndex.setWaiting(false);
    $notify({
      title: 'Distritos',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger'
    });
  }
};

const changeGoverment = () => {
  storeSideBar.setGoverment(Number(govermentSelected.value));
  clearDistrict();
  getDistricts();
  clearSection();
  storeSideBar.setClearDesktop(true);
  storeSideBar.setSetResultsValidaciones([]);
  activaButttonReporte.value = 0;
};
const changeEtapa = () => {
  storeSideBar.setEtapa(etapaSelected.value);
  storeSideBar.setClearDesktop(true);
  storeSideBar.setSetResultsValidaciones([]);
  activaButttonReporte.value = 0;
};
const optionsDistrict = computed(() => {
  const data = [{ key: 0, text: 'Selecciona un distrito' }];
  if (govermentSelected.value <= 0 || distritos.value.length === 0) {
    return data;
  }
  for (const item of distritos.value) {
    data.push({ key: item, text: item });
  }
  return data;
});

const clearDistrict = () => {
  districtSelected.value = 0;
  storeSideBar.setDistrict(Number(districtSelected.value));
};

const clearEtapas = () => {
  etapaSelected.value = 0;
  storeSideBar.setEtapa(Number(etapaSelected.value));
};

const changeDistrict = () => {
  storeSideBar.setDistrict(districtSelected.value);
  storeSideBar.setClearDesktop(true);
  getSections();
  storeSideBar.setSetResultsValidaciones([]);
  activaButttonReporte.value = 0;
};
const changeSection = () => {
  clearEtapas();
  storeSideBar.setSection(sectionSelected.value);
  if (
    Number(govermentSelected.value) > 0 &&
    Number(districtSelected.value) > 0 &&
    Number(sectionSelected.value) > 0
  ) {
    getGeometries();
    storeSideBar.setSetResultsValidaciones([]);
    storeSideBar.setShowMap(true);
  } else {
    storeSideBar.setShowMap(false);
  }
  activaButttonReporte.value = 0;
};
const seccions = ref([]);
const getSections = async () => {
  clearSection();
  if (
    Number(govermentSelected.value) <= 0 ||
    Number(districtSelected.value) <= 0
  ) {
    return;
  }
  try {
    storeIndex.setWaiting(true);
    const url = `${apiUrl}/search/secciones?e=${govermentSelected.value}&d=${districtSelected.value}`;
    const result = await $fetch(url, {
      method: 'GET'
    });
    seccions.value = result.data.length > 0 ? result.data : [];
    storeIndex.setWaiting(false);
  } catch (error) {
    storeIndex.setWaiting(false);
    $notify({
      title: 'Secciones',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger'
    });
  }
};

const getGeometries = async () => {
  if (!govermentSelected.value > 0 && !districtSelected.value > 0 && !sectionSelected.value > 0) {
    return;
  }
  try {
    storeIndex.setWaiting(true);
    const result = await $fetch(
        `${apiUrl}/search/initialgeom?e=${govermentSelected.value}&d=${districtSelected.value}&s=${sectionSelected.value}`
    );
    storeIndex.setWaiting(false);
    storeSideBar.setInitialMapGeometry(result);
    storeSideBar.setShowMap(false);
  } catch (error) {
    storeIndex.setWaiting(false);
    $notify({
      title: 'Geometria',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger'
    });
  }
};

const etapaSelected = ref(0);
const etapas = ref([]);
const getEtapas = () => {
  etapas.value = storeSideBar.getEtapas();
};

watch(etapaSelected, () => {
  if (etapaSelected.value !== 0) {
    storeSideBar.setEtapa(etapaSelected.value);
  }
});

const clearSection = () => {
  sectionSelected.value = 0;
  storeSideBar.setSection(sectionSelected.value);
};
const optionsSeccions = computed(() => {
  const data = [{ key: 0, text: 'Selecciona una seccion' }];
  if (seccions.value.length < 0) {
    return data;
  }

  for (const item of seccions.value) {
    data.push({ key: Number(item), text: item });
  }
  return data;
});

const validate = async () => {
  storeSideBar.setActiveSpinnerData(true);
  let url = `${apiUrl}/search/etapaUno?e=${govermentSelected.value}&d=${districtSelected.value}&s=${sectionSelected.value}&et=${etapaSelected.value}&user=${user.value}`;
  if (etapaSelected.value === 2) { url = `${apiUrl}/search/etapaDos?e=${govermentSelected.value}&d=${districtSelected.value}&s=${sectionSelected.value}&et=${etapaSelected.value}&user=${user.value}`; }
  if (etapaSelected.value === 3) { url = `${apiUrl}/search/etapaTres?e=${govermentSelected.value}&d=${districtSelected.value}&s=${sectionSelected.value}&et=${etapaSelected.value}&user=${user.value}`; }
  const stageTracking = `Etapa${etapaSelected.value}`;
  const metaDataValidate = `${govermentSelected.value}-${districtSelected.value}-${govermentSelected.value}`;
  try {
    gtag('event', 'validate', {
      event_category: `${stageTracking}`,
      event_label: `${metaDataValidate}`,
      value: 1
    });
    storeIndex.setWaiting(true);
    const result = await $fetch(url, { method: 'GET' });
    storeSideBar.setClearDesktop(false);
    storeSideBar.setSetResultsValidaciones(result);
    activaButttonReporte.value = 1;
  } catch (error) {
    $notify({ title: `validaciones etapa ${etapaSelected.value}`, text: 'Ocurrido un error, inténtelo más tarde', type: 'danger' });
  } finally {
    storeIndex.setWaiting(false);
    storeSideBar.setActiveSpinnerData(false);
  }
};
const legendGoverment = computed(() => {
  return govermentsLoggin[storeDce.legacyCredentialsApp.goverment].name;
});

</script>
