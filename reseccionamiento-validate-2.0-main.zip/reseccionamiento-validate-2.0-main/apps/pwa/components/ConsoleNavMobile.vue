<template>
  <div class="md:hidden">
    <transition
      enter-active-class="ease-linear duration-300"
      enter-from-class="opacity-0"
      enter-to-class="opacity-100"
      leave-active-class="duration-500"
      leave-from-class="opacity-100"
      leave-to-class="opacity-0"
    >
      <div
        v-if="sidebarComponent"
        class="fixed inset-0 z-30 transform transition-opacity"
        @click="closeSidebar"
      >
        <div class="absolute inset-0 bg-gray-600 opacity-75" />
      </div>
    </transition>
    <div class="fixed inset-0 flex z-40">
      <transition
        enter-active-class="ease-out duration-300"
        enter-from-class="-translate-x-full"
        enter-to-class="translate-x-0"
        leave-active-class="ease-in duration-300"
        leave-from-class="translate-x-0"
        leave-to-class="-translate-x-full"
      >
        <div
          v-if="sidebarComponent"
          class="flex-1 flex flex-col max-w-xs w-full bg-white transform"
        >
          <div class="absolute top-0 right-0 -mr-14 p-1">
            <button
              v-show="sidebarComponent"
              class="flex items-center justify-center h-12 w-12 rounded-full focus:outline-none"
              @click="closeSidebar"
            >
              <svg
                class="h-6 w-6 text-white"
                stroke="currentColor"
                fill="none"
                viewBox="0 0 24 24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
          <div class="flex-1 h-0 pt-5 pb-4 overflow-y-auto">
            <console-nav-items class="mt-5 px-2" />
          </div>
        </div>
      </transition>
      <div class="flex-shrink-0 w-14">
        <!-- Force sidebar to shrink to fit close icon -->
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { consoleStore } from './../store/console';
const storeConsole = consoleStore();
const { sidebar, sidebarWithDelay } = storeToRefs(storeConsole);
const sidebarComponent = ref();
const sidebarWithDelayComponent = ref();
watch(sidebar, () => {
  sidebarComponent.value = sidebar;
});
watch(sidebarWithDelay, () => {
  sidebarWithDelayComponent.value = sidebarWithDelay;
});
const closeSidebar = () => {
  storeConsole.setSidebar(false);
  setTimeout(() => {
    storeConsole.setSidebarWithDelay(false);
  }, 400);
};

</script>
