<template>
  <div class="w-full h-full relative">
    <LMap
      ref="myMap"
      class="w-full h-full"
      :center="center"
      :bounds="bounds"
      :zoom="zoom"
      @ready="initMap"
    >
      <LGeoJson
        :geojson="geoJsonLines"
        :options-style="styleFunctionLines"
        @mouseover="onMouseOverFeature"
        @click="onClickFeature"
      />
      <LControl position="topright">
        <button
          style="background: white; color: black; padding: 2px; border-radius: 5px; margin-right: 10px;"
          @click="initMap()"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            class="size-6"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
          </svg>
        </button>
        <button
          style="background: white; color: black; padding: 2px; border-radius: 5px;"
          @click="toggleFullscreen"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            class="size-6"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5H4.5v3.75m0 7.5V19.5h3.75m7.5-15h3.75v3.75m0 7.5V19.5h-3.75" />
          </svg>
        </button>
      </LControl>
    </LMap>
  </div>
</template>

<script setup>
import 'leaflet.fullscreen/Control.FullScreen.css';
import 'leaflet.fullscreen';
const props = defineProps({
  geometry: {
    required: true,
    type: String
  }
});
const geoJsonLines = ref(null);
const center = [0, 0];
const zoom = ref(4);
const myMap = ref(null);
const bounds = ref(null);

const initMap = () => {
  if (props.geometry) {
    geoJsonLines.value = JSON.parse(props.geometry);
    const boundsGeometries = L.geoJSON(geoJsonLines.value).getBounds();
    //* validate onlyPint
    const southWest = boundsGeometries.getSouthWest();
    const northEast = boundsGeometries.getNorthEast();
    if (southWest.lat === northEast.lat && southWest.lng === northEast.lng) {
      myMap.value.leafletObject.setView([southWest.lat, southWest.lng], 4);
      return;
    }
    //* end
    bounds.value = boundsGeometries;
    myMap.value.leafletObject.fitBounds(bounds.value);
  }
};

const styleFunctionLines = computed(() => {
  return () => {
    return {
      weight: 5,
      color: '#EBFF39',
      opacity: 1,
      fillColor: '',
      fillOpacity: 0
    };
  };
});
const onMouseOverFeature = (event) => {
  const layer = event.layer;
  const gid = layer.feature?.geometry.properties.gid;
  if (gid !== undefined) {
    layer.bindTooltip(`GID: ${gid}`, { sticky: true }).openTooltip();
  }
};

const toggleFullscreen = () => {
  if (myMap.value) {
    myMap.value.leafletObject.toggleFullscreen();
    myMap.value.leafletObject.on('fullscreenchange', () => {
      myMap.value.leafletObject.fitBounds(bounds.value);
    });
  }
};

function onClickFeature (event) {
  const layer = event.layer;
  const feature = layer.feature;
  if (feature && feature.geometry && feature.geometry.coordinates) {
    const bounds = L.geoJSON(feature).getBounds();
    myMap.value.leafletObject.flyToBounds(bounds, {
      duration: 2,
      easeLinearity: 0.25
    });
  }
}
</script>

<style>
.leaflet-container {
  background: #292d3e !important;
  outline: 0;
}

.leaflet-container .leaflet-interactive:focus {
outline: none;
border: none;
}
</style>
