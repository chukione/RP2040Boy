<template>
  <!-- Table Sobreposición de la capa de red -->
  <div>
    <div class="flex items-center justify-center gap-10 px-5 mb-2">
      <div
        v-if="resultsValidaciones.data.sobreposicionGeom && resultsValidaciones.data.sobreposicionGeom
          .lista.length>0"
        class="flex justify-center pb-5"
      >
        <p
          v-if="resultsValidaciones.data.sobreposicionGeom
            .lista.length>1"
        >
          Se encontró un total de <span class="text-red-500 font-bold">{{ resultsValidaciones.data.sobreposicionGeom
            .lista.length }}</span> geometrías sobreposicionadas.
        </p>
        <p
          v-else
        >
          Se encontró <span class="text-red-500 font-bold">1</span> geometría sobreposicionada.
        </p>
      </div>
      <div v-else class="flex justify-center pb-5">
        <p>
          No hay Sobreposición de la capa de red
        </p>
      </div>
    </div>
    <div v-if="resultsValidaciones.data.sobreposicionGeom && resultsValidaciones.data.sobreposicionGeom.lista.length>0" class="flex justify-center gap-10 px-5">
      <!-- Table -->
      <div>
        <div class="h-[400px] overflow-auto flex items-center justify-center">
          <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
            <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
              <tr>
                <th scope="col" class="px-6 py-3">
                  GID
                </th>
                <th scope="col" class="px-6 py-3">
                  GID(S) REPETIDO(S)
                </th>
              </tr>
            </thead>
            <tbody class="text-center">
              <tr
                v-for="item in resultsValidaciones.data.sobreposicionGeom.lista"
                :key="`gid-${item.key}`"
                class="bg-white border-b"
              >
                <td class="px-6 py-4">
                  {{ item.gid }}
                </td>
                <td class="px-6 py-4">
                  {{ item.repetidos.join(', ') }}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <!-- Map -->
      <div class="w-[600px] h-[400px]">
        <ConsoleMapGeometryDuplicated :geometry="resultsValidaciones.data.sobreposicionGeom.geometry" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { sideBarStore } from './../store/sideBar';
const storeSideBar = sideBarStore();
const { resultsValidaciones } = storeToRefs(storeSideBar);

</script>
