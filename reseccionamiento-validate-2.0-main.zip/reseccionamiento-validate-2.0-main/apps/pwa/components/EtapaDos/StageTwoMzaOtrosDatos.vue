<template>
  <div>
    <div v-if="resultsValidaciones.data.validarMzasOtrosDatos && resultsValidaciones.data.validarMzasOtrosDatos.length>0" class="flex items-center justify-center gap-10 px-20">
      <table class="w-full text-sm text-left rtl:text-right text-gray-500 border">
        <thead class="text-xs text-white uppercase text-center bg-ineAzul">
          <tr>
            <th scope="col" class="px-6 py-3">
              GID
            </th>
            <th scope="col" class="px-6 py-3">
              Entidad
            </th>
            <th scope="col" class="px-6 py-3">
              Distrito
            </th>
            <th scope="col" class="px-6 py-3">
              Sección
            </th>
          </tr>
        </thead>
        <tbody class="text-center">
          <tr
            v-for="item in resultsValidaciones.data.validarMzasOtrosDatos"
            :key="`gid-${item.key}`"
            class="bg-white border-b"
          >
            <td class="px-6 py-4">
              {{ item.gid }}
            </td>
            <td class="px-6 py-4">
              {{ item.entidad }}
            </td>
            <td class="px-6 py-4">
              {{ item.distrito }}
            </td>
            <td class="px-6 py-4">
              {{ item.seccion }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-else class="flex items-center justify-center gap-10 px-5 mb-2">
      <p>
        No se encontraron Manzanas con otros datos.
      </p>
    </div>
  </div>
</template>

<script setup>
import { sideBarStore } from './../store/sideBar';
const storeSideBar = sideBarStore();
const { resultsValidaciones } = storeToRefs(storeSideBar);

</script>
