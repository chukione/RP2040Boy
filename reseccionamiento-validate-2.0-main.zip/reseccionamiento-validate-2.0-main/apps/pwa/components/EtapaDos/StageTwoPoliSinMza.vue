<template>
  <!-- Table Manzanas sin poligono -->
  <div>
    <div class="flex items-center justify-center gap-10 px-5 mb-2">
      <div
        v-if="resultsValidaciones.data.validarPoligonosSinMza && resultsValidaciones.data.validarPoligonosSinMza
          .lista.length>0"
        class="flex justify-center pb-5"
      >
        <p
          v-if="resultsValidaciones.data.validarPoligonosSinMza
            .lista.length>1"
        >
          Se encontró un total de <span class="text-red-500 font-bold">{{ resultsValidaciones.data.validarPoligonosSinMza
            .lista.length }}</span> Poligonos sin Manzanas.
        </p>
        <p
          v-else
        >
          Se encontró <span class="text-red-500 font-bold">1</span> Poligono sin Manzana.
        </p>
      </div>
      <div v-else class="flex justify-center pb-5">
        <p>
          No hay Poligonos sin Manzanas.
        </p>
      </div>
    </div>
    <div v-if="resultsValidaciones.data.validarPoligonosSinMza && resultsValidaciones.data.validarPoligonosSinMza.lista.length>0" class="flex justify-center gap-10 px-5">
      <!-- Table -->
      <div>
        <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
          <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
            <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
              <tr>
                <th scope="col" class="px-6 py-3">
                  #
                </th>
                <th scope="col" class="px-6 py-3">
                  GID
                </th>
              </tr>
            </thead>
            <tbody class="text-center">
              <tr
                v-for="(item, index) in resultsValidaciones.data.validarPoligonosSinMza.lista"
                :key="`gid-${item.key}`"
                class="bg-white border-b"
              >
                <td class="px-6 py-4">
                  {{ index + 1 }}
                </td>
                <td class="px-6 py-4">
                  {{ item.gid }}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <!-- Map -->
      <div class="w-[600px] h-[400px]">
        <EtapaDosMapManzanaSinPoligonos :geometry="resultsValidaciones.data.validarPoligonosSinMza.geometry" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { sideBarStore } from './../store/sideBar';
const storeSideBar = sideBarStore();
const { resultsValidaciones } = storeToRefs(storeSideBar);

</script>
