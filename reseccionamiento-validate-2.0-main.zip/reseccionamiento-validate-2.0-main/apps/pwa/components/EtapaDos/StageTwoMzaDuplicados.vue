<template>
  <div>
    <div v-if="resultsValidaciones.data.validarMzasDuplicadas && resultsValidaciones.data.validarMzasDuplicadas.length>0" class="flex items-center justify-center gap-10 px-20">
      <table class="w-full text-sm text-left rtl:text-right text-gray-500 border">
        <thead class="text-xs text-white uppercase text-center bg-ineAzul">
          <tr>
            <th scope="col" class="px-6 py-3">
              GIDs
            </th>
            <th scope="col" class="px-6 py-3">
              Entidad
            </th>
            <th scope="col" class="px-6 py-3">
              Distrito
            </th>
            <th scope="col" class="px-6 py-3">
              Sección
            </th>
            <th scope="col" class="px-6 py-3">
              Municipio
            </th>
            <th scope="col" class="px-6 py-3">
              Localidad
            </th>
            <th scope="col" class="px-6 py-3">
              Manzana
            </th>
          </tr>
        </thead>
        <tbody class="text-center">
          <tr
            v-for="item in resultsValidaciones.data.validarMzasDuplicadas"
            :key="`gid-${item.key}`"
            class="bg-white border-b"
          >
            <td class="px-6 py-4">
              {{ item.gids }}
            </td>
            <td class="px-6 py-4">
              {{ item.entidad }}
            </td>
            <td class="px-6 py-4">
              {{ item.distrito }}
            </td>
            <td class="px-6 py-4">
              {{ item.seccion }}
            </td>
            <td class="px-6 py-4">
              {{ item.municipio }}
            </td>
            <td class="px-6 py-4">
              {{ item.localidad }}
            </td>
            <td class="px-6 py-4">
              {{ item.manzana }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-else class="flex items-center justify-center gap-10 px-5 mb-2">
      <p>
        No se encontraron Manzanas con datos duplicados
      </p>
    </div>
  </div>
</template>

<script setup>
import { sideBarStore } from './../store/sideBar';
const storeSideBar = sideBarStore();
const { resultsValidaciones } = storeToRefs(storeSideBar);

</script>
