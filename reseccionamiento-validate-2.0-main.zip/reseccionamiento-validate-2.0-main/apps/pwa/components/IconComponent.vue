<script setup>
const props = defineProps({
  icon: {
    type: Array,
    required: true
  }
});

const { icon } = toRefs(props);
</script>
<template>
  <ClientOnly>
    <FontAwesomeIcon :icon="icon" />
  </ClientOnly>
</template>
