<!-- eslint-disable vue/require-explicit-emits -->
<template>
  <div class="bg-white shadow-lg rounded-lg pointer-events-auto">
    <div class="rounded-lg shadow-xs overflow-hidden">
      <div class="p-4">
        <div class="flex items-start">
          <!-- icon -->
          <div class="flex-shrink-0">
            <svg
              fill="none"
              stroke="currentColor"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              viewBox="0 0 24 24"
              class="w-6 h-6"
              :class="[
                'danger' == props.notify.type ? 'text-red-400' : '',
                'info' == props.notify.type ? 'text-blue-400' : '',
                'success' == props.notify.type ? 'text-green-400' : '',
                'warning' == props.notify.type ? 'text-yellow-400' : '',
              ]"
            >
              <path :d="iconsNotify[props.notify.type]" />
            </svg>
          </div>
          <!-- text -->
          <div class="ml-3 flex-1 pt-0.5">
            <p
              v-if="props.notify.title"
              class="text-sm leading-5 font-medium text-gray-900"
            >
              {{ props.notify.title }}
            </p>
            <p
              class="text-sm leading-5 text-gray-500"
              :class="props.notify.title ? 'mt-1' : ''"
            >
              {{ props.notify.text }}
            </p>
          </div>
          <!-- close  -->
          <div class="ml-4 flex-shrink-0 flex">
            <button
              class="inline-flex text-gray-400 focus:outline-none focus:text-gray-900"
              @click="removeDiv"
            >
              <svg fill="currentColor" viewBox="0 0 20 20" class="w-5 h-5">
                <path
                  fill-rule="evenodd"
                  d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                  clip-rule="evenodd"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { icons } from '@/services/icons';
const props = defineProps({
  notify: {
    required: true,
    type: Object
  }
});
const iconsNotify = ref();
iconsNotify.value = icons.notify;
const emit = defineEmits(['remove']);
const removeDiv = () => {
  emit('remove', props.notify.id);
};
</script>
