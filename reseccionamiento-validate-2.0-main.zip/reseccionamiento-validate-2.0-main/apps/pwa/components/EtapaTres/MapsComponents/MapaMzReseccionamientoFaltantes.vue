<template>
  <div class="w-full h-full relative">
    <LMap
      ref="myMap"
      class="w-full h-full"
      :min-zoom="minZoom"
      :max-zoom="maxZoom"
      :max-bounds="mexicoBounds"
      :zoom="zoom"
      :center="center"
      :bounds="combinedBounds"
      @ready="initMap"
    >
      <LGeoJson
        v-if="geoJSON.mzReseccionamientoFaltantes"
        :geojson="geoJSON.mzReseccionamientoFaltantes"
        :options-style="styleFunctionMzReseccionamientoFaltantes"
        @mouseover="onMouseOverFeature"
        @click="onClickFeature"
      />
      <!-- Centrar y Fullscreen -->
      <LControl position="topright">
        <button
          style="background: white; color: black; padding: 2px; border-radius: 5px; margin-right: 10px;"
          @click="initMap"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            class="size-6"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
          </svg>
        </button>
        <button
          style="background: white; color: black; padding: 2px; border-radius: 5px;"
          @click="toggleFullscreen"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            class="size-6"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5H4.5v3.75m0 7.5V19.5h3.75m7.5-15h3.75v3.75m0 7.5V19.5h-3.75" />
          </svg>
        </button>
      </LControl>
    </LMap>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, nextTick } from 'vue';
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/store/sideBar';
import 'leaflet-fullscreen/dist/Leaflet.fullscreen.js';
import 'leaflet-fullscreen/dist/leaflet.fullscreen.css';

const storeSideBar = sideBarStore();
const { initialMapGeometry, resultsValidaciones } = storeToRefs(storeSideBar);

const geoJSON = ref({
  seccion: null,
  manzana: null,
  red: null,
  schools: []
});

const shouldRenderMap = ref(false);
const combinedBounds = ref(null);
const map = ref(null);
const center = ref([23.6345, -102.5528]); // Coordenadas iniciales -> de México
const zoom = ref(6); // Zoom Inicial
const minZoom = ref(6); // Zoom minimo, limitado para no salir de México
const maxZoom = ref(20); // Zoom máximo
// Define los límites geográficos de México
const mexicoBounds = [
  [14.5345, -118.3648], // Suroeste de México
  [32.7187, -86.7108] // Noreste de México
];

watch([resultsValidaciones, initialMapGeometry], ([newResultsValidaciones, newInitialMapGeometry]) => {
  if (newResultsValidaciones && Object.keys(newResultsValidaciones).length > 0) {
    shouldRenderMap.value = true;
    if (newInitialMapGeometry && newInitialMapGeometry.data) {
      geoJSON.value.mzReseccionamientoFaltantes = newResultsValidaciones.data.comparacionManzanas.mzReseccionamientoFaltantes[0].the_geom;

      nextTick(() => {
        const boundsMzReseccionamientoFaltantes = L.geoJSON(geoJSON.value.mzReseccionamientoFaltantes).getBounds();
        combinedBounds.value = boundsMzReseccionamientoFaltantes;
      });
    }
  } else {
    shouldRenderMap.value = false;
  }
}, { immediate: true, deep: true });

onMounted(() => {
  nextTick(() => {
    map.value = map.value?.$el?.__vueParentComponent?.ctx?.mapObject;
  });
});

const styleFunctionMzReseccionamientoFaltantes = computed(() => {
  return () => ({
    color: '#FFFFFF',
    weight: 1, // Grosor de las líneas
    opacity: 1,
    fillColor: '#6182CC', // Color de relleno azul
    fillOpacity: 0.8
  });
});

function onMouseOverFeature (event) {
  const layer = event.layer;
  const manzana = layer.feature?.properties.manzana;
  if (manzana !== undefined) {
    layer.bindTooltip(`Manzana: ${manzana}`, { sticky: true }).openTooltip();
  }
}

const myMap = ref(null);
const initMap = () => {
  if (myMap.value) {
    myMap.value.leafletObject.fitBounds(combinedBounds.value);
  }
};

const toggleFullscreen = () => {
  if (myMap.value) {
    myMap.value.leafletObject.toggleFullscreen();
    myMap.value.leafletObject.on('fullscreenchange', () => {
      myMap.value.leafletObject.fitBounds(combinedBounds.value);
    });
  }
};

function onClickFeature (event) {
  const layer = event.layer;
  const feature = layer.feature;
  if (feature && feature.geometry && feature.geometry.coordinates) {
    const bounds = L.geoJSON(feature).getBounds();
    myMap.value.leafletObject.flyToBounds(bounds, {
      duration: 2,
      easeLinearity: 0.25
    });
  }
}
</script>

<style>
.leaflet-container .leaflet-interactive:focus {
  outline: none;
  border: none;
}
</style>
