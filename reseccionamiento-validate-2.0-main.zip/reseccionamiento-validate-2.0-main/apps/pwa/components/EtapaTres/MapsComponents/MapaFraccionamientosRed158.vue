<template>
  <div class="w-full h-full relative">
    <!-- Mapa -->
    <LMap
      ref="myMap"
      class="w-full h-full"
      :min-zoom="minZoom"
      :max-zoom="maxZoom"
      :max-bounds="mexicoBounds"
      :zoom="zoom"
      :center="center"
      :bounds="combinedBounds"
      @ready="initMap"
    >
      <template v-if="Object.keys(geoJSONByCategoria).length">
        <div v-for="(features, categoria) in geoJSONByCategoria" :key="`poligono-${categoria}`">
          <LGeoJson
            v-if="layersVisibility[categoria]"
            :geojson="{ type: 'FeatureCollection', features: features }"
            :options-style="getStyleFunction(categoria)"
            @mouseover="onMouseOverFeature"
            @click="onClickFeature"
          />
        </div>
      </template>

      <!-- Control de capas -->
      <div class="flex flex-col gap-2 absolute top-2 right-2 z-[1000]">
        <div
          v-for="(color, categoria) in categoriaColors"
          :key="`control-${categoria}`"
          class="flex justify-start items-center gap-1"
        >
          <button
            class="h-5 w-5 border border-black rounded"
            :style="{ backgroundColor: color }"
            :title="'Habilitar/deshabilitar categoría ' + categoria"
            @click="toggleLayer(categoria)"
          />
          <p class="text-white text-[10px]">
            Categoría {{ categoria }}
          </p>
        </div>
      </div>

      <!-- Centrar y Fullscreen -->
      <LControl position="bottomleft">
        <button
          style="background: white; color: black; padding: 2px; border-radius: 5px; margin-right: 10px;"
          @click="toggleFullscreen"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            class="size-6"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5H4.5v3.75m0 7.5V19.5h3.75m7.5-15h3.75v3.75m0 7.5V19.5h-3.75" />
          </svg>
        </button>
        <button
          style="background: white; color: black; padding: 2px; border-radius: 5px;"
          @click="initMap"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            class="size-6"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
          </svg>
        </button>
      </LControl>
    </LMap>
  </div>
</template>

<script setup>
import { ref, watch, onMounted, nextTick } from 'vue';
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/store/sideBar';

const storeSideBar = sideBarStore();
const { initialMapGeometry, resultsValidaciones } = storeToRefs(storeSideBar);

const geoJSON = ref({
  seccion: null,
  manzana: null,
  red: null,
  schools: []
});

const shouldRenderMap = ref(false);
const combinedBounds = ref(null);
const map = ref(null);
const myMap = ref(null);
const center = ref([23.6345, -102.5528]); // Coordenadas iniciales -> de México
const zoom = ref(6); // Zoom Inicial
const minZoom = ref(6); // Zoom minimo, limitado para no salir de México
const maxZoom = ref(20); // Zoom máximo
const mexicoBounds = [
  [14.5345, -118.3648], // Suroeste de México
  [32.7187, -86.7108] // Noreste de México
];

const categoriaColors = ref({});
const geoJSONByCategoria = ref({});
const layersVisibility = ref({});
const { getColorBySt } = usePoligonoColors();

watch([resultsValidaciones, initialMapGeometry], ([newResultsValidaciones, newInitialMapGeometry]) => {
  if (newResultsValidaciones && Object.keys(newResultsValidaciones).length > 0) {
    shouldRenderMap.value = true;
    if (newInitialMapGeometry && newInitialMapGeometry.data) {
      geoJSON.value.polRedInterMz158 = newResultsValidaciones.data.fraccionamientos?.red15;

      // Generar colores únicos para cada categoría
      const uniqueCategorias = [...new Set(geoJSON.value.polRedInterMz158.features.map(categoria => categoria.properties.categoria))];

      categoriaColors.value = uniqueCategorias.reduce((acc, categoria) => {
        acc[categoria] = getColorBySt(categoria); // Obtener color por st
        return acc;
      }, {});

      geoJSONByCategoria.value = geoJSON.value.polRedInterMz158.features.reduce((acc, feature) => {
        const poligono = feature.properties.categoria;
        if (!acc[poligono]) {
          acc[poligono] = [];
        }
        acc[poligono].push(feature);
        return acc;
      }, {});

      // Inicializar visibilidad de capas
      layersVisibility.value = uniqueCategorias.reduce((acc, categoria) => {
        acc[categoria] = true;
        return acc;
      }, {});

      // Guardamos en el store la cantidad de categorias
      storeSideBar.setCategoriasLength(Object.keys(layersVisibility.value).length);

      nextTick(() => {
        combinedBounds.value = L.geoJSON(geoJSON.value.polRedInterMz158).getBounds();
      });
    }
  } else {
    shouldRenderMap.value = false;
  }
}, { immediate: true, deep: true });

onMounted(() => {
  nextTick(() => {
    map.value = map.value?.$el?.__vueParentComponent?.ctx?.mapObject;
  });
});

function getStyleFunction (categoria) {
  return () => ({
    color: categoriaColors.value[categoria],
    opacity: 1,
    fillOpacity: 0.5,
    weight: 1 // Ajusta el valor de weight para hacer la línea más delgada
  });
}

function onMouseOverFeature (event) {
  const layer = event.layer;
  const categoria = layer.feature?.properties.categoria;
  if (categoria !== undefined) {
    layer.bindTooltip(`Categoria: ${categoria}`, { sticky: true }).openTooltip();
  }
}

const initMap = () => {
  if (myMap.value) {
    myMap.value.leafletObject.fitBounds(combinedBounds.value);
  }
};

const toggleFullscreen = () => {
  if (myMap.value) {
    myMap.value.leafletObject.toggleFullscreen();
    myMap.value.leafletObject.on('fullscreenchange', () => {
      myMap.value.leafletObject.fitBounds(combinedBounds.value);
    });
  }
};

function onClickFeature (event) {
  const layer = event.layer;
  const feature = layer.feature;
  if (feature && feature.geometry && feature.geometry.coordinates) {
    const bounds = L.geoJSON(feature).getBounds();
    myMap.value.leafletObject.flyToBounds(bounds, {
      duration: 2,
      easeLinearity: 0.25
    });
  }
}

// Función para alternar la visibilidad de una capa
const toggleLayer = (layer) => {
  layersVisibility.value[layer] = !layersVisibility.value[layer];
};
</script>

<style>
.leaflet-container .leaflet-interactive:focus {
outline: none;
border: none;
}
</style>
