<template>
  <div class="w-full h-full relative">
    <!-- Mapa -->
    <LMap
      ref="myMap"
      class="w-full h-full"
      :min-zoom="minZoom"
      :max-zoom="maxZoom"
      :max-bounds="mexicoBounds"
      :zoom="zoom"
      :center="center"
      :bounds="combinedBounds"
      @ready="handleMapReady"
    >
      <LGeoJson
        v-if="geoJSON.polRedInterMz"
        :geojson="geoJSON.polRedInterMz"
        :options-style="styleFunctionpolRedInterMz"
        @mouseover="onMouseOverFeature"
        @click="onClickFeature"
      />
      <!-- Control de capas -->
      <LControl position="topright">
        <!-- Botones para habilitar/deshabilitar capas -->
        <div class="flex flex-col gap-2">
          <div v-if="Object.keys(geoJSON.polRedInterMz).length && Object.keys(geoJSON.polRedInterMz.features).length" class="flex justify-start items-center gap-1">
            <button
              class="h-5 w-5 border border-black rounded bg-[#ffbf00] hover:bg-yellow-700 text-white transition-all duration-500"
              :title="'Habilitar/deshabilitar servicios'"
              @click="toggleLayer('schools')"
            />
            <p class="text-white text-[10px]">
              Servicios
            </p>
          </div>
          <div v-if="Object.keys(geoJSONByPoligono).length" class="flex justify-start items-center gap-1">
            <button
              class="h-5 w-5 border border-black rounded shadow bg-red-500 hover:bg-red-700 transition-all duration-500"
              :title="'Habilitar/deshabilitar fraccionamientos'"
              @click="toggleLayer('poligonos')"
            />
            <p class="text-white text-[10px]">
              Fraccionamientos
            </p>
          </div>
        </div>
      </LControl>
      <!-- Centrar y Fullscreen -->
      <LControl position="bottomleft">
        <button
          style="background: white; color: black; padding: 2px; border-radius: 5px;  margin-right: 10px;"
          @click="toggleFullscreen"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            class="size-6"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5H4.5v3.75m0 7.5V19.5h3.75m7.5-15h3.75v3.75m0 7.5V19.5h-3.75" />
          </svg>
        </button>
        <button
          style="background: white; color: black; padding: 2px; border-radius: 5px;"
          @click="initMap"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            class="size-6"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
          </svg>
        </button>
      </LControl>
      <template v-if="layersVisibility.schools">
        <l-marker
          v-for="school in geoJSON.schools"
          :key="`school-${school.properties.gid}`"
          :lat-lng="[
            school.geometry.coordinates[1],
            school.geometry.coordinates[0],
          ]"
          :draggable="false"
        >
          <l-icon :icon-anchor="[22, 22]" :icon-size="[22, 22]">
            <img src="@/assets/img/game-icons--bank.svg">
          </l-icon>
          <LTooltip> {{ school.properties.tipo.charAt(0).toUpperCase() + school.properties.tipo.slice(1).toLowerCase() }} </LTooltip>
        </l-marker>
      </template>

      <template v-if="layersVisibility.poligonos">
        <l-marker
          v-for="marker in markers"
          :key="`marker-${marker.id}`"
          :lat-lng="[marker.lat, marker.lng]"
          :draggable="false"
        >
          <l-icon :icon-anchor="[12, 12]" :icon-size="[24, 24]">
            <div class="custom-marker">
              {{ marker.poligono_ }}
            </div>
          </l-icon>
        </l-marker>
      </template>

      <template v-if="layersVisibility.poligonos && Object.keys(geoJSONByPoligono).length">
        <LGeoJson
          v-for="(features, poligono_) in geoJSONByPoligono"
          :key="`poligono-${poligono_}`"
          :geojson="{ type: 'FeatureCollection', features: features }"
          :options-style="getStyleFunction(poligono_)"
          @mouseover="onMouseOverFeature"
          @click="onClickFeature"
        />
      </template>
    </LMap>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, nextTick } from 'vue';
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/store/sideBar';

const { $notify } = useNuxtApp();

const storeSideBar = sideBarStore();
const { initialMapGeometry, resultsValidaciones } = storeToRefs(storeSideBar);
const { getColorBySt } = usePoligonoColors();

const geoJSON = ref({
  seccion: null,
  manzana: null,
  red: null,
  schools: []
});

const shouldRenderMap = ref(false);
const combinedBounds = ref(null);
const map = ref(null);
const myMap = ref(null);
const center = ref([23.6345, -102.5528]); // Coordenadas iniciales -> de México
const zoom = ref(6); // Zoom Inicial
const minZoom = ref(6); // Zoom minimo, limitado para no salir de México
const maxZoom = ref(20); // Zoom máximo
const mexicoBounds = [
  [14.5345, -118.3648], // Suroeste de México
  [32.7187, -86.7108] // Noreste de México
];

const poligonoColors = ref({});
const markers = ref([]);
const geoJSONByPoligono = ref({});

// Estado reactivo para controlar la visibilidad de las capas y los markers
const layersVisibility = ref({
  schools: true,
  poligonos: true
});

// Estado reactivo para controlar si se debe ejecutar la función initMap
const mapReady = ref(false);

// Función para alternar la visibilidad de una capa o markers
const toggleLayer = (layer) => {
  layersVisibility.value[layer] = !layersVisibility.value[layer];
};

watch([resultsValidaciones, initialMapGeometry], ([newResultsValidaciones, newInitialMapGeometry]) => {
  if (!newResultsValidaciones || Object.keys(newResultsValidaciones).length === 0) {
    shouldRenderMap.value = false;
    mapReady.value = false;
    $notify({
      title: 'Mapa inconsistencias en captura',
      text: 'El campo de resultsValidaciones es null o vacío',
      type: 'danger'
    });
    return;
  }

  if (!newInitialMapGeometry || !newInitialMapGeometry.data) {
    shouldRenderMap.value = false;
    mapReady.value = false;
    $notify({
      title: 'Mapa inconsistencias en captura',
      text: 'El campo de initialMapGeometry es null o vacío',
      type: 'danger'
    });
    return;
  }

  const polRedInterMz = newResultsValidaciones.data?.polRedInterMz;
  const redEscuelaServicios = polRedInterMz?.redEscuelaServicios?.features;
  const poligonosRed = polRedInterMz?.poligonosRed?.features;

  // Verificar la existencia de redEscuelaServicios y poligonosRed
  if (!redEscuelaServicios || !Array.isArray(redEscuelaServicios)) {
    shouldRenderMap.value = false;
    mapReady.value = false;
    $notify({
      title: 'Mapa inconsistencias en captura',
      text: 'El campo redEscuelaServicios o sus features son nulos o no es un array',
      type: 'danger'
    });
    return;
  }

  if (!poligonosRed || !Array.isArray(poligonosRed)) {
    shouldRenderMap.value = false;
    mapReady.value = false;
    $notify({
      title: 'Mapa inconsistencias en captura',
      text: 'El campo poligonosRed o sus features son nulos o no es un array',
      type: 'danger'
    });
    return;
  }

  shouldRenderMap.value = true;
  mapReady.value = true;

  geoJSON.value.schools = redEscuelaServicios;
  geoJSON.value.polRedInterMz = polRedInterMz.poligonosRed;

  // Generar colores únicos para cada poligono_
  const uniquePoligonos = [...new Set(poligonosRed.map(feature => feature.properties.poligono_))];
  poligonoColors.value = uniquePoligonos.reduce((acc, poligono) => {
    if (poligono !== null && poligono !== 0) {
      acc[poligono] = getColorBySt(poligono); // Obtener color por st
    }
    return acc;
  }, {});

  // Agrupar los polígonos por poligono_
  geoJSONByPoligono.value = poligonosRed.reduce((acc, feature) => {
    const poligono = feature.properties.poligono_;
    if (poligono !== null && poligono !== 0) {
      if (!acc[poligono]) {
        acc[poligono] = [];
      }
      acc[poligono].push(feature);
    }
    return acc;
  }, {});

  // Guardamos en el store la cantidad de fraccionamientos correspondientes a poligono_
  storeSideBar.setFraccionamientosLength(Object.keys(geoJSONByPoligono.value).length);

  // Generar marcadores en el centro de cada geometría
  markers.value = poligonosRed
    .filter(feature => feature.properties.poligono_ !== null && feature.properties.poligono_ !== 0)
    .map((feature) => {
      const centroid = getCentroid(feature.geometry.coordinates[0]);
      return {
        id: feature.properties.gid,
        poligono_: feature.properties.poligono_,
        manzana: feature.properties.manzana,
        lat: centroid[1],
        lng: centroid[0],
        features: feature
      };
    });

  nextTick(() => {
    combinedBounds.value = L.geoJSON(poligonosRed).getBounds();
  });
}, { immediate: true, deep: true });

onMounted(() => {
  nextTick(() => {
    map.value = map.value?.$el?.__vueParentComponent?.ctx?.mapObject;
  });
});

const handleMapReady = () => {
  if (mapReady.value) {
    initMap();
  }
};

const styleFunctionpolRedInterMz = computed(() => {
  return () => ({
    color: '#FFFFFF',
    weight: 1, // Grosor de las líneas
    opacity: 1,
    fillColor: '#6182CC', // Color de relleno azul
    fillOpacity: 0.5
  });
});

function getStyleFunction (poligono_) {
  return () => ({
    color: poligonoColors.value[poligono_],
    opacity: 1,
    fillOpacity: 0.5
  });
}

function getCentroid (coords) {
  const centroid = [0, 0];
  coords.forEach((coord) => {
    centroid[0] += coord[0];
    centroid[1] += coord[1];
  });
  centroid[0] /= coords.length;
  centroid[1] /= coords.length;
  return centroid;
}

function onMouseOverFeature (event) {
  const layer = event.layer;
  const manzana = layer.feature?.properties.manzana;
  if (manzana !== undefined) {
    layer.bindTooltip(`Manzana: ${manzana}`, { sticky: true }).openTooltip();
  }
}

const initMap = () => {
  if (myMap.value) {
    myMap.value.leafletObject.fitBounds(combinedBounds.value);
  }
};

const toggleFullscreen = () => {
  if (myMap.value) {
    myMap.value.leafletObject.toggleFullscreen();
    myMap.value.leafletObject.on('fullscreenchange', () => {
      myMap.value.leafletObject.fitBounds(combinedBounds.value);
    });
  }
};

function onClickFeature (event) {
  const layer = event.layer;
  const feature = layer.feature;
  if (feature && feature.geometry && feature.geometry.coordinates) {
    const bounds = L.geoJSON(feature).getBounds();
    myMap.value.leafletObject.flyToBounds(bounds, {
      duration: 2,
      easeLinearity: 0.25
    });
  }
}
</script>

<style>
.custom-marker {
  border-radius: 50%;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  color: black;
  -webkit-text-stroke: 1px aliceblue; /* Borde del texto */
  font-weight: 800;
  text-align: center;
}

.leaflet-container .leaflet-interactive:focus {
outline: none;
border: none;
}
</style>
