<template>
  <div class="w-full h-auto mb-9 bg-[#f6d5da] rounded">
    <form @submit.prevent="">
      <div class="shadow overflow-hidden">
        <div class="px-4 py-5 sm:p-6">
          <div class="grid grid-cols-6 gap-4">
            <!-- userName -->
            <div class="col-span-6">
              <label
                for="userName"
                class="block text-base font-bold leading-5 text-[#c13d60]"
              >Etapa</label>
              <div class="mt-1 flex items-center">
                <div class="flex-1 flex rounded-md">
                  <select
                    class="mt-1 block w-60 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-[#e58799] focus:border-[#e58799] sm:text-sm rounded-md"
                  >
                    <option
                      v-for="sec in etapas"
                      :key="`sec-${sec.id}`"
                      :value="sec.id"
                    >
                      {{ sec.name }}
                    </option>
                  </select>
                  <button
                    class="ml-2 inline-flex items-center py-2 px-3 rounded border border-gray-300 text-white text-base font-bold bg-[#c13d60]"
                    type="submit"
                  >
                    Validar
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
</template>

<script setup>
import { sideBarStore } from '@/store/sideBar';
const storeSideBar = sideBarStore();
const etapas = ref([]);
onMounted(async () => {
  etapas.value = await storeSideBar.getEtapas();
});
</script>
