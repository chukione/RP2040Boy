<template>
  <div>
    <div v-if="'data' in resultsValidaciones">
      <!-- Title -->
      <div class="text-center bg-ineMorado text-white h-12 flex items-center justify-center text-lg font-semibold">
        <h2>Validación de geometrías Etapa 2</h2>
      </div>
      <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold">
        <h2>Capa red</h2>
      </div>
      <!-- Sobreposición -->
      <div>
        <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
          <h2>Sobreposición de la capa de red</h2>
        </div>
        <div>
          <EtapaDosStageTwoSobreposicion />
        </div>
      </div>
      <!-- Sobreposición Capa Polígonos Red -->
      <div>
        <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold mt-6">
          <h2>Sobreposición Capa Polígonos Red</h2>
        </div>
        <!-- Manzanas sin poligono -->
        <div>
          <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
            <h2>Manzanas sin poligono</h2>
          </div>
          <div>
            <EtapaDosStageTwoMzaSinPoli />
          </div>
        </div>
        <!-- Manzanas que intersectan con poligonos -->
        <div>
          <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
            <h2>Manzanas que intersectan con poligonos</h2>
          </div>
          <div>
            <EtapaDosStageTwoMzaInter />
          </div>
        </div>
        <!-- Poligonos con mas de una mza -->
        <div>
          <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
            <h2>Poligonos con mas de una manzana</h2>
          </div>
          <div>
            <EtapaDosStageTwoPoliMzas />
          </div>
        </div>
        <!-- Poligonos sin mza-->
        <div>
          <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
            <h2>Poligonos sin manzana</h2>
          </div>
          <div>
            <EtapaDosStageTwoPoliSinMza />
          </div>
        </div>
      </div>
      <!-- Validación de Información De La Capa Mz_Reseccionamiento  -->
      <div>
        <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold mt-6">
          <h2>Validación de Información De La Capa Mz_Reseccionamiento </h2>
        </div>
        <!-- Inconsistencias en captura-->
        <div>
          <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
            <h2>Manzanas con otros datos</h2>
          </div>
          <div>
            <EtapaDosStageTwoMzaOtrosDatos />
          </div>
        </div>
        <!-- Mzas con datos duplicados-->
        <div>
          <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
            <h2>Manzanas con datos duplicados</h2>
          </div>
          <div>
            <EtapaDosStageTwoMzaDuplicados />
          </div>
        </div>
        <!-- Mzas con datos nulos-->
        <div>
          <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
            <h2>Manzanas con datos nulos</h2>
          </div>
          <div>
            <EtapaDosStageTwoMzasNulas />
          </div>
        </div>
      </div>
      <!-- Capa Mz_Reseccionamiento -->
      <div>
        <div class="text-center bg-inePurpura text-white h-8 flex items-center justify-center text-lg font-semibold mt-6">
          <h2>Capa Mz_Reseccionamiento</h2>
        </div>
        <!-- /mz invalidas -->
        <div>
          <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
            <h2>
              Geometrías inválidas
            </h2>
          </div>
          <div class="flex items-center justify-center gap-10 px-5 mb-2">
            <div v-if="resultsValidaciones.data.validarGeometriaMz.invalidas.length>0" class="flex justify-center pb-5">
              <p
                v-if="resultsValidaciones.data.validarGeometriaMz.invalidas.length>0"
              >
                Se encontraron <span class="text-red-500 font-bold">{{ resultsValidaciones.data.validarGeometriaMz.invalidas.length }}</span> manzanas.
              </p>
              <p
                v-else
              >
                Se encontró <span class="text-red-500 font-bold">1</span> manzana.
              </p>
            </div>
            <div v-else class="flex justify-center pb-5">
              <p>
                No se encontraron manzanas invalidas.
              </p>
            </div>
          </div>
          <div v-if="resultsValidaciones.data.validarGeometriaMz.invalidas.length>0" class="flex justify-center gap-10 px-5">
            <!-- Table -->
            <div>
              <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
                <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
                  <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                    <tr>
                      <th scope="col" class="px-6 py-3">
                        Manzana
                      </th>
                      <th scope="col" class="px-6 py-3">
                        GID
                      </th>
                    </tr>
                  </thead>
                  <tbody class="text-center">
                    <tr
                      v-for="item in resultsValidaciones.data.validarGeometriaMz.invalidas"
                      :key="`gid-${item.key}`"
                      class="bg-white border-b"
                    >
                      <td class="px-6 py-4">
                        {{ item.manzana }}
                      </td>
                      <td class="px-6 py-4">
                        {{ item.gid }}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- /mz nulas -->
        <div>
          <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
            <h2>
              Geometrías nulas
            </h2>
          </div>
          <div class="flex items-center justify-center gap-10 px-5 mb-2">
            <div v-if="resultsValidaciones.data.validarGeometriaMz.nulas.length>0" class="flex justify-center pb-5">
              <p
                v-if="resultsValidaciones.data.validarGeometriaMz.nulas.length>0"
              >
                Se encontraron <span class="text-red-500 font-bold">{{ resultsValidaciones.data.validarGeometriaMz.nulas.length }}</span> manzanas nulas.
              </p>
              <p
                v-else
              >
                Se encontró <span class="text-red-500 font-bold">1</span> manzana nula.
              </p>
            </div>
            <div v-else class="flex justify-center pb-5">
              <p>
                No se encontraron geometrías nulas en la capa.
              </p>
            </div>
          </div>
          <div v-if="resultsValidaciones.data.validarGeometriaMz.nulas.length>0" class="flex justify-center gap-10 px-5">
            <!-- Table -->
            <div>
              <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
                <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
                  <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                    <tr>
                      <th scope="col" class="px-6 py-3">
                        Manzana
                      </th>
                      <th scope="col" class="px-6 py-3">
                        GID
                      </th>
                    </tr>
                  </thead>
                  <tbody class="text-center">
                    <tr
                      v-for="item in resultsValidaciones.data.validarGeometriaMz.nulas"
                      :key="`gid-${item.key}`"
                      class="bg-white border-b"
                    >
                      <td class="px-6 py-4">
                        {{ item.manzana === null ? 'null' : item.manzana }}
                      </td>
                      <td class="px-6 py-4">
                        {{ item.gid }}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- Geometrías duplicadas -->
        <div>
          <div class="text-center text-ineAzul h-8 flex items-center justify-center text-lg font-semibold py-10">
            <h2>Geometrías duplicadas</h2>
          </div>
          <div class="flex items-center justify-center gap-10 px-5 mb-2">
            <div v-if="resultsValidaciones.data.geometriasDuplicadasMzResecc && resultsValidaciones.data.geometriasDuplicadasMzResecc.lista.length>0" class="flex justify-center pb-5">
              <p
                v-if="resultsValidaciones.data.geometriasDuplicadasMzResecc.lista.length>1"
              >
                Se encontró un total de <span class="text-red-500 font-bold">{{ resultsValidaciones.data.geometriasDuplicadasMzResecc.lista.length }}</span> líneas duplicadas.
              </p>
              <p
                v-else
              >
                Se encontró <span class="text-red-500 font-bold">1</span> línea duplicada.
              </p>
            </div>
            <div v-else class="flex justify-center pb-5">
              <p>
                No se encontraron líneas duplicadas.
              </p>
            </div>
          </div>
          <div v-if="resultsValidaciones.data.geometriasDuplicadasMzResecc && resultsValidaciones.data.geometriasDuplicadasMzResecc.lista.length>0" class="flex justify-center gap-10 px-5">
            <!-- Table -->
            <div>
              <div class="h-[400px] overflow-auto overflow-x-hidden flex flex-col items-center">
                <table class="w-full my-auto text-sm text-left rtl:text-right text-gray-500 border">
                  <thead class="text-xs text-white uppercase text-center bg-ineAzul sticky top-0 z-10">
                    <tr>
                      <th scope="col" class="px-6 py-3">
                        GID
                      </th>
                      <th scope="col" class="px-6 py-3">
                        GID(s) repetido(s)
                      </th>
                    </tr>
                  </thead>
                  <tbody class="text-center">
                    <tr
                      v-for="item in resultsValidaciones.data.geometriasDuplicadasMzResecc.lista"
                      :key="`gid-${item.key}`"
                      class="bg-white border-b"
                    >
                      <td class="px-6 py-4">
                        {{ item.gid }}
                      </td>
                      <td class="px-6 py-4">
                        {{ item.repetidos.join(', ') }}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <!-- Map -->
            <div class="w-[600px] h-[400px]">
              <ConsoleMapGeometryDuplicated :geometry="resultsValidaciones.data.geometriasDuplicadasMzResecc.geometry" />
            </div>
          </div>
        </div>
      </div>
      <!-- Botón para borrar Capa Polígonos Red -->
      <div>
        <div class="text-center text-ineAzul flex items-center justify-center text-2xl font-semibold mt-6 py-2">
          <h2>Borrar Capa Polígonos Red</h2>
        </div>
        <div class="text-center flex items-center justify-center text-lg font-semibold">
          <h2>Se detectaron errores en la generación de la capa Poligonos_Red</h2>
        </div>
        <div class="text-center flex items-center justify-center text-lg font-semibold p-4">
          <button v-if="!loading" type="button" class="w-[30%] px-6 py-3.5 text-lg font-bold text-white inline-flex items-center text-center justify-center bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 rounded-lg dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800" @click="borrarCapaPoligonoRed">
            Borrar
          </button>
          <!-- Loader -->
          <button v-if="loading" disabled type="button" class="w-[30%] px-6 py-3.5 text-lg font-semibold text-center justify-center text-gray-600 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 hover:text-rose focus:z-10 focus:ring-2 focus:ring-rose focus:text-rose inline-flex items-center">
            <svg
              aria-hidden="true"
              role="status"
              class="inline w-4 h-4 me-3 text-gray-200 animate-spin dark:text-gray-600"
              viewBox="0 0 100 101"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor" />
              <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="#e83e8c" />
            </svg>
            Eliminando...
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { sideBarStore } from '../store/sideBar';
import { indexStore } from '@/store';

const storeSideBar = sideBarStore();
const { resultsValidaciones } = storeToRefs(storeSideBar);
const { goverment, district, section } = resultsValidaciones._object;

const storeIndex = indexStore();
const { $notify } = useNuxtApp();
const config = useRuntimeConfig();
const { apiUrl } = config.public;

// Muestra el loader
const loading = ref(false);

// Código para Eliminar la capa poligono red
const borrarCapaPoligonoRed = async () => {
  const url = `${apiUrl}/delete/deletePoligonosRed?e=${goverment}&d=${district}&s=${section}`;

  try {
    // Activate loading
    loading.value = true;
    storeIndex.setWaiting(true);
    const result = await $fetch(url, { method: 'GET' });
    const flatErasers = result.code;

    if (flatErasers === '02') {
      $notify({ title: 'Validaciones borrar capa poligono red', text: 'Se borró la capa exitosamente', type: 'success' });
    }
  } catch (error) {
    $notify({ title: 'Validaciones borrar capa poligono red', text: 'Ocurrido un error, inténtelo más tarde', type: 'danger' });
  } finally {
    storeIndex.setWaiting(false);
    loading.value = false;
  }
};

</script>
