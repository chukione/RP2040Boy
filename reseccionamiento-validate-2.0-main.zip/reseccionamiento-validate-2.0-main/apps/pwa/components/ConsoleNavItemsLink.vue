<template>
  <div>
    <!-- TODO add this to nuxt-link -->
    <!-- v-if="isVisible" -->
    <nuxt-link
      class="utc-link group"
      :to="props.item.to"
      :title="props.item.help || ''"
      @click="handleClose"
    >
      <console-nav-items-link-icon
        v-if="props.item.icon"
        class="utc-link-icon text-5xl"
        :name="props.item.icon"
      />
      {{ props.item.name }}
    </nuxt-link>
    <div v-if="props.item.isSubmenu">
      <console-nav-items-link
        v-for="item2 in props.item.submenus"
        :key="item2.icon"
        :item="item2"
        class="utc-link-no-exact ml-10"
      />
    </div>
  </div>
</template>

<script setup>

const props = defineProps({
  item: {
    type: Object,
    required: true
  }
});
const emit = defineEmits(['closeSidebar']);
const handleClose = () => {
  emit('closeSidebar');
};

</script>
