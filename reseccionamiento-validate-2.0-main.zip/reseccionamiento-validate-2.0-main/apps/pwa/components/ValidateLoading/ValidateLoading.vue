<template>
  <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-85   z-[9999999]">
    <ValidateLoadingConsoleNavLogo2 />
  </div>
</template>

<script setup>
</script>
