<template>
  <div class="flex items-center flex-shrink-0 px-5 animate-bounce">
    <AppLogo class="h-10 w-auto" />
    <div class="ml-2 text-white">
      <h2 class="font-display text-2xl font-extrabold leading-tight">
        DCE
      </h2>
      <p class="w-full text-xs text-white text-right leading-none">
        versión {{ packageVersion }}
      </p>
    </div>
  </div>
</template>
<script setup lang="ts">
const config = useRuntimeConfig();
const { packageVersion } = config.public;
</script>
