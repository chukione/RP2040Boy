<!-- eslint-disable vue/v-on-event-hyphenation -->
<template>
  <!-- TODO add to nav role -->
  <!-- v-if="role" -->

  <nav>
    <console-nav-items-link
      v-for="item in filteredNavList"
      :key="item.icon"
      :item="item"
      class="utc-link-no-exact"
      @closeSidebar="closeSidebar"
    />
    <!-- TODO items protected by role -->
    <!-- <div v-for="itemGroup in filterGrouped" :key="itemGroup.slug" class="mt-8">
        <h3
          class="px-3 text-xs leading-4 font-semibold text-gray-500 uppercase tracking-wider"
        >
          {{ itemGroup.name }}
        </h3>
        <div class="mt-1">
          <console-nav-items-link
            v-for="item in itemGroup.list"
            :key="item.icon"
            :item="item"
            @closeSidebar="closeSidebar"
          />
        </div>
      </div> -->
  </nav>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { consoleStore } from './../store/console';
const storeConsole = consoleStore();
const { nav } = storeToRefs(storeConsole);
const navList = ref(nav);
watch(nav, () => {
  navList.value = nav;
});

// Filtra la lista navList.value.public basada en la propiedad show
const filteredNavList = computed(() => {
  return navList.value.public.filter(item => item.show === true);
});

const closeSidebar = () => {
  storeConsole.setSidebar(false);
  setTimeout(() => {
    // wait 400ms
    storeConsole.setSidebarWithDelay(false);
  }, 400);
};

</script>
