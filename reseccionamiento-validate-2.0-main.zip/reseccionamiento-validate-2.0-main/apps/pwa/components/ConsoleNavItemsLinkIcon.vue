<template>
  <svg
    fill="none"
    stroke="currentColor"
    stroke-linecap="round"
    stroke-linejoin="round"
    stroke-width="2"
    :viewBox="viewBoxSize"
  >
    <path :d="path" />
  </svg>
</template>

<script setup>
import { icons } from '@/services/icons';
const props = defineProps({
  name: {
    required: true,
    type: String
  },
  viewBox: {
    type: String,
    default: '0 0 24 24'
  }
});
const path = ref(icons[props.name]);
const viewBoxSize = ref(props.viewBox);

</script>
