<template>
  <svg
    clip-rule="evenodd"
    fill-rule="evenodd"
    stroke-linecap="round"
    stroke-linejoin="round"
    stroke-width="2"
    :fill="'fill' === props.type ? 'currentColor' : 'none'"
    :stroke="'stroke' == props.type ? 'currentColor' : 'none'"
    :viewBox="'stroke' == props.type ? '0 0 24 24' : '0 0 20 20'"
  >
    <path v-for="(path, index) in getPath" :key="index" :d="path" />
  </svg>
</template>

<script setup lang="ts">
import { newIcons } from '@/services/icons';

const props = defineProps({
  type: {
    default: 'stroke',
    type: String
  },
  name: {
    required: true,
    type: String
  }
});
const getPath = computed(() => {
  return newIcons[props.type][props.name];
});
</script>
