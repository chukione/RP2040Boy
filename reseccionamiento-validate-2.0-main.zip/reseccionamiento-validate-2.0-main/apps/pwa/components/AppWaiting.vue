<template>
  <div
    id="waiting"
    class="app-waiting fixed top-0 left-0 right-0 h-1 overflow-hidden z-50"
  >
    <div class="app-waiting-wrapper relative w-full h-full bg-pink-200">
      <div class="app-waiting-indeterminate bg-pink-400" />
    </div>
  </div>
</template>
