<template>
  <div class="w-full min-h-screen flex flex-col items-center justify-center">
    <h1 class="text-4xl font-extrabold text-gray-900 tracking-tight sm:text-5xl">
      {{ getTitle() }}
    </h1>

    <span class="text-sm text-gray-500">
      {{ props.error.statusCode }}
    </span>

    <app-logo class="my-6 h-16 w-auto" />

    <p class="text-xl text-gray-500">
      {{ props.error.statusMessage }}
    </p>
  </div>
</template>

<script setup>
const props = defineProps({
  error: {
    required: true,
    type: Object
  }
});

const getTitle = () => {
  if (props.error.statusCode === 401) {
    return 'Unauthorized';
  } else if (props.error.statusCode === 404) {
    return 'Page Not Found';
  }
  return 'Error Page';
};

</script>
