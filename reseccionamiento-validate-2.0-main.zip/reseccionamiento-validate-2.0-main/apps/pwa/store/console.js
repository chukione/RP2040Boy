import { defineStore } from 'pinia';
import { navList } from '@/services/nav';

export const consoleStore = defineStore('console', {
  state: () => ({
    nav: navList,
    sidebar: false,
    sidebarWithDelay: false,
    title: 'Dashboard'
  }),
  getters: {
    sidebarConsole: (state) => {
      return state.sidebar;
    },
    sidebarWithDelayConsole: (state) => {
      return state.sidebarWithDelay;
    },
    navConsole: (state) => {
      return state.nav;
    },
    titleConsole: (state) => {
      return state.title;
    }
  },
  actions: {
    updateToken (payload) {
      this.token = payload;
    },
    //*
    setSidebar (val) {
      this.sidebar = val;
      if (val) {
        this.sidebarWithDelay = val;
      }
    },
    setSidebarWithDelay (val) {
      this.sidebarWithDelay = val;
    },
    setTitle (val) {
      this.title = val;
    }
  }
});
