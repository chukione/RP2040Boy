import { defineStore } from 'pinia';
import { goverments } from '../services/goverments';
export const sideBarStore = defineStore('sideBar', {
  state: () => ({
    goverments: [],
    goverment: 0,
    district: 0,
    sections: [],
    section: 0,
    etapa: 0,
    etapas: [],
    showMap: false,
    ClearDesktop: false,
    initialMapGeometry: [],
    resultsValidaciones: {},
    fraccionamientosLength: null,
    categoriasLength: null,
    activeSpinnerData: false
  }),
  getters: {
  },
  actions: {
    setInitialMapGeometry (val) {
      this.initialMapGeometry = val;
    },
    setGoverments (val) {
      this.goverments = val;
    },
    setShowMap (val) {
      this.showMap = val;
    },
    setClearDesktop (val) {
      this.ClearDesktop = val;
    },
    setEtapas (val) {
      this.etapas = val;
    },
    setGoverment (val) {
      this.goverment = val;
    },
    setDistrict (val) {
      this.district = val;
    },
    setSections (val) {
      this.setions = val;
    },
    setSection (val) {
      this.section = val;
    },
    setEtapa (val) {
      this.etapa = val;
    },
    setFraccionamientosLength (val) {
      this.fraccionamientosLength = val;
    },
    setCategoriasLength (val) {
      this.categoriasLength = val;
    },
    setSetResultsValidaciones (val) {
      this.resultsValidaciones = val;
    },
    setActiveSpinnerData (val) {
      this.activeSpinnerData = val;
    },
    //* actions
    getGoverments () {
      if (this.goverments.length > 0) {
        return this.goverments;
      }
      //* Get goverments from core service
      const list = [{ id: 0, name: 'Selecciona una entidad', capital: '', slug: '', distritoFederal: '' }];
      Object.keys(goverments).forEach((govermentId) => {
        const goverment = goverments[govermentId];
        list.push({
          id: parseInt(govermentId),
          name: goverment.name,
          capital: goverment.capital,
          slug: goverment.slug,
          distritoFederal: goverment.distrito.federal
        });
      });
      this.setGoverments(list);
      return this.goverments;
    },
    getEtapas () {
      if (this.etapas.length > 0) {
        return this.etapas;
      }
      const list = [
        { id: 0, name: 'Selecciona una etapa' },
        { id: 1, name: 'Geometría' },
        { id: 2, name: 'Polígonos red' },
        { id: 3, name: 'Pol Red Inter Mz' }
      ];
      this.setEtapas(list);
      return this.etapas;
    },
    getSections (payload) {
      const { goverment, district } = payload;
      return new Promise((resolve, reject) => {
        const url = `/search/sections?e=${goverment}&d=${district}`;
        $fetch(url, {
          headers: {
          },
          method: 'GET'
        })
          .then((res) => {
            if (res) {
              this.setSections(res);
              resolve(this.sections);
            } else {
              this.setSections([]);
            }
          })
          .catch((error) => {
            this.setSections([]);
            console.error(error);
            reject(error);
          });
      });
    }
  }
});
