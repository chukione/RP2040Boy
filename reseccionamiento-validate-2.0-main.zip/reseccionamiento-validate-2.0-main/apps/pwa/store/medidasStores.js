import { defineStore } from 'pinia';

export const medidasStores = defineStore('medidas', {
  state: () => ({
    dataAlto: null,
    dataAltoMain: null,
    dataAncho: null,
    altoComentarios: null
  }),
  actions: {
    setDataAlto (val) {
      this.dataAlto = val;
    },
    setDataAltoMain (val) {
      this.dataAltoMain = val;
    },
    setDataAncho (val) {
      this.dataAncho = val;
    },
    setDataAltoComentarios (val) {
      this.altoComentarios = val;
    }
  }
});
