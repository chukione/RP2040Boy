import { defineStore } from 'pinia';

export const indexStore = defineStore('index', {
  state: () => ({
    waiting: false
  }),
  getters: {
    waitingIndex: (state) => {
      return state.waiting;
    }
  },
  actions: {
    setWaiting (val) {
      this.waiting = val;
    }
  }
});
