module.exports = {
  semi: true,
  arrowParens: 'always',
  singleQuote: true,
};
