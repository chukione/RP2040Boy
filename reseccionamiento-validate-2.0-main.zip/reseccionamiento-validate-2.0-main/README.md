# Reseccionamiento Validate 2.0

Sistema para validar geometrias de reseccionamiento 2.0

## Requerimientos

- Instalar [yarn](https://classic.yarnpkg.com/en/docs/install/)

## Root

    -Instalar las dependencias del proyecto
    
    Abrimos una terminal en root y ejecutamos el siguiente comando:

            `yarn install`


## API (Back)


    - Archivo .env

        Creamos un archivo .env sobre API con la siguiente informaciòn:

            ```

            # DB_CONN=JSON.stringify( ...conn )
            DB_CONN={"<credenciales y certificados>"}
            DCE_ENVIRONMENT=developer

            
            ```


    
    Abrimos una terminal en API y ejecutamos los siguientes comandos:
            
            `yarn emulators`

    Si la ejecuciòn del comando nos arroja errores  ejecutamos los siguientes:
        
        `yarn firebase login`
        `yarn firebase use default`
        


## PWA (Front)

    - Archivo .env

        Agragamos un archivo a PWA con el nombre '.env' con la siguiente informaciòn:

              ```  

              FIREBASE_CONFIG={"<firebaseconfig>"}

                SERVICE_ID=usermanger

                DOMAIN_URL=http://localhost:3000
                API_URL=http://localhost:5001/ine-carto-next/us-central1/usermanager-api 
                
                
                ```

    -Instalar yarn en PWA
        Abrimos una terminal en PWA y ejecutamos las siguientes instrucciones:   

                    `yarn install`
        


### Modo desarrollo

> \$ yarn dev
