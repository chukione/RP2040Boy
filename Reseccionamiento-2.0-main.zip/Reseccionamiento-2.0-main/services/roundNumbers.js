export function roundNumbers (number) {
  const cifra = Number(number);
  if (Number.isInteger(cifra)) {
    return cifra.toFixed(4);
  }
  return cifra.toFixed(4);
}
