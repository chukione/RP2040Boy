<template>
  <div class="hidden md:flex md:flex-shrink-0">
    <div class="flex flex-col w-60 border-r border-gray-200 bg-white">
      <div class="h-0 flex-1 flex flex-col pb-4 overflow-y-auto">
        <div class="px-4 pt-2">
          <label
            for="etapa"
            class="block mb-1 text-sm font-medium text-gray-900 dark:text-white"
          >
            Etapa
          </label>
          <select
            id="etapa"
            v-model="etapa_"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            @change="changeStages"
          >
            <option
              v-for="eta in optionsEtapas"
              :key="`eta-${eta.key}`"
              :value="eta.key"
            >
              {{ eta.text }}
            </option>
          </select>
          <label
            for="entidad"
            class="mt-4 block mb-1 text-sm font-medium text-gray-900 dark:text-white"
          >
            Entidad
          </label>
          <select
            id="entidad"
            v-model="goverment_"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            @change="changeGoverment"
          >
            <option
              v-for="gov in optionsGoverment"
              :key="`goverment-${gov.key}`"
              :value="gov.key"
            >
              {{ gov.text }}
            </option>
          </select>
          <label
            for="distrito"
            class="mt-4 block mb-1 text-sm font-medium text-gray-900 dark:text-white"
          >
            Distrito
          </label>
          <select
            id="distrito"
            v-model="district_"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            @change="changeDistrict"
          >
            <option
              v-for="dis in optionsDistrict"
              :key="`district-${dis.key}`"
              :value="dis.key"
            >
              {{ dis.text }}
            </option>
          </select>
          <label
            for="seccion"
            class="mt-4 block mb-1 text-sm font-medium text-gray-900 dark:text-white"
          >
            Sección
          </label>
          <select
            id="seccion"
            v-model="section_"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            @change="changeSection"
          >
            <option
              v-for="sec in optionsSeccions"
              :key="`sec-${sec.key}`"
              :value="sec.key"
            >
              {{ sec.text }}
            </option>
          </select>
        </div>
        <div class="overflow-y-auto overflow-x-hidden flex-grow">
          <ul class="flex flex-col py-4 space-y-1">
            <li class="lista">
              <NuxtLink to="/console/crearEscenarios" class="resec-link">
                <IconComponent :icon="['fas', 'circle-plus']" />
                <span class="ml-2 text-sm tracking-wide truncate">Crear/Editar Escenario</span>
              </NuxtLink>
              <!-- <nuxt-link to="/console/crearEscenarios">
                <button
                  class="text-xs font-semibold border rounded-md p-1 w-full uppercase bg-transparent border-navBar text-navBar text-center hover:bg-navBar hover:text-white"
                >
                  <span class="mr-1">
                    <IconComponent :icon="['fas', 'circle-plus']" />
                  </span>
                  Crear/Editar Escenario
                </button>
              </nuxt-link> -->
            </li>
            <li class="lista">
              <NuxtLink to="/console/verEscenarios" class="resec-link">
                <IconComponent :icon="['fas', 'eye']" />
                <span class="ml-2 text-sm tracking-wide truncate">Ver Escenarios</span>
              </NuxtLink>
            </li>
            <li class="lista">
              <NuxtLink to="/console/validarGuardar" class="resec-link">
                <IconComponent :icon="['fas', 'square-check']" />
                <span class="ml-2 text-sm tracking-wide truncate">Validar y guardar</span>
              </NuxtLink>
            </li>
            <li class="lista">
              <NuxtLink to="/console/recomendarEscenario" class="resec-link">
                <IconComponent :icon="['fas', 'star']" />
                <span class="ml-2 text-sm tracking-wide truncate">Recomendar/Liberar</span>
              </NuxtLink>
            </li>
            <li class="lista">
              <NuxtLink to="/console/copiarEscenarios" class="resec-link">
                <IconComponent :icon="['fas', 'copy']" />
                <span class="ml-2 text-sm tracking-wide truncate">Copiar Escenarios</span>
              </NuxtLink>
            </li>
            <li class="lista">
              <NuxtLink to="/console/reporteEscenarios" class="resec-link">
                <IconComponent :icon="['fas', 'table']" />
                <span class="ml-2 text-sm tracking-wide truncate">Reportes</span>
              </NuxtLink>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { sideBarStore } from './../stores/sideBar';
const { $notify } = useNuxtApp();
const storeSideBar = sideBarStore();
const { goverment, district, etapa, section } = storeToRefs(storeSideBar);

//* DATA
const goverments = ref<any>([]);
const goverment_ = ref(0);
const district_ = ref(0);
const section_ = ref(0);
const seccions = ref<any>([]);
const etapa_ = ref(0);
const etapas = ref<any>([]);
const distritos = ref<any>([]);
onMounted(() => {
  if (goverment.value > 0 && etapa.value > 0) {
    goverment_.value = goverment.value;
    etapa_.value = etapa.value;
  }
  if (etapa.value > 0) {
    etapa_.value = etapa.value;
  }
  if (district.value > 0) {
    district_.value = district.value;
    getDistrictsMounted();
  }
  if (section.value > 0) {
    section_.value = section.value;
    getSectionsMounted();
  }
  goverments.value = storeSideBar.getGoverments();
  getEtapas();
  changeSection();
  // updateDate();
  //* restartValues();
});
// const updateDate = async () => {
//   await getEscenarios();
//   await getCreateEditScenario();
//   await getAprobarEscenario();
// };

const getEtapas = async () => {
  try {
    const url = 'http://localhost:3030/etapas';
    etapas.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Etapas',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
const optionsGoverment = computed(() => {
  if (goverments.value.length < 0) {
    return;
  }
  const data = [];
  for (const item of goverments.value) {
    data.push({ key: Number(item.id), text: item.name });
  }
  return data;
});

const optionsEtapas = computed(() => {
  const data = [{ key: 0, text: 'Selecciona una etapa' }];
  if (etapas.value.length < 0) {
    return data;
  }

  for (const item of etapas.value) {
    data.push({ key: Number(item.id), text: item.nombre });
  }
  return data;
});
const optionsSeccions = computed(() => {
  const data = [{ key: 0, text: 'Selecciona una seccion' }];
  if (seccions.value.length < 0) {
    return data;
  }

  for (const item of seccions.value) {
    data.push({ key: Number(item.Seccion), text: item.Seccion });
  }
  return data;
});
const optionsDistrict = computed(() => {
  const data = [{ key: 0, text: 'Selecciona un distrito' }];
  if (goverment_.value <= 0 || distritos.value.length === 0) {
    return data;
  }
  for (const item of distritos.value) {
    data.push({ key: item.distrito, text: `Distrito ${item.distrito}` });
  }
  return data;
});
const changeStages = () => {
  storeSideBar.setEtapa(Number(etapa_.value));
  clearDistrict();
  clearGoverment();
  getSections();
};
const changeGoverment = () => {
  storeSideBar.setGoverment(Number(goverment_.value));
  clearDistrict();
  getSections();
  getDistricts();
};
const changeDistrict = () => {
  storeSideBar.setDistrict(district_.value);
  getSections();
};

const changeSection = () => {
  storeSideBar.setSection(Number(section_.value));
  getEscenarios();
  getCreateEditScenario();
  getAprobarEscenario();
};
const clearDistrict = () => {
  district_.value = 0;
  storeSideBar.setDistrict(Number(district_.value));
};
const clearGoverment = () => {
  goverment_.value = 0;
  storeSideBar.setGoverment(goverment_.value);
};
const clearStage = () => {
  etapa_.value = 0;
  storeSideBar.setEtapa(etapa_.value);
};
const clearSection = () => {
  section_.value = 0;
  storeSideBar.setSection(section_.value);
  storeSideBar.setSections([]);
};
const clearEscenarios = () => {
  // etapa_.value = 0;
  storeSideBar.setEscenarios([]);
  storeSideBar.setCreateScenarios([]);
  storeSideBar.setEscenariosAprobar([]);
};
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const restartValues = () => {
  clearGoverment();
  clearDistrict();
  clearSection();
  clearStage();
  clearEscenarios();
};
const getSections = async () => {
  // - clear sections
  clearSection();
  // - clear results
  clearEscenarios();
  if (Number(goverment.value) <= 0 || Number(district.value) <= 0) {
    return;
  }
  try {
    const url = `http://localhost:3030/getSecciones?entidad=${goverment.value}&distrito=${district.value}`;
    seccions.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Secciones',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
const getDistricts = async () => {
  // - clear sections
  clearSection();
  // - clear results
  clearEscenarios();
  if (Number(goverment.value) <= 0) {
    return;
  }
  try {
    const url = `http://localhost:3030/getDistritos/${goverment.value}`;
    distritos.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Distritos',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
const getDistrictsMounted = async () => {
  if (Number(goverment.value) <= 0) {
    return;
  }
  try {
    const url = `http://localhost:3030/getDistritos/${goverment.value}`;
    distritos.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Distritos',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
const getSectionsMounted = async () => {
  if (Number(goverment.value) <= 0 || Number(district.value) <= 0) {
    return;
  }
  try {
    const url = `http://localhost:3030/getSecciones?entidad=${goverment.value}&distrito=${district.value}`;
    seccions.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Secciones',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
const getEscenarios = async () => {
  // - clear escenarios
  clearEscenarios();
  if (
    goverment.value <= 0 ||
    district.value <= 0 ||
    etapa.value <= 0 ||
    section.value <= 0
  ) {
    return;
  }
  try {
    const url = `http://localhost:3030/getDataMain?etapa=${etapa.value}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&typeUser=PAN-CNV`;
    const escenariosBefore: any = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    if (escenariosBefore.length > 0) {
      for (const index in escenariosBefore) {
        const alias = escenariosBefore[index].Alias;
        const urlAlias = `http://localhost:3030/getLogo?alias=${alias}`;
        const routeImage: any = await $fetch(urlAlias, {
          headers: {
            Accept: 'application/json, text/plain, */*',
          },
          method: 'GET',
        });
        escenariosBefore[index].Logo = routeImage[0].Logo;
      }
      storeSideBar.setEscenarios(escenariosBefore);
    }
  } catch (error) {
    $notify({
      title: 'Escenarios',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

const getCreateEditScenario = async () => {
  // - clear escenarios
  clearEscenarios();
  if (
    goverment.value <= 0 ||
    district.value <= 0 ||
    etapa.value <= 0 ||
    section.value <= 0
  ) {
    return;
  }
  try {
    const url = `http://localhost:3030/getCrearEscenarios?etapa=${etapa.value}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&typeUser=ADMINISTRADOR&userName=erick.loza`;
    const createScenariosBefore: any = await $fetch(url, {});
    if (createScenariosBefore.length > 0) {
      storeSideBar.setCreateScenarios(createScenariosBefore);
    } else {
      try {
        const url = `http://localhost:3030/getCrearEscenarios?etapa=${etapa.value}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&typeUser=ADMINISTRADOR&userName=juan.perez`;
        const escenariosCreated = await $fetch(url, {
          headers: {
            Accept: 'application/json, text/plain, */*',
          },
          method: 'GET',
        });
        storeSideBar.setCreateScenarios(escenariosCreated);
      } catch (error) {
        $notify({
          title: 'Crear Escenario',
          text: 'Ocurrido un error, inténtelo más tarde',
          type: 'danger',
        });
      }
    }
  } catch (error) {
    $notify({
      title: 'Editar escenarios',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

const getAprobarEscenario = async () => {
  // - clear escenarios
  clearEscenarios();
  if (
    goverment.value <= 0 ||
    district.value <= 0 ||
    etapa.value <= 0 ||
    section.value <= 0
  ) {
    return;
  }
  try {
    const url = `http://localhost:3030/getAprobarEscenario?et=${etapa.value}&e=${goverment.value}&d=${district.value}&s=${section.value}&typeUser=MORENA-CLV`;
    const AprobarescenariosBefore: any = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    if (AprobarescenariosBefore.length > 0) {
      for (const index in AprobarescenariosBefore) {
        const alias = AprobarescenariosBefore[index].Alias;
        const urlAlias = `http://localhost:3030/getLogo?alias=${alias}`;
        const routeImage: any = await $fetch(urlAlias, {
          headers: {
            Accept: 'application/json, text/plain, */*',
          },
          method: 'GET',
        });
        AprobarescenariosBefore[index].Logo = routeImage[0].Logo;
      }
      storeSideBar.setEscenariosAprobar(AprobarescenariosBefore);
    }
  } catch (error) {
    $notify({
      title: 'Aprobar Escenarios',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
// const getComentarios = async () => {
//   // - clear escenarios
//   clearEscenarios();
//   if (
//     goverment.value <= 0 ||
//     district.value <= 0 ||
//     etapa.value <= 0 ||
//     section.value <= 0
//   ) {
//     return;
//   }
//   // const url = `http://localhost:3030/getComentarios?id=2&typeUser=ADMINISTRADOR`;
//   // const url = `http://localhost:3030/getComentarios?id=11&typeUser=MORENA-CDV`;
//   const url = `http://localhost:3030/getComentarios?id=1&typeUser=PRI-CDV`;
//   const getComentariosBefore: any = await $fetch(url, {
//   });
//   if (getComentariosBefore.length > 0) {
//     storeSideBar.setdataComentarios(getComentariosBefore);
//   }
//   console.log(getComentariosBefore);
// };
</script>
