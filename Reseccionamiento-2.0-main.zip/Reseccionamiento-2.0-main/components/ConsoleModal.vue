<template>
  <div
    v-show="showWithDelay"
    class="selected-modal fixed bottom-0 inset-x-0 px-4 pb-6 sm:inset-0 sm:p-0 sm:flex sm:items-center sm:justify-center"
    @keyup.esc="close"
  >
    <transition
      enter-active-class="ease-out duration-300"
      enter-class="opacity-0"
      enter-to-class="opacity-100"
      leave-active-class="ease-in duration-200"
      leave-class="opacity-100"
      leave-to-class="opacity-0"
    >
      <div v-if="show" class="fixed inset-0 transition-opacity">
        <div class="absolute inset-0 bg-gray-500 opacity-75" />
      </div>
    </transition>

    <transition
      enter-active-class="ease-out duration-300"
      enter-class="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
      enter-to-class="opacity-100 translate-y-0 sm:scale-100"
      leave-active-class="ease-in duration-200"
      leave-class="opacity-100 translate-y-0 sm:scale-100"
      leave-to-class="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
    >
      <div
        v-if="show"
        class="bg-white rounded-lg px-4 pt-5 pb-4 overflow-hidden shadow-xl transform transition-all sm:max-w-lg sm:w-full sm:p-6"
      >
        <div>
          <div
            class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-pink-100"
          >
            <span>🚀</span>
          </div>
          <div class="mt-3 text-center sm:mt-8">
            <h3 class="text-lg leading-6 font-medium text-gray-900">
              {{ title }}
            </h3>
          </div>
        </div>
        <div
          class="mt-5 sm:mt-10 sm:grid sm:grid-cols-2 sm:gap-3 sm:grid-flow-row-dense"
        >
          <span class="flex w-full rounded-md shadow-sm sm:col-start-2">
            <button
              type="button"
              class="inline-flex justify-center w-full rounded-md border border-transparent px-4 py-2 bg-pink-600 text-base leading-6 font-medium text-white shadow-sm hover:bg-pink-500 focus:outline-none focus:border-pink-700 focus:shadow-outline-pink transition ease-in-out duration-150 sm:text-sm sm:leading-5"
              @click="handleOK()"
            >
              Aceptar
            </button>
          </span>
          <span
            class="mt-3 flex w-full rounded-md shadow-sm sm:mt-0 sm:col-start-1"
          >
            <button
              type="button"
              class="inline-flex justify-center w-full rounded-md border border-gray-300 px-4 py-2 bg-white text-base leading-6 font-medium text-gray-700 shadow-sm hover:text-gray-500 focus:outline-none focus:border-blue-300 focus:shadow-outline transition ease-in-out duration-150 sm:text-sm sm:leading-5"
              @click="close"
            >
              Cancelar
            </button>
          </span>
        </div>
      </div>
    </transition>
  </div>
</template>
<script setup>
const message = ref(null);
const show = ref(false);
const showWithDelay = ref(false);
const title = ref(null);
const emit = defineEmits(['validatesave']);
const open = (titleOpen, messageOpen) => {
  title.value = titleOpen;
  message.value = messageOpen;
  show.value = true;
  showWithDelay.value = true;
};
const close = () => {
  forceClose();
};
const forceClose = () => {
  show.value = false;
  setTimeout(() => {
    // wait 400ms
    showWithDelay.value = false;
  }, 400);
};
const handleOK = () => {
  emit('validatesave');
  close();
};
defineExpose({
  open,
});
</script>
