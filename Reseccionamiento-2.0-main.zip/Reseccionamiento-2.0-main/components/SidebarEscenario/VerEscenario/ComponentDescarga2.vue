<template>
  <div class="flex flex-col gap-6 px-3 text-ineAzul dark:text-slate-100">
    <!-- Acuses de referencia del escenario -->
    <div class="flex flex-col gap-2">
      <!-- Title -->
      <div class="font-semibold dark:font-normal ">
        <p>Acuses de referencia del escenario</p>
      </div>
      <!-- Buttons -->
      <div class="flex justify-start gap-4 select-none">
        <!-- Guardado -->
        <div v-if="dataEscenarioActual">
          <UTooltip :text="(((dataEscenarioActual.Seleccion_guardado == 1 && dataEscenarioActual.guardado == 1) || (dataEscenarioActual.Seleccion_guardado == 1 && dataEscenarioActual.Guardado == 1)) ? 1 : (dataEscenarioActual.Seleccion_guardado !== undefined ? dataEscenarioActual.Seleccion_guardado : (dataEscenarioActual.guardado !== undefined ? dataEscenarioActual.guardado : 0))) !== 0 ? 'Descargar' : 'El escenario no ha sido guardado'">
            <UButton
              class="flex justify-center w-full"
              color="white"
              :disabled="dataEscenarioActual.Seleccion_guardado === 0 || dataEscenarioActual.seleccion_guardado === 0"
              :ui="{
                color: {
                  white: {
                    solid:
                      'text-xs shadow-sm ring-1 ring-inset ring-ineMorado dark:ring-purple-400 text-white bg-ineMorado hover:bg-purple-800 dark:bg-inherit dark:hover:bg-gray-800/50 disabled:bg-ineMorado dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-red-500 dark:text-purple-400 font-normal transition-hover duration-1000',
                  },
                },
              }"
              @click="imprimirFormato('ACUSE DE ESCENARIO GUARDADO')"
            >
              <UIcon size="30px" name="i-flowbite:file-pdf-outline" dynamic /> 
              Acuse de guardado
            </UButton>
          </UTooltip>
        </div>
        <!-- Liberado -->
        <div v-if="dataEscenarioActual && dataEscenarioActual.Liberado !== undefined">
          <UTooltip  :text="dataEscenarioActual.Liberado === 1 && dataEscenarioActual.Ganador === 1 ? 'Descargar' : 'El escenario no ha sido liberado'">
            <UButton
              class="flex justify-center w-full"
              color="white"
              :disabled="dataEscenarioActual.Liberado === 0 || dataEscenarioActual.Ganador === 0"
              :ui="{
                color: {
                  white: {
                    solid:
                      'text-xs shadow-sm ring-1 ring-inset ring-ineMorado dark:ring-purple-400 text-white bg-ineMorado hover:bg-purple-800 dark:bg-inherit dark:hover:bg-gray-800/50 disabled:bg-ineMorado dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-red-500 dark:text-purple-400 font-normal transition-hover duration-1000',
                  },
                },
              }"
              @click="imprimirFormato('ACUSE DE ESCENARIO LIBERADO')"
            > <UIcon size="30px" name="i-flowbite:file-pdf-outline" dynamic /> Acuse de liberado
            </UButton>
          </UTooltip>
        </div>
        <!-- Recomendado -->
        <div v-if="dataEscenarioActual && dataEscenarioActual.Seleccion_recomendado !== undefined">
          <UTooltip :text="dataEscenarioActual.Seleccion_recomendado === 1 && dataEscenarioActual.Recomendado === 1 ? 'Descargar' : 'El escenario no ha sido recomendado'">
            <UButton
              class="flex justify-center w-full"
              color="white"
              :disabled="dataEscenarioActual.Seleccion_recomendado === 0 || dataEscenarioActual.Recomendado === 0"
              :ui="{
                color: {
                  white: {
                    solid:
                      'text-xs shadow-sm ring-1 ring-inset ring-ineMorado dark:ring-purple-400 text-white bg-ineMorado hover:bg-purple-800 dark:bg-inherit dark:hover:bg-gray-800/50 disabled:bg-ineMorado dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-red-500 dark:text-purple-400 font-normal transition-hover duration-1000',
                  },
                },
              }"
              @click="imprimirFormato('ACUSE DE ESCENARIO RECOMENDADO')"
            > <UIcon size="30px" name="i-flowbite:file-pdf-outline" dynamic /> Acuse de recomendado
            </UButton>
          </UTooltip>
        </div>
      </div>
    </div>
    <!-- Acuses de referencia del escenario -->
    <div class="flex flex-col gap-2">
      <div class="font-semibold dark:font-normal">
        <p>Tablas de datos del escenario</p>
      </div>
      <div class="flex justify-start items-center gap-2 select-none">
        <!-- Secciones de trabajo -->
        <div>
          <UButton
            class="flex justify-center"
            color="white"
            :loading="loadingInfoEscenario"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-ineRosa dark:ring-ineRosa text-white bg-ineRosa hover:ring-pink-700 hover:bg-pink-700 dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-red-500 dark:text-ineRosa font-normal transition-hover duration-1000',
                },
              },
            }"
            @click="getInforEscenario"
          > <UIcon size="30px" name="i-eos-icons:csv-file" dynamic /> Secciones de trabajo
          </UButton>
        </div>
        <!-- Evaluaciones del escenario -->
        <div>
          <UButton
            class="flex justify-center"
            color="white"
            :loading="loadingEvaluacionEscenario"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-ineRosa dark:ring-ineRosa text-white bg-ineRosa hover:ring-pink-700 hover:bg-pink-700 dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-red-500 dark:text-ineRosa font-normal transition-hover duration-1000',
                },
              },
            }"
            @click="downloadEvaluacionEscenario"
          > <UIcon size="30px" name="i-eos-icons:csv-file" dynamic /> Evaluaciones del escenario
          </UButton>
        </div>
        <!-- DICE/DEBE -->
        <div>
          <UButton
            class="flex justify-center"
            color="white"
            :loading="loadingDiceDebe"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-ineRosa dark:ring-ineRosa text-white bg-ineRosa hover:ring-pink-700 hover:bg-pink-700 dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-red-500 dark:text-ineRosa font-normal transition-hover duration-1000',
                },
              },
            }"
            @click="descargaDiceDebe"
          > <UIcon size="18px" name="i-eos-icons:csv-file" dynamic /> DICE/DEBE
          </UButton>
        </div>
      </div>
    </div>
    <!-- Información espacial del escenario -->
    <div class="flex flex-col gap-2">
      <div class="font-semibold dark:font-normal">
        <p>Información espacial del escenario</p>
      </div>
      <div class="flex justify-start gap-4 select-none">
        <!-- Escenario -->
        <div>
          <UButton
            class="flex justify-center items-center"
            color="white"
            :loading="loadingEscenarioGeoJson"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-ineLila dark:ring-ineLila text-white bg-ineLila hover:ring-purple-400 hover:bg-purple-400 dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-red-500 dark:text-ineLila font-normal transition-hover duration-1000',
                },
              },
            }"
            @click="downloadDataEscenario"
          >
            <UIcon size="18px" name="i-gis:geojson-file" dynamic /> Escenario
          </UButton>
        </div>
        <!-- Secciones de trabajo -->
        <div>
          <UButton
            class="flex justify-center"
            color="white"
            :loading="loadingStGeoJson"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-ineLila dark:ring-ineLila text-white bg-ineLila hover:ring-purple-400 hover:bg-purple-400 dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-red-500 dark:text-ineLila font-normal transition-hover duration-1000',
                },
              },
            }"
            @click="downloadGeoJsonST"
          >
            <UIcon size="18px" name="i-gis:geojson-file" dynamic /> Secciones de trabajo
          </UButton>
        </div>
      </div>
    </div>
    <!-- Regresar Inicio -->
    <div class="flex justify-center">
      <UButton
        icon="i-heroicons-home"
        class="flex justify-center w-full"
        label="Regresar"
        color="white"
        :ui="{
          color: {
            white: {
              solid:
                'text-xs shadow-sm ring-1 ring-inset ring-ineAzul dark:ring-ineRosa text-white dark:text-ineRosa bg-ineAzul hover:bg-[#80416b55] hover:text-ineAzul disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-ineAzul hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
            },
          },
        }"
        @click="returnPage"
      />
    </div>
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/stores/sideBar';
import { descargasStore } from '@/stores/descargasStore';

const storeDescargas = descargasStore();
const { dataEscenario, dataEvaluacionEscenario } = storeToRefs(storeDescargas);

const route = useRoute();

const { $notify } = useNuxtApp();

// Esta funcion permite reasignar la url del logo para que sea mostrada
const returnPage = () => {
  navigateTo('/console/crearEscenarios');
};

const storeSideBar = sideBarStore();
const { goverment, district, section, idEscenario, escenarioVer, escenarioEdit } =
    storeToRefs(storeSideBar);

const dataEscenarioActual = ref(null);
watchEffect(() => {
  if (route.path === '/console/verEscenario' && escenarioVer.value) {
    dataEscenarioActual.value = escenarioVer.value;
    // console.log('ver', dataEscenarioActual.value);
  }
  if (route.path === '/console/editarEscenarios' && escenarioEdit.value) {
    dataEscenarioActual.value = escenarioEdit.value;
    // console.log('editar', dataEscenarioActual.value);
  }
});

const dataGeneral = ref([]);
const loadingInfoEscenario = ref(false);
const getInforEscenario = async () => {
  loadingInfoEscenario.value = true;
  try {
    const url = `http://localhost:3030/Get-info-escenario?id_esc=${idEscenario.value}&e=${goverment.value}&d=${district.value}&s=${section.value}`;
    dataGeneral.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    // downloadCSV(dataGeneral.value)
    downloadCSV(dataGeneral.value, `USUARIO_Propuestas Distritales_${goverment.value}_${district.value}_${section.value}`);
    $notify({
      title: 'Descarga secciones de trabajo',
      text: 'Archivo descargado con éxito',
      type: 'success',
    });
  } catch (error) {
    $notify({
      title: 'Descarga secciones de trabajo',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  } finally {
    loadingInfoEscenario.value = false;
  }
};

const dataDiceDebe = ref([]);
const dataDiceDebeImp = ref([]);
const loadingDiceDebe = ref(false);
const descargaDiceDebe = async () => {
  loadingDiceDebe.value = true;
  const url = `http://localhost:3030/descargaDiceDebe?id_esc=${idEscenario.value}&e=${goverment.value}&d=${district.value}&s=${section.value}`;
  try {
    dataDiceDebe.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    let newData = [];
    for (const key in dataDiceDebe.value.st) {
      if(Object.prototype.hasOwnProperty.call(dataDiceDebe.value.st, key)){
        const element = dataDiceDebe.value.st[key].datos;
        newData = newData.concat(element);
      }
    }

    dataDiceDebeImp.value = newData;

    // downloadCSV(dataDiceDebeImp.value);
    downloadCSV(dataDiceDebeImp.value, `USUARIO_DICE/DEBE_Propuestas Distritales_${goverment.value}_${district.value}_${section.value}`);

    $notify({
      title: 'Descarga DICE/DEBE',
      text: 'Archivo descargado con éxito',
      type: 'success',
    });
  } catch (error) {
    $notify({
      title: 'Descarga DICE/DEBE',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  } finally {
    loadingDiceDebe.value = false;
  }
};

const loadingEvaluacionEscenario = ref(false);
const downloadEvaluacionEscenario = () => {
  try {
    loadingEvaluacionEscenario.value = true;
    const renamedData = dataEvaluacionEscenario.value.map(item => {
      return {
        ST: item.col1,
        Rango: item.col2,
        Conformacion: item.col3,
        Vialidad: item.col4,
        Sitio: item.col5,
      };
    });
    // downloadCSV(renamedData);
    downloadCSV(renamedData, `evaluaciones_st_escenario_USUARIO_Propuestas Distritales_${goverment.value}_${district.value}_${section.value}`);
    $notify({
      title: 'Evaluacion del Escenario',
      text: 'Archivo descargado con éxito',
      type: 'success',
    });
  } catch (error) {
    $notify({
      title: 'Evaluacion del Escenario',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }finally{
    loadingEvaluacionEscenario.value = false;
  }
};

// *** Función que descarga archivos CSV ***
const downloadCSV = (setInfo, filename) => {
  const data = setInfo;
  const array = [Object.keys(data[0])].concat(data);

  const csv = array.map(row => {
    return Object.values(row).map(value => {
      return typeof value === 'string' ? `"${value.replace(/"/g, '""')}"` : value;
    }).join(',');
  }).join('\n');

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.setAttribute('download', filename + '.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// Download info Escenario
const loadingEscenarioGeoJson = ref(false);
const downloadDataEscenario = () => {
  try {
    loadingEscenarioGeoJson.value = true;
    // downloadGeoJsonFile(dataEscenario.value, 'ManzanaGeoJSON.geojson');
    downloadGeoJsonFile(dataEscenario.value, `escenario_USUARIO_Propuestas Distritales_${goverment.value}_${district.value}_${section.value}`);
    $notify({
      title: 'GeoJSON Escenario',
      text: 'Archivo descargado con éxito',
      type: 'success',
    });
  } catch (error) {
    $notify({
      title: 'GeoJSON Escenario',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  } finally {
    loadingEscenarioGeoJson.value = false;
  }
};

// Download info Secciones de trabajo
const dataGeoJsonST = ref([]);
const loadingStGeoJson = ref(false);
const downloadGeoJsonST = async () => {
  try {
    loadingStGeoJson.value = true;
    const url = `http://localhost:3030/getDownloadStEsc?idEscenario=${idEscenario.value}`;
    dataGeoJsonST.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    // Mappeamos la información para obtener la respuesta como queremos
    const formattedResponse = {
      type: 'FeatureCollection',
      features: dataGeoJsonST.value.features.map((feature) => ({
        type: 'Feature',
        geometry: {
          type: feature.geometry.type,
          coordinates: feature.geometry.coordinates,
        },
        properties: {
          st: feature.properties.id,
          entidad: goverment.value,
          seccion_origen: section.value,
        },
      })),
    };

    dataGeoJsonST.value = formattedResponse;

    // downloadGeoJsonFile(dataGeoJsonST.value, 'secciones_de_trabajo.geojson');
    downloadGeoJsonFile(dataGeoJsonST.value, ` ST_escenario_USUARIO_Propuestas Distritales_${goverment.value}_${district.value}_${section.value}`);

    $notify({
      title: 'GeoJSON ST',
      text: 'Archivo descargado con éxito',
      type: 'success',
    });
  } catch (error) {
    $notify({
      title: 'GeoJSON ST',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  } finally {
    loadingStGeoJson.value = false;
  }
};

// Función para descargar archivo GeoJSON
const downloadGeoJsonFile = (data, filename) => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename + '.geojson';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

// *** Acuses PDF'S ***
const {
  imprimirFormato,
} = useEscenario(idEscenario.value);

</script>
