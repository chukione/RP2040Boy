<template>
  <div
    v-show="asignData == 'Success'"
    class="flex flex-col justify-between gap-4">
    <!-- Tables -->
    <div class="flex flex-col gap-4 px-3">
      <!--Tabla 1-->
      <div>
        <UTable
          :columns="columns"
          class="border-[1px] dark:border-ineRosa rounded-md shadow-md"
          :rows="rows"
          :ui="{
            th: {
              base: 'text-center rtl:text-right bg-ineAzul text-white dark:bg-[#2e2e2e84]',
              padding: 'p-2',
              color: 'text-gray-900 dark:text-white',
              font: 'font-semibold',
              size: 'text-xs',
            },
            tr: {
              base: 'text-center align',
              selected: 'bg-gray-50 dark:bg-gray-800/50',
              active: 'hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer',
            },
          }"
        >
          <!-- Status Vialidad-->
          <template #col4-data="{ row }">
            <div v-if="row.col4 === 1">
              <UIcon
                class="text-lg text-green-500"
                name="i-heroicons-check-circle"
              />
            </div>
            <div v-if="row.col4 === 0">
              <UIcon class="text-lg text-red-500" name="i-heroicons-x-circle" />
            </div>
          </template>
          <!-- Status Sitio -->
          <template #col5-data="{ row }">
            <div v-if="row.col5 === 1">
              <UIcon
                class="text-lg text-green-500"
                name="i-heroicons-check-circle"
              />
            </div>
            <div v-if="row.col5 === 0">
              <UIcon class="text-lg text-red-500" name="i-heroicons-x-circle" />
            </div>
          </template>
        </UTable>
      </div>
      <!--Fin tabla 1-->
      <!--Tabla 2-->
      <div class="border-[1px] dark:border-ineRosa rounded-md shadow-md">
        <UTable
          :columns="columnsNewTable"
          :rows="rowsNewTable"
          class="rounded-md"
          :ui="{
            th: {
              base: 'text-center rtl:text-right bg-ineAzul text-white dark:bg-[#2e2e2e84]',
              padding: 'p-2',
              color: 'text-gray-900 dark:text-white',
              font: 'font-semibold',
              size: 'text-xs',
            },
            tr: {
              selected: 'text-center bg-gray-50 dark:bg-gray-800/50',
              active: 'hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer',
            },
          }"
        >
          <template #col1-data="{ row }">
            <div v-if="row.col1" class="w-[180px] mx-auto text-wrap text-center">
              {{ row.col1 }}
            </div>
          </template>
          <template #col3-data="{ row }">
            <div v-if="row.col3" class="font-bold text-center">
              {{ row.col3 }}
            </div>
          </template>
        </UTable>
        <div
          class="flex justify-center items-center px-3 py-3.5 border-t border-gray-200 dark:border-gray-700 font-[ui-sans-serif, system-ui, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji'] bg-[#2e2e2e10] cursor-pointer rounded-b-md dark:bg-[#2e2e2e44]"
        >
          <!-- < v-model="q" placeholder="Filter people..." /> -->
          <p class="text-sm font-semibold dark:text-white">
            EVALUACIÓN DEL ESCENARIO:
            <span class="text-inePurpura font-bold text-sm dark:text-pink-400">{{
              roundNumbers(dataEscenario?.Calificacion)
            }}</span>
            PUNTOS
          </p>
        </div>
      </div>
    </div>
    <!--Action Buttons-->
    <div :class="isDark ? 'modoOscuroComentarios' : 'bg-white'" class="flex flex-col gap-4 py-3 sticky bottom-0 px-3">
      <!-- Imprimir Formato -->
      <div class="flex justify-center">
        <UButton
          icon="i-heroicons-printer"
          class="flex justify-center w-full"
          label="Imprimir Formato"
          color="white"
          :ui="{
            color: {
              white: {
                solid:
                  'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
              },
            },
          }"
          @click="
            calificacion !== null && dataEscenario !== null && imagesReady
              ? imprimirFormato('FORMATO DE EVALUACIONES')
              : withoutQualification()
          "
        />
      </div>
      <!-- Regresar Inicio -->
      <div class="flex justify-center">
        <NuxtLink class="w-full" to="/console">
          <UButton
            icon="i-heroicons-home"
            class="flex justify-center w-full"
            label="Regresar"
            color="white"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-ineAzul dark:ring-ineRosa text-white dark:text-ineRosa bg-ineAzul hover:bg-[#80416b55] hover:text-ineAzul disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-ineAzul hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }"
          />
        </NuxtLink>
      </div>
    </div>
  </div>
</template>

<script setup>
import { roundNumbers } from '@/services/roundNumbers';
import { sideBarStore } from '@/stores/sideBar';

const storeSideBar = sideBarStore();
const { idEscenario } = storeToRefs(storeSideBar);

// console.log(idEscenario.value);

const {
  asignData,
  columns,
  rows,
  columnsNewTable,
  rowsNewTable,
  dataEscenario,
  isDark,
  calificacion,
  imagesReady,
  withoutQualification,
  imprimirFormato,
} = useEscenario(idEscenario.value);
</script>
