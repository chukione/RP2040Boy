<template>
  <div class="flex flex-col justify-between px-3 h-full">
    <!-- Alert -->
    <div>
      <UAlert
        :ui="{
          color: {
            white: {
              solid:
                'cursor-pointer text-xs shadow-sm ring-1 ring-inset ring-ineRosa dark:ring-ineRosa text-white dark:text-ineRosa bg-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-bg duration-700',
            },
          },
        }" 
        icon="i-heroicons-information-circle" :description="`El escenario debe tener un total de ${optionsSt.length} secciones de trabajo`" title="Información!" />
    </div>
    <div class="h-full flex flex-col justify-evenly py-2">
      <!-- Main Content -->
      <!-- Limpiar Sección de trabajo / Añadir/Quitar Manzanas -->
      <div
        class="flex flex-col justify-center border-[0.5px] py-3 rounded-md shadow-md dark:hover:shadow-md dark:hover:shadow-ineRosa dark:border-ineRosa dark:bg-[#2e2e2e44] cursor-pointer transition-shadow duration-700 relative">
        <!-- Action Buttons -->
        <div class="flex flex-col justify-center gap-2">
          <h1 class="font-bold text-center text-ineAzul dark:text-ineRosa text-[18px]">
            Editar sección de trabajo
          </h1>
          <!-- Select Sección de trabajo -->
          <div class="flex flex-col justify-center items-center">
            <USelect
              v-model="st_" class="w-5/6 mx-auto" :options="optionsSt" value-attribute="id"
              option-attribute="numero" placeholder="Seleccionar sección" :ui="{
                color: {
                  white: {
                    outline:
                      'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset dark:ring-gray-700 focus:ring-2 focus:ring-ineRosa dark:focus:ring-primary-400',
                  },
                },
              }" @change="changeST()" />
          </div>
          <!-- Añadir manzanas -->
          <div class="flex justify-center">
            <UButton
              :disabled="st_ === null || selectedFeatures.length === 0"
              icon="i-heroicons-plus" label="Añadir manzanas" color="white" 
              class="flex justify-center w-5/6"
              :ui="{
                color: {
                  white: {
                    solid:
                      'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                  },
                },
              }"
              @click="agregarManzanas" />
          </div>
          <!-- Quitar manzanas -->
          <div class="flex justify-center">
            <UButton
              :disabled="st_ === null || selectedFeatures.length === 0"
              icon="i-heroicons-trash" label="Quitar manzanas" color="white"
              class="flex justify-center w-5/6"
              :ui="{
                color: {
                  white: {
                    solid:
                      'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                  },
                },
              }" @click="deleteST" />
          </div>
          <!-- Limpiar Sección de Trabajo -->
          <div class="flex justify-center">
            <UButton
              :disabled="st_ === null"
              icon="i-heroicons-archive-box-x-mark" class="flex justify-center w-5/6"
              label="Limpiar sección de trabajo" color="white" :ui="{
                color: {
                  white: {
                    solid:
                      'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                  },
                },
              }" @click="clearST()" />
          </div>
          <!-- Limpiar manzanas seleccionadas -->
          <div class="flex justify-center">
            <UButton
              :disabled="selectedFeatures.length === 0"
              icon="i-heroicons-backspace" class="flex justify-center w-5/6"
              label="Limpiar manzanas seleccionadas" color="white" :ui="{
                color: {
                  white: {
                    solid:
                      'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                  },
                },
              }" @click="limpiarSelectedFeatures()" />
          </div>
          <!-- Tooltip de como usar -->
          <div class="absolute top-2 right-2">
            <UPopover mode="hover">
              <UIcon name="i-heroicons-information-circle"/>
              <template #panel>
                <div class="p-2 text-sm text-gray-500">
                  <!-- <Placeholder class="h-20 w-48" /> -->
                  <p class="font-semibold" >Reglas de uso</p>
                  <li>Sí desea limpiar una sección de trabajo, primero eliga una sección.</li>
                  <li>Sí desea agregar o quitar una manzana, eliga la sección y la(s) manzanas deseadas.</li>
                </div>
              </template>
            </UPopover>
          </div>
        </div>
      </div>

      <div v-if="selectedFeatures.length !== 0" class="max-h-[148px] flex flex-col overflow-auto border bg-[#80416be4] dark:border-ineRosa dark:text-[#e6a4bee5] dark:bg-[#2e2e2e44] p-2 rounded-md text-white gap-2">
        <div class=" font-semibold text-[14px] text-center pb-1 border-b dark:border-ineRosa">
          <h1>Manzanas seleccionadas</h1>
        </div>
        <div class="flex flex-col flex-wrap overflow-auto gap-2 text-[12px] px-1">
          <div v-for="(manzana, index) in selectedFeatures" :key="index">
            <div class="flex gap-1">
              <p class="font-semibold">{{ index + 1 }}. </p>
              <p class=" font-light">{{ manzana }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Button Back -->
    <div class="sticky bottom-3">
      <!-- Regresar Inicio -->
      <div class="flex justify-center">
        <UButton
          icon="i-heroicons-home" class="flex justify-center w-full" label="Regresar" color="white"
          :ui="{
            color: {
              white: {
                solid:
                  'text-xs shadow-sm ring-1 ring-inset ring-ineAzul dark:ring-ineRosa text-white dark:text-ineRosa bg-ineAzul hover:bg-[#80416b55] hover:text-ineAzul disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-ineAzul hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
              },
            },
          }" @click="returnPage" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, defineEmits } from 'vue';
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/stores/sideBar';

const storeSideBar = sideBarStore();
const { selectedFeatures, st, goverment, district, section, idEscenario } =
    storeToRefs(storeSideBar);
const { $notify } = useNuxtApp();
const seccionesList = ref([]);
const emit = defineEmits(['updatedata']);

const returnPage = () => {
  navigateTo('/console/crearEscenarios');
};

onMounted(async () => {
  if (idEscenario.value) {
    selectedFeatures.value = [];
    await getSecciones();
  }
});

const st_ = ref(null);
const optionsSt = computed(() => {
  const data = [];
  if (seccionesList.value.length === 0) {
    return data;
  }
  for (const item of seccionesList.value) {
    data.push({ id: item.id, numero: `Sección ${item.numero}` });
  }
  return data;
});
const getSecciones = async () => {
  try {
    const id = idEscenario.value;
    const url = `http://localhost:3030/getStrabajo?id=${id}`;
    seccionesList.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'ST',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
const changeST = () => {
  storeSideBar.setST(st_.value);
};

const agregarManzanas = async () => {
  const manzanas = String(selectedFeatures.value);
  try {
    const id = idEscenario.value;
    const url = `http://localhost:3030/update-mzn-st?idEscenario=${id}&idSt=${st.value}&manzanasEntrada=${manzanas}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&tipoActualizacion=agregar`;
    // seccionesList.value =
    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    // console.log('cambie bandera: setBanderaRePaint ');
    storeSideBar.setBanderaRePaint(true);
    // Aqui va el modal ***********
    evaluaST();
    evaluaEscenario();
    emit('updatedata');
    selectedFeatures.value = [];
    // ******************
  } catch (error) {
    $notify({
      title: 'actualizar Manzanas',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

const evaluaST = async () => {
  try {
    const id = idEscenario.value;
    // const url = `http://localhost:3030/evaluaSt?id=${id}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}`;
    const url = `http://localhost:3030/evaluaSt?id=${id}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}`;
    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    // return evaluaSTprueba;
  } catch (error) {
    $notify({
      title: 'Evaluar Secciones de Trabajo',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

const clearST = async () => {
  try {
    const url = `http://localhost:3030/clear-secmanzanas?id_st=${st_.value}`;
    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    storeSideBar.setBanderaRePaint(true);
    evaluaST();
    evaluaEscenario();
    emit('updatedata');
  } catch (error) {
    $notify({
      title: 'Limpiar Secciones de Trabajo',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

const deleteST = async () => {
  const id = idEscenario.value;
  const manzanas = String(selectedFeatures.value);
  try {
    const url = `http://localhost:3030/update-mzn-st?idEscenario=${id}&idSt=${st_.value}&manzanasEntrada=${manzanas}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&tipoActualizacion=borrar`;
    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    storeSideBar.setBanderaRePaint(true);
    evaluaST();
    evaluaEscenario();
    emit('updatedata');
    selectedFeatures.value = [];
  } catch (error) {
    $notify({
      title: 'Eliminar Secciones de Trabajo',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

const evaluaEscenario = async () => {
  const id = idEscenario.value;
  try {
    const url = `http://localhost:3030/evaluarEscenario?id_esc=${id}`;
    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Evalua escenario',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
    console.error(error);
  }
};

const limpiarSelectedFeatures = () => {
  selectedFeatures.value = [];
  storeSideBar.setBanderaRePaint(true);
  storeSideBar.setIdsMzn(selectedFeatures.value);
};

</script>
