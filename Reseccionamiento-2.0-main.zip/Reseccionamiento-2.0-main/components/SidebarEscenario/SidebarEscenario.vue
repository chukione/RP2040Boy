<template>
  <div :class="isDark ? 'modoOscuroMain' : 'bg-white'" class="w-full border-r shadow-md dark:border-ineRosa dark:shadow-ineRosa" :style="{ height: `${availableHeight}px` }">
    <!-- Header Action Buttons -->
    <div ref="compHeight" class="flex flex-wrap justify-evenly gap-4 px-2 py-3 sticky top-0 z-10 border-b-[0.5px] dark:border-ineRosa">
      <!-- Edición ST -->
      <div v-if="showBtoEditar">
        <UTooltip v-if="TipoSeleccion !== 0" text="Edición ST">
          <UButton
            icon="i-heroicons-pencil-square"
            class="flex justify-center"
            color="white"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-inePurpura disabled:ring-ineRosa disabled:font-semibold disabled:text-white hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }"
            @click="TipoSeleccion = 0"
          />
        </UTooltip>
        <UButton
          v-if="TipoSeleccion === 0"
          icon="i-heroicons-pencil-square"
          class="flex justify-center"
          :label="TipoSeleccion === 0 ? 'Edición ST' : ''"
          color="white"
          :ui="{
            color: {
              white: {
                solid: TipoSeleccion === 0 ?
                  'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-inePurpura disabled:bg-inePurpura disabled:ring-ineRosa disabled:font-semibold disabled:text-white dark:bg-inherit dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400'
                  :
                  ''
              },
            },
          }"
          @click="TipoSeleccion = 0"
        />
      </div>
      <!-- Calificación -->
      <div>
        <UTooltip v-if="TipoSeleccion !== 1" text="Calificación">
          <UButton
            icon="i-heroicons-star"
            class="flex justify-center"
            :label="TipoSeleccion === 1 ? 'Calificación' : ''"
            color="white"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-inePurpura disabled:ring-ineRosa disabled:font-semibold disabled:text-white hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }"
            @click="TipoSeleccion = 1"
          />
        </UTooltip>
        <UButton
          v-if="TipoSeleccion === 1"
          icon="i-heroicons-star"
          class="flex justify-center"
          :label="TipoSeleccion === 1 ? 'Calificación' : ''"
          color="white"
          :ui="{
            color: {
              white: {
                solid: TipoSeleccion === 1 ?
                  'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-inePurpura disabled:bg-inePurpura disabled:ring-ineRosa disabled:font-semibold disabled:text-white dark:bg-inherit dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400'
                  :
                  ''
              },
            },
          }"
          @click="TipoSeleccion = 1"
        />
      </div>
      <!-- Comentarios -->
      <div>
        <UTooltip v-if="TipoSeleccion !== 2" text="Comentarios">
          <UButton
            icon="i-heroicons-chat-bubble-bottom-center-text"
            class="flex justify-center"
            :label="TipoSeleccion === 2 ? 'Comentarios' : ''"
            color="white"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-inePurpura disabled:ring-ineRosa disabled:font-semibold disabled:text-white hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }"
            @click="TipoSeleccion = 2"
          />
        </UTooltip>
        <UButton
          v-if="TipoSeleccion === 2"
          icon="i-heroicons-chat-bubble-bottom-center-text"
          class="flex justify-center"
          :label="TipoSeleccion === 2 ? 'Comentarios' : ''"
          color="white"
          :ui="{
            color: {
              white: {
                solid: TipoSeleccion === 2 ?
                  'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-inePurpura disabled:bg-inePurpura disabled:ring-ineRosa disabled:font-semibold disabled:text-white dark:bg-inherit dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400'
                  :
                  ''
              },
            },
          }"
          @click="TipoSeleccion = 2"
        />
      </div>
      <!-- Descargas -->
      <div>
        <UTooltip v-if="TipoSeleccion !== 3" text="Descargas">
          <UButton
            icon="i-heroicons-arrow-down-tray"
            class="flex justify-center"
            :label="TipoSeleccion === 3 ? 'Descargas' : ''"
            color="white"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-inePurpura disabled:ring-ineRosa disabled:font-semibold disabled:text-white hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }"
            @click="TipoSeleccion = 3"
          />
        </UTooltip>
        <UButton
          v-if="TipoSeleccion === 3"
          icon="i-heroicons-arrow-down-tray"
          class="flex justify-center"
          :label="TipoSeleccion === 3 ? 'Descargas' : ''"
          color="white"
          :ui="{
            color: {
              white: {
                solid: TipoSeleccion === 3 ?
                  'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-inePurpura disabled:bg-inePurpura disabled:ring-ineRosa disabled:font-semibold disabled:text-white dark:bg-inherit dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400'
                  :
                  ''
              },
            },
          }"
          @click="TipoSeleccion = 3"
        />
      </div>
    </div>
    <!-- Main Content -->
    <div class="overflow-auto pt-4" :style="{ height: `${availableHeight2}px` }">
      <div v-show="TipoSeleccion === 0" class="h-full">
        <SidebarEscenarioVerEscenarioTabEditarEscenario @updatedata="updateCalificacion" />
      </div>
      <div v-show="TipoSeleccion === 1" class="h-full">
        <SidebarEscenarioVerEscenarioComponentCalificacion2 ref="calComp" />
      </div>
      <div v-show="TipoSeleccion === 2" class="h-full">
        <SidebarEscenarioVerEscenarioComponentComentario2 />
      </div>
      <div v-show="TipoSeleccion === 3">
        <SidebarEscenarioVerEscenarioComponentDescarga2 />
      </div>
    </div>
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { medidasStores } from '@/stores/medidasStores';

const route = useRoute();
const storeSideBar = sideBarStore();
watchEffect(()=>{
  storeSideBar.setRouteLocationKey(route.fullPath);
});

// *** Manejo de Stores ***
const storeMedidas = medidasStores();
const { dataAlto } = storeToRefs(storeMedidas);

const availableHeight = ref(null);
watchEffect(() => {
  availableHeight.value = dataAlto.value;
});

const setDataAltoComentarios = (val) => {
  storeMedidas.setDataAltoComentarios(val);
};

const TipoSeleccion = ref(null);

const showBtoEditar = ref(false);
let resizeObserver;
onMounted(() => {
  if (route.path === '/console/editarEscenarios') {
    showBtoEditar.value = true;
    TipoSeleccion.value = 0;
  }
  if (route.path === '/console/verEscenario') {
    TipoSeleccion.value = 1;
  }

  resizeObserver = new ResizeObserver(getDimensions);
  resizeObserver.observe(document.body);
  getDimensions();
});

const calComp = ref(null);
const updateCalificacion = async () => {
  await calComp.value?.getCalificacion();
};

const compHeight = ref(null);
const availableHeight2 = ref(0);
const getDimensions = () => {
  const headerHeight = compHeight.value ? compHeight.value.clientHeight : 0;
  availableHeight2.value = availableHeight.value - headerHeight;
  setDataAltoComentarios(availableHeight2.value);
};

// DarkMode
const colorMode = useColorMode();
const isDark = computed({
  get () {
    return colorMode.value === 'dark';
  },
  set () {
    colorMode.preference = colorMode.value === 'dark' ? 'light' : 'dark';
  },
});
</script>
