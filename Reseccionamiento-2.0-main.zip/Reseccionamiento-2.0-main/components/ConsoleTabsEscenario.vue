<template>
  <div>
    <div>
      <ul class="flex flex-wrap text-xs font-medium text-center text-gray-500 dark:text-gray-400">
        <li class="mr-1">
          <button
            v-if="showBtoEditar"
            class="inline-block px-2 py-2 bg-fuchsia-100 text-black rounded-md"
            :class="{' bg-navBar text-white  ' : TipoSeleccion ===0 }"
            @click="TipoSeleccion = 0"
          >
            <IconComponent :icon="['fas', 'star']" />
            Edición ST
          </button>
        </li>
        <li class="mr-1">
          <button
            class="inline-block px-2 py-2 bg-fuchsia-100 text-black rounded-md"
            :class="{' bg-navBar text-white  ' : TipoSeleccion ===1 }"
            @click="TipoSeleccion = 1"
          >
            <IconComponent :icon="['fas', 'star']" />
            Calificación
          </button>
        </li>
        <li class="mr-1">
          <button
            class="inline-block px-2 py-2 bg-fuchsia-100 text-black rounded-md"
            :class="{' bg-navBar text-white ' : TipoSeleccion ===2 }"
            @click="TipoSeleccion = 2"
          >
            <IconComponent :icon="['fas', 'comments']" />
            Comentarios
          </button>
        </li>
        <li class="">
          <button
            class="inline-block px-1 py-2 bg-fuchsia-100 text-black rounded-md"
            :class="{' bg-navBar text-white ' : TipoSeleccion ===3 }"
            @click="TipoSeleccion = 3"
          >
            <IconComponent :icon="['fas', 'download']" />
            Descargas
          </button>
        </li>
      </ul>
    </div>
    <div class="p-3 mt-6 bg-white border">
      <div v-show="TipoSeleccion === 0">
        <ComponentEdicionST @updatedata="updateCalificacion()" />
      </div>
      <div v-show="TipoSeleccion === 1">
        <ComponentCalificacion ref="calComp" />
      </div>
      <div v-show="TipoSeleccion === 2">
        <ComponentComentario />
      </div>
      <div v-show="TipoSeleccion === 3">
        <ComponentDescarga />
      </div>
    </div>
  </div>
</template>

<script setup>
import ComponentDescarga from './ComponentDescarga.vue';
const calComp = ref(null);

const TipoSeleccion = ref(null);

const route = useRoute();
const showBtoEditar = ref(false);
onMounted(() => {
  console.log(route.path);
  if (route.path === '/console/editarEscenarios') {
    showBtoEditar.value = true;
    TipoSeleccion.value = 0;
  }
  if (route.path === '/console/verEscenario') {
    TipoSeleccion.value = 1;
  }
});

const updateCalificacion = () => {
  calComp.value?.getCalificacion();
};
</script>
