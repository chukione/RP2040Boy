<template>
  <div
    class="bg-white dark:bg-[#2e2e2e44] w-[312px] shadow-md rounded-md border border-ineAzul dark:border-ineRosa py-4 px-5 flex flex-col gap-2 relative"
  >
    <!-- Header -->
    <div class="flex items-center gap-3">
      <!-- Logo -->
      <div>
        <img class="w-12" :src="ImageSrc" >
      </div>
      <!-- Title -->
      <div>
        <h1 class="text-lg font-bold text-ineAzul dark:text-ineRosa">
          {{ props.escenario.Alias }}
        </h1>
        <h2 class="text-inePurpura dark:text-ineRosa font-bold">
          {{ props.escenario.Nstemporales }} secciones de trabajo
        </h2>
      </div>
    </div>

    <!-- Data Main -->
    <div class="w-full flex flex-col justify-between">
      <div
        v-for="item in getDataCards"
        :key="`informacion-${item.score}-${item.labelType}`"
        class="grid grid-cols-3 text-[12px] gap-3"
      >
        <div>
          <label>{{ item.labelPuntos }}</label>
        </div>
        <div>
          <label>{{ item.labelType }}</label>
        </div>
        <div class="text-end">
          {{ roundNumbers(item.score) }}
        </div>
      </div>
    </div>

    <!-- Footer -> Score -->
    <div
      class="flex justify-end items-center text-inePurpura dark:text-ineRosa font-bold"
    >
      {{ roundNumbers(props.escenario.Calificacion) }}
    </div>

    <div
      class="w-full flex items-center justify-center border-t pt-4 border-ineAzul dark:border-ineRosa"
    >
      <UButton
        v-if="props.escenario.Guardado === 0"
        icon="i-heroicons-map"
        class="flex justify-center w-full"
        label="Validar y Guardar"
        color="white"
        :ui="{
          color: {
            white: {
              solid:
                'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
            },
          },
        }"
        @click="isOpen = true"
      />
      <UButton
        v-if="props.escenario.Guardado !== 0"
        :icon="props.escenario.Guardado === 1 && props.escenario.Seleccion_guardado === 1 ? 'i-heroicons-check-circle' : 'i-heroicons-arrow-down-on-square-stack'"
        class="flex justify-center w-full"
        :label="`Guardado el ${formatearFecha(props.escenario.Fguardado)}`"
        color="white"
        :disabled="true"
        :ui="{
          color: {
            white: {
              solid:
                'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
            },
          },
        }"
      />
    </div>
    <!-- Escenario liberado -->
    <div v-if="props.escenario.Guardado === 1 && props.escenario.Seleccion_guardado === 1" class="absolute top-2 right-2">
      <UIcon class="text-green-500" name="i-heroicons-check-circle text-[30px]" />
    </div>
    <!-- Modal para confirmar la validación y guardado del escenario -->
    <UModal
      v-model="isOpen"
      :ui="{
        container: 'flex min-h-full items-end sm:items-center justify-center text-center text-white',
        background: isDark ? 'modoOscuroMain' : 'bg-[#252756d2]',
        overlay: {
          base: 'fixed inset-0 transition-opacity',
          background: 'bg-gray-400/75 dark:bg-[#2e2e2e80]',
          transition: {
            enter: 'ease-out duration-300',
            enterFrom: 'opacity-0',
            enterTo: 'opacity-100',
            leave: 'ease-in duration-200',
            leaveFrom: 'opacity-100',
            leaveTo: 'opacity-0',
          },
        },
      }"
    >
      <div class="py-5">
        <h1 class="flex text-center items-center justify-center text-xl font-semibold dark:font-normal">¿Desea validar y guardar el escenario?</h1>
        <div class="pt-6 flex gap-4 items-center justify-center">
          <UButton  
            color="white" 
            label="Cancelar"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-sm shadow-sm ring-1 ring-inset ring-red-600 dark:ring-red-600 text-white dark:text-red-600 bg-red-600 hover:bg-red-700 hover:ring-red-700 dark:bg-inherit dark:hover:bg-gray-800/50 disabled:bg-red-600 dark:disabled:bg-inherit focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }" 
            @click="isOpen = false" />
          <UButton
            label="Guardar"  
            color="white"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-sm shadow-sm ring-1 ring-inset ring-green-600 dark:ring-green-600 text-white dark:text-green-600 bg-green-600 hover:bg-green-700 hover:ring-green-700 dark:bg-inherit dark:hover:bg-gray-800/50 disabled:bg-green-600 dark:disabled:bg-inherit focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }" 
            @click="saveValidate"/>
        </div>
      </div>
    </UModal>
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { roundNumbers } from '@/services/roundNumbers';
import { sideBarStore } from '@/stores/sideBar';
const { $notify } = useNuxtApp();

const storeSideBar = sideBarStore();
const { goverment, district, section, etapa } = storeToRefs(storeSideBar);
const props = defineProps({
  escenario: {
    required: true,
    type: Object,
  },
});
const propId = props.escenario.Id;
const ImageSrc = `/_nuxt/assets/${props.escenario.Logo}`;
const getDataCards = computed(() => {
  const data = [];
  data.push({
    labelPuntos: '(30pts)',
    labelType: 'Rango',
    score: roundNumbers(props.escenario.Rango),
  });
  data.push({
    labelPuntos: '(24pts)',
    labelType: 'Conformación',
    score: roundNumbers(props.escenario.Conformacion),
  });
  data.push({
    labelPuntos: '(22pts)',
    labelType: 'Vialidad',
    score: roundNumbers(props.escenario.Vialidad),
  });
  data.push({
    labelPuntos: '(24pts)',
    labelType: 'Sitio',
    score: roundNumbers(props.escenario.Sitio),
  });

  return data;
});

// Modal
const isOpen = ref(false);

// Funcion que permite guardar la informacion del escenario
const emit = defineEmits(['update:guardar-escenario']);
const saveValidate = async () => {
  if (Number(goverment.value) <= 0) {
    return;
  }
  try {
    const url = `http://localhost:3030/guardarEscenario?idEscenario=${propId}&etapa=${etapa.value}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&typeUser=MORENA-CDV`;

    // console.log(url);

    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    $notify({
      title: 'Validar y guardar',
      text: 'El escenario fue guardado con éxito',
      type: 'success',
    });
    // Emitir el evento de actualización
    emit('update:guardar-escenario', propId);
    imprimirFormato('ACUSE DE ESCENARIO GUARDADO');
  } catch (error) {
    $notify({
      title: 'Validar y guardar',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  } finally {
    isOpen.value = false;
  }
};

function formatearFecha(fechaISO) {
  const fecha = new Date(fechaISO);

  const año = fecha.getFullYear();
  const mes = String(fecha.getMonth() + 1).padStart(2, '0');
  const día = String(fecha.getDate()).padStart(2, '0');
  const horas = String(fecha.getHours()).padStart(2, '0');
  const minutos = String(fecha.getMinutes()).padStart(2, '0');
  const segundos = String(fecha.getSeconds()).padStart(2, '0');

  return `${año}-${mes}-${día} ${horas}:${minutos}:${segundos}`;
}

// *** Acuses PDF'S ***
const {
  imprimirFormato,
} = useEscenario(propId);

// DarkMode
const colorMode = useColorMode();
const isDark = computed({
  get () {
    return colorMode.value === 'dark';
  },
  set () {
    colorMode.preference = colorMode.value === 'dark' ? 'light' : 'dark';
  },
});
</script>

<style>
.hola{
  color: #252756e4;
}
</style>
