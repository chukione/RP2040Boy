<template>
  <div class="overflow-auto p-5" :style="{ height: `${availableHeight}px`, width: `${availableWidth}px` }">
    <div v-if="dataEscenarios.length > 0" class="flex flex-col gap-4">
      <!-- buttons -->
      <div class="flex justify-center gap-2">
        <UButton
          v-if="!showCards"
          icon="i-heroicons-credit-card"
          class="flex justify-center w-1/6"
          label="Ver tarjetas"
          color="white"
          :ui="{
            color: {
              white: {
                solid:
                  'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
              },
            },
          }"
          @click="cardsShow"
        />
        <UButton
          v-if="!showTable"
          icon="i-heroicons-table-cells"
          class="flex justify-center w-1/6"
          label="Ver tabla"
          color="white"
          :ui="{
            color: {
              white: {
                solid:
                  'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
              },
            },
          }"
          @click="tableShow"
        />
      </div>
      <!-- cards -->
      <div v-if="showCards" :class="dataEscenarios.length > 1 ? 'justify-center' : 'justify-start'" class="flex flex-wrap gap-10">
        <!-- <div class="grid lg:grid-cols-3 md:grid-cols-1 grid-cols-1 gap-10">
        </div> -->
        <SidebarComponentTabsTabVerEscenarioCardVerEscenario
          v-for="esc in dataEscenarios"
          :key="`escenario-${esc.Id}`"
          :escenario="esc"
        />
      </div>
      <!-- table -->
      <div v-if="showTable" class="border-[0.5px] shadow-md dark:border-ineRosa rounded-md px-4 bg-white dark:bg-[#2e2e2e44] mt-3">
        <div>
          <UTable
            :rows="dataEscenarios"
            :columns="columns"
            :progress="{ color: 'primary', animation: 'carousel' }"
            :ui="{
              th: {
                base: 'text-center rtl:text-right',
                font: 'font-semibold',
              },
              tr: {
                base: 'text-center',
                selected: 'bg-gray-100 dark:bg-gray-800/50',
              },
            }"
            @select="mapa-dataEscenarios"
          >
            <template
              #Rango-data="{ row }"
            >
              <div v-if="row.Rango">
                {{ roundNumbers(row.Rango) }}
              </div>
            </template>
            <template
              #Conformacion-data="{ row }"
            >
              <div v-if="row.Rango">
                {{ roundNumbers(row.Conformacion) }}
              </div>
            </template>
            <template
              #Calificacion-data="{ row }"
            >
              <div v-if="row.Rango">
                {{ roundNumbers(row.Calificacion) }}
              </div>
            </template>
            <template #mapa-data="row">
              <UTooltip
                text="Ver Mapa"
              >
                <UButton
                  icon="i-heroicons-map"
                  color="white"
                  :ui="{
                    color: {
                      white: {
                        solid:
                          'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                      },
                    },
                  }"
                  @click="showEscenario(row.row, row.row.Id)"
                />
              </UTooltip>
            </template>
          </UTable>
        </div>
      </div>
    </div>
    <div v-else class=" text-red-500">
      Sin datos
    </div>
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from './../../stores/sideBar';
import { medidasStores } from '@/stores/medidasStores';
import { roundNumbers } from '~/services/roundNumbers';

// *** Manejo de Stores ***
const storeMedidas = medidasStores();
const { dataAltoMain, dataAncho } = storeToRefs(storeMedidas);

const availableHeight = ref(null);
const availableWidth = ref(null);
watchEffect(() => {
  availableHeight.value = dataAltoMain.value;
  availableWidth.value = dataAncho.value;
});
const storeSideBar = sideBarStore();
const { dataEscenarios } = storeToRefs(storeSideBar);
const showCards = ref(true);
const showTable = ref(false);
const tableShow = () => {
  showCards.value = false;
  showTable.value = true;
};
const cardsShow = () => {
  showCards.value = true;
  showTable.value = false;
};

const columns = [
  {
    key: 'Usuario',
    label: 'Usuario',
    sortable: true,
  },
  {
    key: 'Nstemporales',
    label: 'Num_ST',
    sortable: true,
  },
  {
    key: 'Rango',
    label: 'Rango',
    sortable: true,
  },
  {
    key: 'Conformacion',
    label: 'Conformación',
    sortable: true,
  },
  {
    key: 'Vialidad',
    label: 'Vialidad',
    sortable: true,
  },
  {
    key: 'Sitio',
    label: 'Sitio',
    sortable: true,
  },
  {
    key: 'Calificacion',
    label: 'Calificación',
    sortable: true,
  },
  {
    key: 'Seleccion_guardado',
    label: 'S. Guardado',
    sortable: true,
  },
  {
    key: 'Declinado',
    label: 'Declinado',
    sortable: true,
  },
  {
    key: 'Liberado',
    label: 'S. Liberado',
    sortable: true,
  },
  {
    key: 'Recomendado',
    label: 'Recomendado',
    sortable: true,
  },
  {
    key: 'mapa',
    label: 'Ver mapa',
  },
];

const showEscenario = (escenario, escenarioId) => {
  storeSideBar.setEscenarioVer(escenario);
  storeSideBar.setIdEscenario(escenarioId);
  navigateTo('/console/verEscenario');
};
</script>

<style scoped>

.hola{
  color:#80416b55
}
</style>
