<template>
  <div class="bg-white dark:bg-[#2e2e2e44] w-[312px] shadow-md rounded-md border border-ineAzul dark:border-ineRosa py-4 px-5 flex flex-col gap-2">
    <!-- Header -->
    <div class="flex items-center gap-3">
      <!-- Logo -->
      <div>
        <img class="w-12" :src="ImageSrc">
      </div>
      <!-- Title -->
      <div>
        <h1 class="text-lg font-bold text-ineAzul dark:text-ineRosa">
          {{ props.escenario.alias }}
        </h1>
        <h2 class="text-inePurpura dark:text-ineRosa font-bold">
          {{ props.escenario.nstemporales }} secciones de trabajo
        </h2>
      </div>
    </div>
    <!-- Data Main -->
    <div class="w-full flex flex-col justify-between">
      <div
        v-for="item in getDataCards"
        :key="`informacion-${item.score}-${item.labelType}`"
        class="grid grid-cols-3 text-[12px] gap-3"
      >
        <div>
          <label>{{ item.labelPuntos }}</label>
        </div>
        <div>
          <label>{{ item.labelType }}</label>
        </div>
        <div class="text-end">
          {{ roundNumbers(item.score) }}
        </div>
      </div>
    </div>
    <!-- Footer -> Score -->
    <div
      class="flex justify-end items-center text-inePurpura dark:text-ineRosa font-bold"
    >
      {{
        roundNumbers(
          props.escenario.rango +
            props.escenario.conformacion +
            props.escenario.vialidad +
            props.escenario.sitio, 6)
      }}
    </div>
    <!-- Button -->
    <div
      class="w-full flex items-center justify-center border-t pt-4 border-ineAzul dark:border-ineRosa"
    >
      <UButton
        v-if="props.escenario.guardado === 0"
        icon="i-heroicons-map"
        class="flex justify-center w-full"
        label="Editar Escenario"
        color="white"
        :ui="{
          color: {
            white: {
              solid:
                'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-ineRosa disabled:ring-ineRosa disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
            },
          },
        }"
        @click="saveEscenario"
      />
      <UButton
        v-if="props.escenario.guardado !== 0"
        icon="i-heroicons-exclamation-circle"
        class="flex justify-center w-full"
        label="El escenario ya ha sido guardado"
        color="white"
        :disabled="true"
        :ui="{
          color: {
            white: {
              solid:
                'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
            },
          },
        }"
      />
    </div>
  </div>
</template>

<script setup>
import { roundNumbers } from '@/services/roundNumbers';
import { sideBarStore } from '@/stores/sideBar';
const storeSideBar = sideBarStore();

// Traemos la información del escenario
const props = defineProps({
  escenario: {
    required: true,
    type: Object,
  },
});
const ImageSrc = `/_nuxt/assets/${props.escenario.logo}`;
const getDataCards = computed(() => {
  const data = [];
  data.push({
    labelPuntos: '(30pts)',
    labelType: 'Rango',
    score: props.escenario.rango,
  });
  data.push({
    labelPuntos: '(24pts)',
    labelType: 'Conformación',
    score: props.escenario.conformacion,
  });
  data.push({
    labelPuntos: '(22pts)',
    labelType: 'Vialidad',
    score: props.escenario.vialidad,
  });
  data.push({
    labelPuntos: '(24pts)',
    labelType: 'Sitio',
    score: props.escenario.sitio,
  });
  return data;
});
const saveEscenario = () => {
  storeSideBar.setEscenarioEdit(props.escenario);
  storeSideBar.setIdEscenario(props.escenario.id);
  navigateTo('/console/editarEscenarios');
};
</script>
