<template>
  <div class="bg-white shadow-md sm:rounded-lg border border-gray-200">
    <!-- header -->
    <div class="w-full flex flex-row mb-5 mt-3 px-6">
      <div>
        <img class="w-12" :src="ImageSrc">
      </div>
      <div class="ml-3">
        <div>
          <label class="text-lg font-bold">{{ props.escenario.alias }}</label>
        </div>
        <div>
          <label class="text-labelsStats font-bold">{{
            `${props.escenario.nstemporales} secciones de trabajo`
          }}</label>
        </div>
      </div>
    </div>
    <!-- /header -->
    <!-- Data -->
    <div
      v-for="item in getDataCards"
      :key="`informacion-${item.score}-${item.labelType}`"
      class="grid grid-cols-2 pl-2"
    >
      <div class="col-span-1 text-xs flex flex-row">
        <label>{{ item.labelPuntos }}</label>
        <label class="ml-4">{{ item.labelType }}</label>
      </div>
      <div class="col-span-1 text-xs ml-3">
        {{ item.score }}
      </div>
    </div>
    <!-- Score -->
    <div
      class="flex justify-end items-center text-labelsStats font-bold mb-4 mt-2 px-2"
    >
      {{
        props.escenario.rango +
          props.escenario.conformacion +
          props.escenario.vialidad +
          props.escenario.sitio
      }}
    </div>
    <!-- Button -->
    <div
      class="w-full flex items-center justify-center border-t border-gray-200"
    >
      <button
        v-if="props.escenario.guardado == 0"
        class="mt-3 mb-3 py-2 px-4 border border-transparent text-sm font-bold rounded-md text-white bg-blue-600 shadow-sm hover:bg-blue-500 focus:outline-none focus:shadow-outline-blue focus:bg-blue-500 active:bg-blue-600 transition duration-150 ease-in-out"
        @click="saveEscenario()"
      >
        <IconComponent :icon="['fas', 'map']" />
        Editar Escenario
      </button>
      <button
        v-if="props.escenario.guardado == 1"
        :disabled="true"
        class="mt-3 mb-3 py-2 px-4 border border-transparent text-sm font-bold rounded-md text-white bg-red-600 shadow-sm hover:bg-red-500 focus:outline-none focus:shadow-outline-red focus:bg-red-500 active:bg-red-600 transition duration-150 ease-in-out"
      >
        <IconComponent :icon="['fas', 'circle-exclamation']" />
        El escenario ya ha sido guardado
      </button>
    </div>
  </div>
</template>

<script setup>
import { sideBarStore } from '@/stores/sideBar';
const storeSideBar = sideBarStore();
const props = defineProps({
  escenario: {
    required: true,
    type: Object,
  },
});
const ImageSrc = `/_nuxt/assets/${props.escenario.logo}`;
const getDataCards = computed(() => {
  const data = [];
  data.push({
    labelPuntos: '(30pts)',
    labelType: 'Rango',
    score: props.escenario.rango,
  });
  data.push({
    labelPuntos: '(24pts)',
    labelType: 'Conformación',
    score: props.escenario.conformacion,
  });
  data.push({
    labelPuntos: '(22pts)',
    labelType: 'Vialidad',
    score: props.escenario.vialidad,
  });
  data.push({
    labelPuntos: '(24pts)',
    labelType: 'Sitio',
    score: props.escenario.sitio,
  });
  return data;
});
const saveEscenario = () => {
  storeSideBar.setEscenarioEdit(props.escenario);
  navigateTo('/console/editarEscenarios');
};
</script>
