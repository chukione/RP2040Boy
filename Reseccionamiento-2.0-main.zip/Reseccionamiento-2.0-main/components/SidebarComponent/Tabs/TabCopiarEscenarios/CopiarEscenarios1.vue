<script setup lang="ts">
</script>
<template>
  <div class="mx-8 bg-slate-50 p-10 border rounded-lg mt-8">
    <span class="text-xl font-medium mb-4 block text-6f2f71">
      Copiar escenario
    </span>
    <div class="flex">
      <div class="w-1/3">
        <label for="entidadResult" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Entidad</label>
        <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 mb-2 mt-1 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
      </div>
      <div class="w-1/3">
        <label for="distrito" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Distrito</label>
        <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 mb-2 mt-1 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
      </div>
      <div class="w-1/3">
        <label for="seccion" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Sección</label>
        <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 mb-2 mt-1 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
      </div>
    </div>
    <div class="flex">
      <div class="w-1/3 mt-4">
        <label for="escenario" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Seleccione un escenario</label>
        <select id="escenario" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 mb-2 mt-1 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
          <option selected>
            Seleccione escenario
          </option>
        </select>
      </div>
      <div class="w-1/3 mt-4">
        <label for="etapa" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Seleccione una etapa</label>
        <select id="etapa" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 mb-2 mt-1 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
          <option selected>
            Seleccione etapa
          </option>
        </select>
      </div>
    </div>
    <div class="flex justify-end">
      <button class="text-white bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 mt-7">
        Copiar
      </button>
    </div>
  </div>
</template>
