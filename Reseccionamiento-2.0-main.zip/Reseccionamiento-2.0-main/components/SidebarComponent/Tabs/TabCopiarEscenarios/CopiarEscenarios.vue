<template>
  <div class="bg-white dark:bg-[#2e2e2e44] border dark:border-ineRosa rounded-lg shadow-md flex flex-col gap-5 p-5">
    <div class="text-xl font-medium border-b dark:border-ineRosa border-gray-300">
      <h1 class="pb-4 text-ineAzul dark:text-ineRosa">
        Copiar Escenario
      </h1>
    </div>
    <!--Main Content-->
    <div class="flex flex-col gap-5">
      <!-- Selects -->
      <div class="form-group text-sm flex lg:flex-row md:flex-row flex-col gap-4 text-[16px]">
        <div class="grid lg:grid-cols-5 md:grid-cols-5 grid-cols gap-10 w-full items-end">
          <!-- Entidad -->
          <div>
            <p class="font-semibold mb-2 text-ineAzul dark:text-white">
              Entidad
            </p>
            <!-- <UInput
              v-model="goverment_"
              disabled
              value-attribute="id"
              option-attribute="name"
              placeholder="Seleccionar entidad"
              :ui="{
                color: {
                  white: {
                    outline:
                      'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-ineAzul dark:focus:ring-ineRosa disabled:bg-gray-100 disabled:bg-gray-100',
                  },
                },
              }"
            /> -->
            <USelect
              v-model="goverment_"
              :options="goverments"
              value-attribute="id"
              option-attribute="name"
              disabled
              placeholder="Seleccionar etapa"
              :ui="{
                color: {
                  white: {
                    outline:
                      'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-500 disabled:bg-gray-100',
                  },
                },
              }"
            />
          </div>
          <!-- Distrito -->
          <div>
            <p class="font-semibold mb-2 text-ineAzul dark:text-white">
              Distrito
            </p>
            <!-- <UInput
              v-model="district_"
              value-attribute="distrito"
              disabled
              placeholder="Seleccionar distrito"
              :ui="{
                color: {
                  white: {
                    outline:
                      'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-ineAzul dark:focus:ring-ineRosa disabled:bg-gray-100',
                  },
                },
              }"
            /> -->
            <USelect
              v-model="district_"
              :options="distritos"
              value-attribute="distrito"
              disabled
              placeholder="Seleccionar etapa"
              :ui="{
                color: {
                  white: {
                    outline:
                      'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-500 disabled:bg-gray-100',
                  },
                },
              }"
            />
          </div>
          <!-- Sección -->
          <div>
            <p class="font-semibold mb-2 text-ineAzul dark:text-white">
              Sección
            </p>
            <!-- <UInput
              v-model="section_"
              value-attribute="Seccion"
              placeholder="Seleccionar sección"
              disabled
              :ui="{
                color: {
                  white: {
                    outline:
                      'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-ineAzul dark:focus:ring-ineRosa disabled:bg-gray-100',
                  },
                },
              }"
            /> -->
            <USelect
              v-model="section_"
              :options="seccions"
              value-attribute="Seccion"
              disabled
              placeholder="Seleccionar etapa"
              :ui="{
                color: {
                  white: {
                    outline:
                      'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-500 disabled:bg-gray-100',
                  },
                },
              }"
            />
          </div>
          <!-- Escenario -->
          <div>
            <p class="font-semibold mb-2 text-ineAzul dark:text-white">
              Escenario
            </p>
            <USelect
              v-model="escenarioData"
              :options="escenarios"
              value-attribute="id"
              option-attribute="alias"
              placeholder="Seleccionar escenario"
              :ui="{
                color: {
                  white: {
                    outline:
                      'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-ineAzul dark:focus:ring-ineRosa disabled:bg-gray-100',
                  },
                },
              }"
            />
          </div>
          <!-- Etapa -->
          <div>
            <p class="font-semibold mb-2 text-ineAzul dark:text-white">
              Etapa
            </p>
            <USelect
              v-model="etapa_"
              :options="etapa"
              value-attribute="id"
              option-attribute="nombre"
              placeholder="Seleccionar etapa"
              :ui="{
                color: {
                  white: {
                    outline:
                      'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-ineAzul dark:focus:ring-ineRosa disabled:bg-gray-100 disabled:bg-gray-100',
                  },
                },
              }"
            />
          </div>
        </div>
      </div>
      <!-- Botón Copiar Escenario -->
      <div class="flex justify-center">
        <UButton
          icon="i-heroicons-bookmark" 
          label="Copiar escenario" 
          color="white"
          :ui="{
            color: {
              white: {
                solid:
                  'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
              },
            },
          }"
          @click="CopiarEscenario"  />
      </div>
    </div>
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/stores/sideBar';

// *** Logica Selects ***

const { $notify } = useNuxtApp();
const storeSideBar = sideBarStore();
const { goverment, district, section } = 
storeToRefs(storeSideBar);

// Entidad
const goverments = ref([{ id: 0, name: 'Seleccionar entidad' }]);
const goverment_ = ref(null);
const getGoverments = async () => { 
  goverments.value = storeSideBar.getGoverments();
};

onMounted(async () => {
  await getGoverments();
  if (goverment.value > 0) {
    goverment_.value = goverment.value;
    await getDistritos();
  }
  if (district.value > 0) {
    district_.value = district.value;
    await getSecciones();
  }
  if (section.value > 0) {
    section_.value = section.value;
    await getEtapas();
  }
  await getCopiarEscenarioData();
});

watch(( goverment_), async () => {
  if (goverment_.value > 0) {
    storeSideBar.setGoverment(Number(goverment_.value));
    distritos.value = [];
    district_.value = '';
    etapa_.value = '';
  }
});

// Distrito
const district_ = ref(null);
const distritos = ref([{ distrito: 'Seleccionar distrito' }]);
const getDistritos = async () => {
  try {
    const url = `http://localhost:3030/getDistritos/${goverment_.value}`;
    distritos.value = await $fetch(url, { 
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Distritos',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

// Sección
const section_ = ref(null);
const seccions = ref([{ Seccion: 'Seleccionar sección' }]);
const getSecciones = async () => {
  try {
    const url = `http://localhost:3030/getSecciones?entidad=${goverment_.value}&distrito=${district_.value}`;
    seccions.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      }, 
      method: 'GET', 
    });
  } catch (error) {
    $notify({
      title: 'Secciones',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

// Etapas
const etapa_ = ref(null);
const etapa = ref([{ Etapa: 'Seleccionar etapa' }]);
const getEtapas = async () => {
  try {
    const url = 'http://localhost:3030/etapas';
    etapa.value = await $fetch(url, { 
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET', 
    });
    etapa_.value = etapa.value[0].id;  
  } 
  catch (error) {
    $notify({
      title: 'Etapas',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

// Data Copiar Escenario
const escenarioData = ref(null);
const escenarios = ref([{ Escenarios: 'Seleccionar escenario' }]);
const getCopiarEscenarioData = async () => {
  try {
    const url = `http://localhost:3030/exGetCopiarEscenarioData?etapa=${etapa_.value}&entidad=${goverment_.value}&distrito=${district_.value}&seccion=${section_.value}&typeUser=ADMINISTRADOR`;
    escenarios.value = await $fetch(url, { 
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET', 
    });
    escenarioData.value = escenarios.value[0].id;
  } catch (error) {
    $notify({
      title: 'Escenarios',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

// Servicio Copiar Escenario
const CopiarEscenario = async () => {
  try {
    const url = `http://localhost:3030/getCopiarEscenario?etapa=${etapa_.value}&escenario=${escenarioData.value}`;
    // escenarios.value = await $fetch(url, {
    const resultado = await $fetch(url, { 
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET' });
    // console.log('escenarios.value');
    // console.log('resultado:', resultado);
    $notify({
      title: 'Copiar escenario',
      text: 'El escenario fue copiado con éxito',
      type: 'success',
    });
    // console.log('return resultado', resultado);
    return resultado;
  } catch (error) {
    $notify({
      title: 'Copiar escenario',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

</script>
