<template>
  <div class="p-2">
    <div v-if="dataLiberarEscenario.length !== 0" class="py-4 px-5 flex flex-col gap-2">
      <div :class="dataLiberarEscenario.length > 1 ? 'justify-center' : 'justify-start'" class="flex flex-wrap gap-10">
        <SidebarComponentTabsTabRecomendarEscenarioCardRecomendarEscenario
          v-for="esc in dataLiberarEscenario"
          :key="`escenario-${esc.id}`"
          :escenario="esc"
          @update:recomendar-escenario="getDataEscenario"
        />
      </div>
    </div>    
    <div v-if="dataLiberarEscenario.length === 0">
      <SidebarComponentTabsTabRecomendarEscenarioRecomendarNotFound/>
    </div>
    <!-- <div v-if="dataLiberarEscenario.length === 0">
      <SidebarComponentTabsTabRecomendarEscenarioRecomendarLiberacion/>
    </div> -->
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/stores/sideBar';

// *** Manejo de Stores ***
const storeSideBar = sideBarStore();
const { goverment, district, etapa, section, dataLiberarEscenario, EscenariosAprobar } = storeToRefs(storeSideBar);

// Trae la información de la pestaña Validar y Guardar
const dataLiberarEscenario2 = ref([]);
const getDataLiberarEscenario = async () => {
  try {
    const url = `http://localhost:3030/getLiberarEscenario?etapa=${etapa.value}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&typeUser=PAN-CNV`;
    dataLiberarEscenario2.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    if (dataLiberarEscenario2.value && dataLiberarEscenario2.value.propuestas && dataLiberarEscenario2.value.propuestas.length > 0) {
      for (const index in dataLiberarEscenario2.value.propuestas) {
        const alias = dataLiberarEscenario2.value.propuestas[index].alias;
        const urlAlias = `http://localhost:3030/getLogo?alias=${alias}`;
        const routeImage = await $fetch(urlAlias, {
          headers: {
            Accept: 'application/json, text/plain, */*',
          },
          method: 'GET',
        });
        dataLiberarEscenario2.value.propuestas[index].Logo = routeImage[0].Logo;
      }
      storeSideBar.setLiberarEscenario(dataLiberarEscenario2.value.propuestas);
      dataLiberarEscenario.value = dataLiberarEscenario2.value.propuestas;
    }
  } catch (error) {
    $notify({
      title: 'Liberar Escenarios',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

// Trae la información de la pestaña Validar y Guardar
const AprobarescenariosBefore = ref([]);
const getAprobarEscenario = async () => {
  try {
    const url = `http://localhost:3030/getAprobarEscenario?et=${etapa.value}&e=${goverment.value}&d=${district.value}&s=${section.value}&typeUser=MORENA-CLV`;
    AprobarescenariosBefore.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    if (AprobarescenariosBefore.value && AprobarescenariosBefore.value.length > 0) {
      for (const index in AprobarescenariosBefore.value) {
        const alias = AprobarescenariosBefore.value[index].Alias;
        const urlAlias = `http://localhost:3030/getLogo?alias=${alias}`;
        const routeImage = await $fetch(urlAlias, {
          headers: {
            Accept: 'application/json, text/plain, */*',
          },
          method: 'GET',
        });
        AprobarescenariosBefore.value[index].Logo = routeImage[0].Logo;
      }
      storeSideBar.setEscenariosAprobar(AprobarescenariosBefore.value);
      EscenariosAprobar.value = AprobarescenariosBefore.value;
    }
  } catch (error) {
    $notify({
      title: 'Aprobar Escenarios',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

const getDataEscenario = async () => {
  await getDataLiberarEscenario();
  await getAprobarEscenario();
};
</script>

