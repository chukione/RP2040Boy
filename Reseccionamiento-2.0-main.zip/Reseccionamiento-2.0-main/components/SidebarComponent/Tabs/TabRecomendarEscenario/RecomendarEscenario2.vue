<template>
  <div>
    <RecomendarLiberarEscenario />
  </div>
</template>

