<template>
  <div
    class="bg-white dark:bg-[#2e2e2e44] w-[312px] shadow-md rounded-md border border-ineAzul dark:border-ineRosa py-4 px-5 flex flex-col gap-2 relative"
  >
    <!-- Header -->
    <div class="flex items-center gap-3">
      <!-- Logo -->
      <div>
        <img class="w-12" :src="ImageSrc" >
      </div>
      <!-- Title -->
      <div>
        <h1 class="text-lg font-bold text-ineAzul dark:text-ineRosa">
          {{ props.escenario.alias }}
        </h1>
        <h2 class="text-inePurpura dark:text-ineRosa font-bold">
          {{ props.escenario.nstemporales }} secciones de trabajo
        </h2>
      </div>
    </div>

    <!-- Data Main -->
    <div class="w-full flex flex-col justify-between">
      <div
        v-for="item in getDataCards"
        :key="`informacion-${item.score}-${item.labelType}`"
        class="grid grid-cols-3 text-[12px] gap-3"
      >
        <div>
          <label>{{ item.labelPuntos }}</label>
        </div>
        <div>
          <label>{{ item.labelType }}</label>
        </div>
        <div class="text-end">
          {{ roundNumbers(item.score) }}
        </div>
      </div>
    </div>

    <!-- Footer -> Score -->
    <div
      class="flex justify-end items-center text-inePurpura dark:text-ineRosa font-bold"
    >
      {{ roundNumbers(props.escenario.calificacion) }}
    </div>

    <!-- Action Buttons -->
    <div
      class="w-full flex flex-col items-center gap-4 justify-center border-t pt-4 border-ineAzul dark:border-ineRosa"
    >
      <!-- Recomendar Escenario -->
      <UButton
        :icon="props.escenario.recomendado === 1 ? 'i-heroicons-check-circle' : 'i-heroicons-arrow-down-on-square-stack'"
        class="flex justify-center w-full"
        :label="props.escenario.seleccion_recomendado === 1 ? 'Escenario recomendado' : 'Recomendar escenario'"
        color="white"
        :disabled="props.escenario.recomendado === 1 ? true : false"
        :ui="{
          color: {
            white: {
              solid:
                'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
            },
          },
        }"
        @click="isOpen2 = true"
      />
      <!-- Liberar Escenario -->
      <UButton
        :icon="props.escenario.liberado === 1 ? 'i-heroicons-check-circle' : 'i-heroicons-arrow-down-on-square-stack'"
        class="flex justify-center w-full"
        :label="props.escenario.ganador === 1 ? 'Escenario liberado' : 'Liberar escenario'"
        color="white"
        :disabled="props.escenario.liberado === 1 || props.escenario.recomendado === 0 ? true : false"
        :ui="{
          color: {
            white: {
              solid:
                'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-[#80416b55] hover:text-inePurpura disabled:bg-[#80416b35] disabled:ring-ineRosa disabled:font-semibold disabled:text-inePurpura hover:ring-ineRosa dark:bg-inherit dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
            },
          },
        }"
        @click="isOpen3 = true"
      />
    </div>

    <!-- Escenario liberado -->
    <div v-if="props.escenario.ganador === 1 && props.escenario.liberado === 1" class="absolute top-2 right-2">
      <UIcon class="text-green-500" name="i-heroicons-check-circle text-[30px]" />
    </div>

    <!-- Modal para confirmar la recomendación del escenario -->
    <UModal
      v-model="isOpen2" 
      :ui="{
        container: 'flex min-h-full items-end sm:items-center justify-center text-center text-white',
        background: isDark ? 'modoOscuroMain' : 'bg-[#252756d2]',
        overlay: {
          base: 'fixed inset-0 transition-opacity',
          background: 'bg-gray-400/75 dark:bg-[#2e2e2e80]',
          transition: {
            enter: 'ease-out duration-300',
            enterFrom: 'opacity-0',
            enterTo: 'opacity-100',
            leave: 'ease-in duration-200',
            leaveFrom: 'opacity-100',
            leaveTo: 'opacity-0',
          },
        },
      }"
    >
      <div class="py-5">
        <h1 class="flex text-center items-center justify-center text-xl font-semibold dark:font-normal">¿Desea recomendar este escenario?</h1>
        <div class="mt-6 flex gap-4 items-center justify-center">
          <UButton  
            color="white" 
            label="Cancelar"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-sm shadow-sm ring-1 ring-inset ring-red-600 dark:ring-red-600 text-white dark:text-red-600 bg-red-600 hover:bg-red-700 hover:ring-red-700 dark:bg-inherit dark:hover:bg-gray-800/50 disabled:bg-red-600 dark:disabled:bg-inherit focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }" 
            @click="isOpen2 = false" />
          <UButton
            label="Guardar"  
            color="white"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-sm shadow-sm ring-1 ring-inset ring-green-600 dark:ring-green-600 text-white dark:text-green-600 bg-green-600 hover:bg-green-700 hover:ring-green-700 dark:bg-inherit dark:hover:bg-gray-800/50 disabled:bg-green-600 dark:disabled:bg-inherit focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }" 
            @click="setRecomendarEscenario"/>
        </div>
      </div>
    </UModal>

    <!-- Modal para confirmar la liberación del escenario -->
    <UModal
      v-model="isOpen3" 
      :ui="{
        container: 'flex min-h-full items-end sm:items-center justify-center text-center text-white',
        background: isDark ? 'modoOscuroMain' : 'bg-[#252756d2]',
        overlay: {
          base: 'fixed inset-0 transition-opacity',
          background: 'bg-gray-400/75 dark:bg-[#2e2e2e80]',
          transition: {
            enter: 'ease-out duration-300',
            enterFrom: 'opacity-0',
            enterTo: 'opacity-100',
            leave: 'ease-in duration-200',
            leaveFrom: 'opacity-100',
            leaveTo: 'opacity-0',
          },
        },
      }"
    >
      <div class="py-5">
        <h1 class="flex text-center items-center justify-center text-xl font-semibold dark:font-normal">¿Desea liberar este escenario?</h1>
        <div class="mt-6 flex gap-4 items-center justify-center">
          <UButton  
            color="white" 
            label="Cancelar"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-sm shadow-sm ring-1 ring-inset ring-red-600 dark:ring-red-600 text-white dark:text-red-600 bg-red-600 hover:bg-red-700 hover:ring-red-700 dark:bg-inherit dark:hover:bg-gray-800/50 disabled:bg-red-600 dark:disabled:bg-inherit focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }" 
            @click="isOpen3 = false" />
          <UButton
            label="Guardar"  
            color="white"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-sm shadow-sm ring-1 ring-inset ring-green-600 dark:ring-green-600 text-white dark:text-green-600 bg-green-600 hover:bg-green-700 hover:ring-green-700 dark:bg-inherit dark:hover:bg-gray-800/50 disabled:bg-green-600 dark:disabled:bg-inherit focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }"  
            @click="setLiberarEscenario"/>
        </div>
      </div>
    </UModal>
  </div>
</template>
  
<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/stores/sideBar';
import { roundNumbers } from '@/services/roundNumbers';

const { $notify } = useNuxtApp();
const storeSideBar = sideBarStore();
const { goverment, district, etapa, section } =
  storeToRefs(storeSideBar);
  
const props = defineProps({
  escenario: {
    required: true,
    type: Object,
  },
});

const propId = props.escenario.id;
const ImageSrc = `/_nuxt/assets/${props.escenario.Logo}`;  
const getDataCards = computed(() => {
  return [
    {
      labelPuntos: '(30pts)',
      labelType: 'Rango',
      score: roundNumbers(props.escenario.rango),
    },
    {
      labelPuntos: '(24pts)',
      labelType: 'Conformación',
      score: roundNumbers(props.escenario.conformacion),
    },
    {
      labelPuntos: '(22pts)',
      labelType: 'Vialidad',
      score: roundNumbers(props.escenario.vialidad),
    },
    {
      labelPuntos: '(24pts)',
      labelType: 'Sitio',
      score: roundNumbers(props.escenario.sitio),
    },
  ];
});

// Modal
const isOpen2 = ref(false);
const emit = defineEmits(['update:recomendar-escenario']);
const setRecomendarEscenario = async () => {
  try {
    const url = `http://localhost:3030/recomendarEscenario?id=${props.escenario.id}&etapa=${etapa.value}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}`;
    const response = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    if (response.recomendar && response.recomendar.exito === 1) {
      $notify({
        title: 'Recomendar escenario',
        text: 'El escenario fue recomendado con éxito',
        type: 'success',
      });
      // Emitir el evento de actualización
      emit('update:recomendar-escenario', props.escenario.id);
      imprimirFormato('ACUSE DE ESCENARIO RECOMENDADO');
    } else {
      throw new Error('Error en la recomendación del escenario');
    }
  } catch (error) {
    $notify({
      title: 'Recomendar escenario',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
    console.error('Error al recomendar el escenario:', error);
  } finally {
    isOpen2.value = false;
  }
};

const isOpen3 = ref(false);
const setLiberarEscenario = async () => {
  try {
    const url = `http://localhost:3030/liberarEscenario?id=${props.escenario.id}&etapa=${etapa.value}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}`;
    const response = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    if (response.liberar && response.liberar.exito === 1) {
      $notify({
        title: 'Liberar escenario',
        text: 'El escenario fue liberado con éxito',
        type: 'success',
      });
      emit('update:recomendar-escenario', props.escenario.id);
      imprimirFormato('ACUSE DE ESCENARIO LIBERADO');
    } else {
      throw new Error('Error en la liberación del escenario');
    }
  } catch (error) {
    $notify({
      title: 'Liberar escenario',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
    console.error('Error al liberar el escenario:', error);
  } finally{
    isOpen3.value = false;
  }
};

// *** Acuses PDF'S ***
const {
  imprimirFormato,
} = useEscenario(propId);

// DarkMode
const colorMode = useColorMode();
const isDark = computed({
  get () {
    return colorMode.value === 'dark';
  },
  set () {
    colorMode.preference = colorMode.value === 'dark' ? 'light' : 'dark';
  },
});
</script>
  
