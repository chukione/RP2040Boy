<template>
  <div>
    <!-- Alert -->
    <div :style="{ height: `${availableHeight}px` }" class="w-2/6 mx-auto flex justify-center items-center">
      <UAlert
        icon="i-heroicons-exclamation-triangle text-[35px]" title="No existen escenarios"
        :ui="{
          title: 'text-xl font-medium pb-1',
          description: 'text-lg leading-4 opacity-90',
          gap: 'gap-3',
          color: {
            white: {
              solid:
                'cursor-pointer text-xs shadow-sm ring-1 ring-inset ring-black dark:ring-yellow-100 text-slate-700 dark:text-yellow-100 bg-white dark:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-bg duration-700',
            },
          },
        }"  />

    </div>
  </div></template>

<script setup>

// *** Manejo de Stores ***
import { medidasStores } from '@/stores/medidasStores';

const storeMedidas = medidasStores();
const { dataAltoMain } = storeToRefs(storeMedidas);

// Le asigna el alto al mapa
const availableHeight = ref(null);
watchEffect(() => {
  availableHeight.value = dataAltoMain.value;
});
</script>
