<template>
  <div
    class="overflow-auto p-5 flex flex-col gap-2"
    :style="{ height: `${availableHeight}px`, width: `${availableWidth}px` }"
  >
    <!-- table -->
    <div
      class="border-[0.5px] shadow-md dark:border-ineRosa rounded-md py-2 px-4 bg-white dark:bg-[#2e2e2e44]"
    >
      <div>
        <!-- input buscay y botones de descarga -->
        <div
          class="flex justify-between py-3.5 border-b border-gray-300 dark:border-gray-500"
        >
          <div>
            <UInput
              v-model="search"
              icon="i-heroicons-magnifying-glass-20-solid"
              placeholder="Buscar..."
              :ui="{
                color: {
                  white: {
                    outline:
                      'shadow-sm bg-white dark:bg-transparent text-gray-900 dark:text-white ring-1 ring-inset dark:ring-inset focus:ring-2 focus:ring-inePurpura dark:focus:ring-ineRosa',
                  },
                },
              }"
            />
          </div>
          <div class="font-semibold text-[18px] dark:text-ineRosa text-ineAzul">
            <h1>Reporte comentarios</h1>
          </div>
          <div class="flex gap-2">
            <!-- <nuxt-link to="/console/reporteComentarios"> -->
            <nuxt-link to="/console/reporteEscenarios">
              <UTooltip text="Reporte Escenarios">
                <UButton
                  icon="i-heroicons-map"
                  color="white"
                  :ui="{
                    color: {
                      white: {
                        solid:
                          'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-ineRosa dark:bg-inherit dark:hover:bg-gray-700/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                      },
                    },
                  }"
                />
              </UTooltip>
            </nuxt-link>
            <!-- </nuxt-link> -->
            <UTooltip text="Copiar">
              <UButton
                icon="i-heroicons-clipboard-document"
                color="white"
                :ui="{
                  color: {
                    white: {
                      solid:
                        'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-ineRosa dark:bg-inherit dark:hover:bg-gray-700/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400',
                    },
                  },
                }"
                @click="copyTableData"
              />
            </UTooltip>
            <UTooltip text="Descargar CSV">
              <UButton
                :loading="visualizarLoader"
                icon="i-heroicons-arrow-down-on-square-stack"
                color="white"
                :ui="{
                  color: {
                    white: {
                      solid:
                        'text-xs shadow-sm ring-1 ring-inset ring-inePurpura dark:ring-ineRosa text-white dark:text-ineRosa bg-inePurpura hover:bg-ineRosa dark:bg-inherit dark:hover:bg-gray-700/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400',
                    },
                  },
                }"
                @click="descargarCSV"
              />
            </UTooltip>
          </div>
        </div>
        <!-- table -->
        <div>
          <UTable
            :rows="datosrep ? filteredRows : []"
            :columns="columns"
            :ui="{
              th: {
                base: 'text-center rtl:text-right',
                font: 'font-semibold',
              },
              tr: {
                base: 'text-center',
              },
            }"
          >
            <template
              #comentario-data="{ row }"
            >
              <div v-if="row.comentario" class="w-[300px] mx-auto text-wrap text-justify">
                {{ row.comentario }}
              </div>
            </template>
          </UTable>
        </div>
        <!-- paginación -->
        <div
          class="flex justify-between px-3 py-3.5 border-t-[0.5px] border-ineAzul dark:border-ineRosa "
        >
          <div>
            <span class="text-base text-ineAzul dark:text-ineRosa">
              Mostrando
              <span class="font-medium"> {{ pageFrom }} </span>
              a
              <span class="font-medium"> {{ pageTo }} </span>
              de
              <span class="font-medium"> {{ pageTotal }} </span>
              registros
            </span>
          </div>
          <div
            class="flex justify-end px-3 py-3.5 border-gray-200 dark:border-gray-700"
          >
            <UPagination
              v-model="page"
              :page-count="pageCount"
              :total="datosrep.length"
              :active-button="{ style: 'background-color: #80416b; color: white;' }"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { storeToRefs } from 'pinia';
import { ref, onMounted } from 'vue';
import { medidasStores } from '@/stores/medidasStores';

// Notify
const { $notify } = useNuxtApp();

// *** Manejo de Stores ***
const storeMedidas = medidasStores();
const { dataAltoMain, dataAncho } = storeToRefs(storeMedidas);

const availableHeight = ref(null);
const availableWidth = ref(null);
watchEffect(() => {
  availableHeight.value = dataAltoMain.value;
  availableWidth.value = dataAncho.value;
});

// *** Logica del DataTable ***
const page = ref(1);
const pageCount = 10;
const pageTotal = ref('');

const columns = [
  {
    key: 'entidad',
    label: 'Entidad',
    sortable: true,
  },
  {
    key: 'distrito',
    label: 'Distrito',
    sortable: true,
  },
  {
    key: 'seccion',
    label: 'Sección',
    sortable: true,
  },
  {
    key: 'alias',
    label: 'Alias',
    sortable: true,
  },
  {
    key: 'nombre_usuario',
    label: 'Nombre Usuario',
    sortable: true,
  },
  {
    key: 'tipo_usuario',
    label: 'Tipo Usuario',
    sortable: true,
  },
  {
    key: 'comentario',
    label: 'Comentario',
  },
  {
    key: 'fecha_format',
    label: 'Fecha',
    sortable: true,
  },
];

// Datos que pintan la tabla
const datosrep = ref([]);
const fetchReporte = async () => {
  try {
    const response = await fetch('http://localhost:3030/getReporteCom', {
      method: 'GET',
    });
    const data = await response.json();
    datosrep.value = data;
    page.value = 1;
    pageTotal.value = datosrep.value.length;
  } catch (error) {
    console.error(error);
  }
};

onMounted(fetchReporte);

// Funcionalidad para el buscador
const search = ref('');

const filteredRows = computed(() => {
  if (!search.value) {
    return datosrep.value.slice(
      (page.value - 1) * pageCount,
      page.value * pageCount,
    );
    // return people
  }

  return datosrep.value.filter((person) => {
    return Object.values(person).some((value) => {
      return String(value).toLowerCase().includes(search.value.toLowerCase());
    });
  });
});

const pageFrom = computed(() => (page.value - 1) * pageCount + 1);
const pageTo = computed(() =>
  Math.min(page.value * pageCount, pageTotal.value),
);

// Variable para mostrar el loader
const visualizarLoader = ref(false);

// Función para exportar la data a un archivo CSV
const descargarCSV = () => {
  try {
    visualizarLoader.value = true;

    let csvContent = 'data:text/csv;charset=utf-8,\uFEFF'; // Agregar el BOM (Byte Order Mark)

    // Obteniendo los encabezados de las columnas
    const headers = columns.map((column) =>
      column.label.normalize('NFD').replace(/[\u0300-\u036F]/g, ''),
    );
    csvContent += headers.join(',') + '\n';

    // Iterando sobre los datos para construir las filas del CSV
    datosrep.value.forEach((row) => {
      const values = columns.map((column) => {
        if (column.key === 'comentario') {
          // Encapsular el comentario entre comillas dobles
          return `"${row[column.key].replace(/"/g, '""')}"`;
        } else {
          return row[column.key];
        }
      });
      csvContent += values.join(',') + '\n';
    });

    // Crear un enlace de descarga y simular clic en él
    const encodedURI = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedURI);
    link.setAttribute('download', 'Reporte Comentarios.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Notificar al usuario sobre la descarga exitosa
    $notify({
      title: 'Reporte comentarios',
      text: 'Archivo descargado con éxito',
      type: 'success',
    });
  } catch (error) {
    $notify({
      title: 'Error!',
      text: 'Ocurrió un error al intentar descargar el archivo',
      type: 'danger',
    });
  } finally {
    visualizarLoader.value = false;
  }
};

// Función para copiar texto al portapapeles
function copyToClipboard(text) {
  // Crea un elemento de texto temporal
  const tempInput = document.createElement('textarea');
  tempInput.value = text;
  document.body.appendChild(tempInput);

  // Selecciona el texto dentro del elemento
  tempInput.select();

  // Copia el texto al portapapeles
  document.execCommand('copy');

  // Elimina el elemento temporal
  document.body.removeChild(tempInput);
}

const copyTableData = () => {
  try {
    // Obtiene los datos de la tabla
    const tableData = datosrep.value;

    // Formatea los datos para copiarlos al portapapeles
    const formattedData = tableData
      .map((row) => {
        return Object.keys(row).map((key) => {
          // Reemplaza saltos de línea dentro del campo de "comentario" con un espacio
          if (key === 'comentario' && typeof row[key] === 'string') {
            return row[key].replace(/[\r\n]+/g, ' ');
          }
          return row[key];
        }).join('\t'); // Utiliza tabulación como separador
      })
      .join('\n'); // Une todas las filas separadas por un salto de línea

    // Copia los datos al portapapeles
    copyToClipboard(formattedData);

    // Notifica al usuario que los datos han sido copiados
    $notify({
      title: 'Reporte comentarios',
      text: 'La información ha sido copiada con éxito',
      type: 'success',
    });
  } catch (error) {
    $notify({
      title: 'Error!',
      text: 'Ocurrio un error al intentar copiar los datos',
      type: 'danger',
    });
  }
};

</script>
