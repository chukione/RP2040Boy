<template>
  <div class="h-full w-[250px] flex flex-col border-r shadow-md dark:shadow-ineRosa dark:border-ineRosa">
    <!-- Selects -->
    <div class="px-5 flex flex-col gap-4 py-4">
      <!-- Etapa -->
      <div class="text-justify">
        <h1 class="font-bold mb-2">Etapa</h1>
        <USelect
          v-model="etapa_"
          :options="etapas"
          value-attribute="id"
          option-attribute="nombre"
          placeholder="Seleccionar etapa"
          :ui="{
            color: {
              white: {
                outline:
                  'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-500',
              },
            },
          }"
        />
      </div>
      <!-- Entidad -->
      <div class="text-justify">
        <h1 class="font-bold mb-2">Entidad</h1>
        <USelect
          v-model="goverment_"
          :options="goverments"
          value-attribute="id"
          option-attribute="name"
          placeholder="Seleccionar entidad"
          :disabled="goverments[0]?.name === 'Seleccionar entidad'"
          :ui="{
            color: {
              white: {
                outline:
                  'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-500',
              },
            },
          }"
        />
      </div>
      <!-- Distrito -->
      <div class="text-justify">
        <h1 class="font-bold mb-2">Distrito</h1>
        <USelect
          v-model="district_"
          :options="distritos"
          value-attribute="distrito"
          placeholder="Seleccionar distrito"
          :disabled="distritos[0]?.distrito === 'Seleccionar distrito'"
          :ui="{
            color: {
              white: {
                outline:
                  'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-500',
              },
            },
          }"
        />
      </div>
      <!-- Seccion -->
      <div class="text-justify">
        <h1 class="font-bold mb-2">Seccion</h1>
        <USelect
          v-model="section_"
          :options="seccions"
          value-attribute="Seccion"
          placeholder="Seleccionar sección"
          :disabled="seccions[0]?.Seccion === 'Seleccionar sección'"
          :ui="{
            color: {
              white: {
                outline:
                  'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-pink-500 dark:focus:ring-pink-500',
              },
            },
          }"
        />
      </div>
    </div>
    <!-- Menú -->
    <div v-show="showMenu">
      <UVerticalNavigation
        class="py-2"
        :links="links"
        :ui="{
          base: 'px-5 py-2',
        }"
      />
    </div>
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/stores/sideBar';

// *** Mostrar / Ocultar Menu ***
const showMenu = ref(false);

// *** Logica Menú ***
// const route = useRoute();

const links = [
  [
    {
      label: 'Crear/Editar Escenario',
      icon: 'i-heroicons-plus-circle',
      to: '/console/crearEscenarios',
    },
    {
      label: 'Ver Escenarios',
      icon: 'i-heroicons-eye',
      to: '/console/verEscenarios',
    },
    {
      label: 'Validar y Guardar',
      icon: 'i-heroicons-check-circle',
      to: '/console/validarGuardar',
    },
    {
      label: 'Recomendar/Liberar',
      icon: 'i-heroicons-star',
      to: '/console/recomendarEscenario',
    },
    {
      label: 'Copiar Escenarios',
      icon: 'i-heroicons-document-duplicate',
      to: '/console/copiarEscenarios',
    },
    {
      label: 'Reportes',
      icon: 'i-heroicons-clipboard-document-list',
      to: '/console/reporteEscenarios',
    },
  ],
];

const route = useRoute();
const router = useRouter(); // Importa el router
// Usando route.fullPath para detectar cambios en la ruta
watch(
  () => route.fullPath,
  (newPath) => {
    // console.log('La ruta ha cambiado a:', newPath);
    storeSideBar.setSelectedMenuOption(newPath);
  },
);
// *** Termina Logica Menú ***

// *** Logica Selects ***
const { $notify } = useNuxtApp();
const storeSideBar = sideBarStore();
const { goverment, district, etapa, section, selectedMenuOption, routeLocationKey } =
  storeToRefs(storeSideBar);

// **** DATA ****
// Etapas
const etapa_ = ref('');
const etapas = ref([]);
const getEtapas = async () => {
  try {
    const url = 'http://localhost:3030/etapas';
    etapas.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Etapas',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

onMounted(async () => {
  await getEtapas();
  if (etapa.value > 0) {
    etapa_.value = etapa.value;
    await getGoverments();
  }
  if (goverment.value > 0) {
    goverment_.value = goverment.value;
    await getDistritos();
  }
  if (district.value > 0) {
    district_.value = district.value;
    await getSecciones();
  }
  if (section.value > 0) {
    section_.value = section.value;
    showMenu.value = true;
  }
  if (selectedMenuOption.value) {
    changeSection();
    router.push(selectedMenuOption.value);
  }
  setTimeout(()=> {
    storeSideBar.setRouteLocationKey(selectedMenuOption.value);
  }, 500);
});

// Entidad
const goverments = ref([{ id: 0, name: 'Seleccionar entidad' }]);
const goverment_ = ref('');
const getGoverments = async () => {
  goverments.value = await storeSideBar.getGoverments();
};

watch(etapa_, async () => {
  if (etapa_.value > 0) {
    showMenu.value = false;
    storeSideBar.setEtapa(Number(etapa_.value));
    goverments.value = [];
    goverment_.value = '';
    distritos.value = [{ distrito: 'Seleccionar distrito' }];
    district_.value = '';
    seccions.value = [{ Seccion: 'Seleccionar sección' }];
    section_.value = '';
    await getGoverments();
    if(routeLocationKey.value !== '/console/verEscenario' || routeLocationKey.value !== '/console/editarEscenarios'){
      router.push('/console');
    }
  }
});

// Distrito
const district_ = ref('');
const distritos = ref([{ distrito: 'Seleccionar distrito' }]);
const getDistritos = async () => {
  try {
    section_.value = '';
    const url = `http://localhost:3030/getDistritos/${goverment_.value}`;
    distritos.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Distritos',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

watch((etapa_, goverment_), async () => {
  if (etapa_.value > 0 && goverment_.value > 0) {
    showMenu.value = false;
    storeSideBar.setGoverment(Number(goverment_.value));
    distritos.value = [];
    district_.value = '';
    seccions.value = [{ Seccion: 'Seleccionar sección' }];
    section_.value = '';
    await getDistritos();
    if(routeLocationKey.value !== '/console/verEscenario' && routeLocationKey.value !== '/console/editarEscenarios'){
      router.push('/console');
    }
    // router.push('/console');
  }
});

// Sección
const section_ = ref('');
const seccions = ref([{ Seccion: 'Seleccionar sección' }]);
const getSecciones = async () => {
  try {
    const url = `http://localhost:3030/getSecciones?entidad=${goverment_.value}&distrito=${district_.value}`;
    seccions.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Secciones',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

watch((etapa_, goverment_, district_), async () => {
  if (etapa_.value > 0 && goverment_.value > 0 && district_.value > 0) {
    showMenu.value = false;
    storeSideBar.setDistrict(district_.value);
    section_.value = '';
    await getSecciones();
    if(routeLocationKey.value !== '/console/verEscenario' && routeLocationKey.value !== '/console/editarEscenarios'){
      router.push('/console');
    }
    // router.push('/console');
  }
});

const changeSection = () => {
  storeSideBar.setSection(Number(section_.value));
  getCreateEditScenario();
  getEscenarios();
  getAprobarEscenario();
  getDataLiberarEscenario();
  // storeSideBar.setRouteLocationKey(selectedMenuOption.value);
};

watch(section_, () => {
  if (section_.value > 0) {
    showMenu.value = true;
    changeSection();
    if(routeLocationKey.value !== '/console/verEscenario' && routeLocationKey.value !== '/console/editarEscenarios'){
      router.push('/console');
    }
    // router.push('/console');
  }
});

const clearEscenarios = () => {
  storeSideBar.setEscenarios([]);
  storeSideBar.setCreateScenarios([]);
  storeSideBar.setEscenariosAprobar([]);
  storeSideBar.setLiberarEscenario([]);
};

// Trae la información de la pestaña Crear/Editar Escenario
const escenariosCreated = ref([]);
const getCreateEditScenario = async () => {
  // - clear escenarios
  clearEscenarios();
  try {
    const url = `http://localhost:3030/getCrearEscenarios?etapa=${etapa_.value}&entidad=${goverment_.value}&distrito=${district_.value}&seccion=${section_.value}&typeUser=ADMINISTRADOR&userName=juan.perez`;
    escenariosCreated.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    if (escenariosCreated.value && escenariosCreated.value.length > 0) {
      for (const index in escenariosCreated.value) {
        const alias = escenariosCreated.value[index].alias;
        const urlAlias = `http://localhost:3030/getLogo?alias=${alias}`;
        const routeImage = await $fetch(urlAlias, {
          headers: {
            Accept: 'application/json, text/plain, */*',
          },
          method: 'GET',
        });
        escenariosCreated.value[index].logo = routeImage[0].Logo;
      }
      storeSideBar.setCreateScenarios(escenariosCreated.value);
    }
  } catch (error) {
    $notify({
      title: 'Editar escenarios',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

// Trae la información de la pestaña Ver Escenarios
const escenariosBefore = ref([]);
const getEscenarios = async () => {
  // - clear escenarios
  clearEscenarios();
  try {
    const url = `http://localhost:3030/getDataMain?etapa=${etapa_.value}&entidad=${goverment_.value}&distrito=${district_.value}&seccion=${section_.value}&typeUser=MORENA-CDV`;
    escenariosBefore.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    if (escenariosBefore.value && escenariosBefore.value.length > 0) {
      for (const index in escenariosBefore.value) {
        const alias = escenariosBefore.value[index].Alias;
        const urlAlias = `http://localhost:3030/getLogo?alias=${alias}`;
        const routeImage = await $fetch(urlAlias, {
          headers: {
            Accept: 'application/json, text/plain, */*',
          },
          method: 'GET',
        });
        escenariosBefore.value[index].Logo = routeImage[0].Logo;
      }
      storeSideBar.setEscenarios(escenariosBefore.value);
    }
  } catch (error) {
    $notify({
      title: 'Escenarios',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

// Trae la información de la pestaña Validar y Guardar
const AprobarescenariosBefore = ref([]);
const getAprobarEscenario = async () => {
  // - clear escenarios
  clearEscenarios();
  try {
    const url = `http://localhost:3030/getAprobarEscenario?et=${etapa_.value}&e=${goverment_.value}&d=${district_.value}&s=${section_.value}&typeUser=MORENA-CDV`;
    AprobarescenariosBefore.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    if (AprobarescenariosBefore.value && AprobarescenariosBefore.value.length > 0) {
      for (const index in AprobarescenariosBefore.value) {
        const alias = AprobarescenariosBefore.value[index].Alias;
        const urlAlias = `http://localhost:3030/getLogo?alias=${alias}`;
        const routeImage = await $fetch(urlAlias, {
          headers: {
            Accept: 'application/json, text/plain, */*',
          },
          method: 'GET',
        });
        AprobarescenariosBefore.value[index].Logo = routeImage[0].Logo;
      }
      storeSideBar.setEscenariosAprobar(AprobarescenariosBefore.value);
    }
  } catch (error) {
    $notify({
      title: 'Aprobar Escenarios',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

// Trae la info de Liberar escenario
const dataLiberarEscenario = ref([]);
const getDataLiberarEscenario = async () => {
  // - clear escenarios
  clearEscenarios();
  try {
    const url = `http://localhost:3030/getLiberarEscenario?etapa=${etapa_.value}&entidad=${goverment_.value}&distrito=${district_.value}&seccion=${section_.value}&typeUser=MORENA-CDV`;
    dataLiberarEscenario.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });

    if (dataLiberarEscenario.value && dataLiberarEscenario.value.propuestas && dataLiberarEscenario.value.propuestas.length > 0) {
      for (const index in dataLiberarEscenario.value.propuestas) {
        const alias = dataLiberarEscenario.value.propuestas[index].alias;
        const urlAlias = `http://localhost:3030/getLogo?alias=${alias}`;
        const routeImage = await $fetch(urlAlias, {
          headers: {
            Accept: 'application/json, text/plain, */*',
          },
          method: 'GET',
        });
        dataLiberarEscenario.value.propuestas[index].Logo = routeImage[0].Logo;
      }
      storeSideBar.setLiberarEscenario(dataLiberarEscenario.value.propuestas);
    }
  } catch (error) {
    $notify({
      title: 'Liberar Escenarios',
      text: 'Ocurrió un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};

</script>
