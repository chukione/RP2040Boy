<template>
  <div>
    <div class="mt-1">
      <label>
        <b>Acuses de referencia del escenario</b>
      </label>
      <div class="flex justify-between my-4 select-none text-xs">
        <button
          class="inline-block py-2 px-4 border bg-transparent text-navBar border-navBar hover:bg-navBar hover:text-white rounded-md"
        >
          <span class="mr-2">
            <IconComponent :icon="['fas', 'file-invoice']" />
          </span>
          Guardado
        </button>
        <button
          class="inline-block py-2 px-4 border bg-transparent text-navBar border-navBar hover:bg-navBar hover:text-white rounded-md"
        >
          <IconComponent :icon="['fas', 'file-contract']" />
          Liberado
        </button>
        <button
          class="inline-block py-2 px-4 border bg-transparent text-navBar border-navBar hover:bg-navBar hover:text-white rounded-md"
        >
          <IconComponent :icon="['fas', 'file-lines']" />
          Recomendado
        </button>
      </div>
    </div>
    <div class="mt-8">
      <label>
        <b>Tablas de datos del escenario</b>
      </label>
      <div class="flex justify-between my-4 select-none text-xs">
        <button
          class="inline-block mr-4 py-2 px-4 border bg-transparent text-navBar border-navBar hover:bg-navBar hover:text-white rounded-md"
        >
          <download-csv
            :data="dataGeneral"
            :name="'Descarga Secciones de Trabajo'"
          >
            <IconComponent :icon="['fas', 'table']" />
            Secciones de trabajo
          </download-csv>
        </button>
        <button
          class="inline-block mr-4 py-2 px-4 border bg-transparent text-navBar border-navBar hover:bg-navBar hover:text-white rounded-md"
        >
          <IconComponent :icon="['fas', 'table-cells']" />
          Evaluaciones del escenario
        </button>
        <button
          class="inline-block py-2 px-4 border bg-transparent text-navBar border-navBar hover:bg-navBar hover:text-white rounded-md"
        >
          <download-csv :data="dataDiceDebeImp" :name="'Descarga DICE/DEBE'">
            <IconComponent :icon="['fas', 'table-list']" />
            DICE/DEBE
          </download-csv>
        </button>
      </div>
    </div>
    <div class="mt-8">
      <label>
        <b>Información espacial del escenario</b>
      </label>
      <div class="flex my-4 select-none text-xs">
        <button
          class="inline-block mr-4 py-2 px-4 border bg-transparent text-navBar border-navBar hover:bg-navBar hover:text-white rounded-md"
        >
          <IconComponent :icon="['fas', 'star']" />
          Escenario
        </button>
        <button
          class="inline-block py-2 px-4 border bg-transparent text-navBar border-navBar hover:bg-navBar hover:text-white rounded-md"
        >
          <IconComponent :icon="['fas', 'puzzle-piece']" />
          Evaluaciones del escenario
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from './../stores/sideBar';
const storeSideBar = sideBarStore();
const { goverment, district, section, escenarioEdit } =
  storeToRefs(storeSideBar);
const dataGeneral = ref([]);
const dataDiceDebe = ref([]);
const dataDiceDebeImp = ref([]);

onMounted(async () => {
  const id = escenarioEdit.value.id;
  // editarEscenarios
  const url = `http://localhost:3030/Get-info-escenario?id_esc=${id}&e=${goverment.value}&d=${district.value}&s=${section.value}`;
  try {
    dataGeneral.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    console.error(error);
  }
  await DescargaDiceDebe();
});

const DescargaDiceDebe = async () => {
  const id = escenarioEdit.value.id;
  // dice debe
  const url = `http://localhost:3030/descargaDiceDebe?id_esc=${id}&e=${goverment.value}&d=${district.value}&s=${section.value}`;
  try {
    dataDiceDebe.value = ref(
      await $fetch(url, {
        headers: {
          Accept: 'application/json, text/plain, */*',
        },
        method: 'GET',
      }),
    );
    let newData = [];
    for (const key in dataDiceDebe.value._rawValue._rawValue.st) {
      if (dataDiceDebe.value._rawValue._rawValue.st.hasOwnProperty(key)) {
        const elemento = dataDiceDebe.value._rawValue._rawValue.st[key].datos;
        newData = newData.concat(elemento);
      }
    }
    dataDiceDebeImp.value = newData;
  } catch (error) {
    console.error(error);
  }
};
</script>
