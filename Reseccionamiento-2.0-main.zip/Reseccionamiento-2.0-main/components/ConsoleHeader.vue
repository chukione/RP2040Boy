<template>
  <header class="bg-navBar">
    <nav class="text-white px-5 py-3">
      <div class="flex justify-between items-center">
        <div>
          <img src="@/assets/img/INE_blanco.png" class="w-24" alt="Instituto Nacional Electoral">
        </div>
        <div class="hidden lg:flex lg:w-auto lg:order-1">
          Reseccionamiento 2023
        </div>
        <div class="lg:flex lg:w-auto lg:order-2 text-sm">
          <span class="float-left mr-2">
            <span class="mr-1">
              <IconComponent :icon="['fas', 'user']" />
            </span>
            {{ 'JUAN L' }}
          </span>
          <span class="float-left mr-2">|</span>
          <button class="floar-right">
            <span class="mr-0">
              <IconComponent :icon="['fas', 'right-from-bracket']" />
            </span>
            Cerrar Sesión
          </button>
        </div>
      </div>
    </nav>
  </header>
</template>

<script setup>

</script>
