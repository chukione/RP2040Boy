<template>
  <!-- <div class="bg-white shadow-md sm:rounded-lg border border-gray-200"> -->
  <div class="bg-white dark:bg-transparent shadow-md sm:rounded-lg border border-gray-200">
    <!-- header -->
    <div class="w-full flex flex-row mb-5 mt-3 px-6">
      <div>
        <img class=" w-12" :src="ImageSrc">
      </div>
      <div class="ml-3">
        <div>
          <label class="text-lg font-bold">{{ props.escenario.Alias }}</label>
        </div>
        <div>
          <label class="text-labelsStats font-bold">{{ `${props.escenario.Nstemporales} secciones de trabajo` }}</label>
        </div>
      </div>
    </div>
    <!-- /header -->
    <!-- Data -->
    <div
      v-for="item in getDataCards"
      :key="`informacion-${item.score}-${item.labelType}`"
      class="grid grid-cols-2 px-6"
    >
      <div class="col-span-1 text-xs flex flex-row">
        <label>{{ item.labelPuntos }}</label>
        <label class="ml-12">{{ item.labelType }}</label>
      </div>
      <div class="col-span-1 text-xs ml-16">
        {{ item.score }}
      </div>
    </div>
    <!-- Score -->
    <div class="flex justify-end items-center text-labelsStats font-bold mb-4 mt-2 px-2">
      {{ roundNumbers(props.escenario.Calificacion) }}
    </div>
    <!-- Button -->
    <div class="w-full flex items-center justify-end mb-3 border-t border-gray-200">
      <button
        class="mt-3 mr-3 py-2 px-4 border border-transparent text-sm font-bold rounded-md text-white bg-green-600 shadow-sm hover:bg-green-500 focus:outline-none focus:shadow-outline-green focus:bg-green-500 active:bg-green-600 transition duration-150 ease-in-out"
        @click="showEscenario()"
      >
        Ver mapa
      </button>
    </div>
  </div>
</template>

<script setup>
import { sideBarStore } from './../stores/sideBar';
import { roundNumbers } from './../services/roundNumbers';
const storeSideBar = sideBarStore();
const props = defineProps({
  escenario: {
    required: true,
    type: Object,
  },
});
const ImageSrc = `/_nuxt/assets/${props.escenario.Logo}`;
const getDataCards = computed(() => {
  const data = [];
  data.push({ labelPuntos: '(30pts)', labelType: 'Rango', score: roundNumbers(props.escenario.Rango) });
  data.push({ labelPuntos: '(24pts)', labelType: 'Conformación', score: roundNumbers(props.escenario.Conformacion) });
  data.push({ labelPuntos: '(22pts)', labelType: 'Vialidad', score: roundNumbers(props.escenario.Vialidad) });
  data.push({ labelPuntos: '(24pts)', labelType: 'Sitio', score: roundNumbers(props.escenario.Sitio) });
  return data;
});
const showEscenario = () => {
  storeSideBar.setEscenarioVer(props.escenario);
  navigateTo('/console/verEscenario');
};
</script>
