<template>
  <div class="w-full">
    <div
      class="flex bg-yellow-100 bg-opacity-50 rounded-lg p-4 mb-4 text-sm text-yellow-700"
      role="alert"
    >
      <svg
        class="w-5 h-5 inline mr-3"
        fill="currentColor"
        viewBox="0 0 20 20"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          fill-rule="evenodd"
          d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
          clip-rule="evenodd"
        />
      </svg>
      <div>
        <span class="font-medium">Información!</span> El escenario tiene un
        total de 5 secciones de , las localidades que estan dentro de la sección
        son:
      </div>
    </div>
    <div
      class="mx-auto h-full flex flex-col max-w-3xl items-center justify-center bg-white rounded-xl p-4"
    >
      <button
        class="inline-block px-4 py-3 bg-fuchsia-100 text-black rounded-lg"
        @click="clearST()"
      >
        <IconComponent :icon="['fas', 'trash']" />
        Limpiar sección de trabajo
      </button>
      <label
        for="seccion"
        class="mt-4 block mb-1 text-md font-medium dark:text-white text-left "
      >Sección de trabajo</label
      >
      <select
        id="seccion"
        v-model="st_"
        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2"
        @change="changeST()"
      >
        <option v-for="st in optionsSt" :key="`st-${st.id}`" :value="st.id">
          {{ st.numero }}
        </option>
      </select>
    </div>
    <!-- <div class="flex flex-col"> -->
    <div class="flex justify-center mt-14 text-sm">
      <!-- Mueve los seleccionados del primer select al segundo -->
      <!-- <button
          id="add"
          type="button"
          class="inline-block px-4 py-3 bg-green-100 text-black rounded-lg"
          @click="agregarManzanas()"
        >
          Añadir manzanas
        </button> -->
      <div class="mx-2">
        <button
          id="add"
          type="button"
          class="px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700"
          @click="agregarManzanas()"
        >
          <span class="mr-1">
            <IconComponent :icon="['fas', 'fa-plus']" />
          </span>
          Añadir manzanas
        </button>
      </div>
  
      <!-- Mueve los seccionados del segundo select al primero -->
      <div class="mx-2">
        <button
          id="remove"
          type="button"
          class="px-4 py-2 rounded-md bg-red-600 text-white hover:bg-red-700"
          @click="deleteST()"
        >
          <span class="mr-1">
            <IconComponent :icon="['fas', 'trash']" />
          </span>
          Quitar manzanas
        </button>
      </div>
    </div>
    <div>
      <!-- <div class="justify-center my-8 select-none flex">
          <button
            class="hover:bg-pink-600 hover:text-white uppercase w-full text-center text-base text-pink-600 font-bold border border-pink-600 rounded-md"
            @click="returnPage()"
          >
            <IconComponent :icon="['fas', 'home']" />
            Regresar
          </button>
        </div> -->
      <div class="flex justify-center mt-16  ">
        <button
          class="text-sm font-semibold border rounded-sm p-1 bg-navBar text-white uppercase w-full text-center hover:text-navBar hover:bg-transparent border-navBar"
          @click="returnPage()"
        >
          <span class="mr-2">
            <IconComponent :icon="['fas', 'fa-house-chimney']" />
          </span>
          Regresar
        </button>
      </div>
    </div>
  </div>
</template>
  
<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from './../stores/sideBar';
const storeSideBar = sideBarStore();
const { escenarioEdit, selectedFeatures, st, goverment, district, section } =
    storeToRefs(storeSideBar);
const { $notify } = useNuxtApp();
const seccionesList = ref([]);
const emit = defineEmits(['updatedata']);
  
const returnPage = () => {
  navigateTo('/console/crearEscenarios');
};
  
onMounted(async () => {
  if (escenarioEdit.value) {
    await getSecciones();
  }
});
  
const st_ = ref(0);
const optionsSt = computed(() => {
  const data = [{ id: 0, numero: 'Selecciona una sección' }];
  if (seccionesList.value.length === 0) {
    return data;
  }
  for (const item of seccionesList.value) {
    data.push({ id: item.id, numero: `sección ${item.numero}` });
  }
  return data;
});
const getSecciones = async () => {
  try {
    const id = escenarioEdit.value.id;
    const url = `http://localhost:3030/getStrabajo?id=${id}`;
    seccionesList.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'ST',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
const changeST = () => {
  storeSideBar.setST(st_.value);
};
  
const agregarManzanas = async () => {
  const manzanas = String(selectedFeatures.value);
  try {
    const id = escenarioEdit.value.id;
    const url = `http://localhost:3030/update-mzn-st?idEscenario=${id}&idSt=${st.value}&manzanasEntrada=${manzanas}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&tipoActualizacion=agregar`;
    console.log(url);
    // seccionesList.value =
    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    console.log('cambie bandera: setBanderaRePaint ');
    storeSideBar.setBanderaRePaint(true);
    // Aqui va el modal ***********
    evaluaST();
    evaluaEscenario();
    emit('updatedata');
    // ******************
  } catch (error) {
    $notify({
      title: 'actualizar Manzanas',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
  
const evaluaST = async () => {
  // const evaluaSTprueba = [
  //   {
  //     st: 1,
  //     rango: 9.95448888888889,
  //     conformacion: 6.350622037478119,
  //     vialidad: 0,
  //     sitio: 0,
  //   },
  //   {
  //     st: 2,
  //     rango: 8.264632888888888,
  //     conformacion: 9.251298641177016,
  //     vialidad: 0,
  //     sitio: 0,
  //   },
  // ];
  
  try {
    const id = escenarioEdit.value.id;
    // const url = `http://localhost:3030/evaluaSt?id=${id}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}`;
    const url = `http://localhost:3030/evaluaSt?id=${id}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}`;
    console.log(url);
    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  
    // return evaluaSTprueba;
  } catch (error) {
    $notify({
      title: 'Evaluar Secciones de Trabajo',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
  
const clearST = async () => {
  try {
    const url = `http://localhost:3030/clear-secmanzanas?id_st=${st_.value}`;
    console.log(url);
    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    storeSideBar.setBanderaRePaint(true);
    evaluaST();
    evaluaEscenario();
    emit('updatedata');
  } catch (error) {
    $notify({
      title: 'Limpiar Secciones de Trabajo',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
  
const deleteST = async () => {
  const id = escenarioEdit.value.id;
  const manzanas = String(selectedFeatures.value);
  try {
    const url = `http://localhost:3030/update-mzn-st?idEscenario=${id}&idSt=${st_.value}&manzanasEntrada=${manzanas}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&tipoActualizacion=borrar`;
    console.log(url);
    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    storeSideBar.setBanderaRePaint(true);
    evaluaST();
    evaluaEscenario();
    emit('updatedata');
  } catch (error) {
    $notify({
      title: 'Eliminar Secciones de Trabajo',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
  
const evaluaEscenario = async () => {
  const id = escenarioEdit.value.id;
  try {
    const url = `http://localhost:3030/evaluarEscenario?id_esc=${id}`;
    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Evalua escenario',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
    console.error(error);
  }
};
</script>
  
