<script setup>
import { Map, NavigationControl } from 'maplibre-gl';
import * as turf from '@turf/turf';
import { storeToRefs } from 'pinia';
import { sideBarStore } from './../stores/sideBar';
const storeSideBar = sideBarStore();
const { goverment, district, section, escenarioEdit, banderaRePaint } =
  storeToRefs(storeSideBar);

const hoveredPolygon = ref(null);
const listo = ref(false);
const in3d = ref(false);
// let banderaDatos = ref(false);

const layer = computed(() => {
  const barraColores = usePaletaColores();
  const barraColores3D = usePaletaColores3D();
  if (in3d.value) {
    return {
      id: 'manzanas',
      type: 'fill-extrusion',
      source: 'geojson',
      paint: {
        'fill-extrusion-color': barraColores3D,
        'fill-extrusion-height': ['get', 'height'],
        'fill-extrusion-base': ['get', 'base_height'],
        'fill-extrusion-opacity': 1,
      },
    };
  } else {
    return {
      id: 'manzanas',
      type: 'fill',
      source: 'geojson',
      paint: {
        'fill-color': barraColores,
      },
    };
  }
});

const layerOutline = computed(() => {
  if (in3d.value) {
    return {
      id: 'outline',
      type: 'line',
      source: 'geojson',
      layout: {},
      paint: {
        'line-color': [
          'case',
          ['boolean', ['feature-state', 'hover'], false],
          '#242C89',
          '#000',
        ],
        'line-width': [
          'case',
          ['boolean', ['feature-state', 'hover'], false],
          5,
          1,
        ],
        'line-opacity': 0,
      },
      visible: false,
    };
  } else {
    return {
      id: 'outline',
      type: 'line',
      source: 'geojson',
      layout: {},
      paint: {
        'line-color': [
          'case',
          ['boolean', ['feature-state', 'hover'], false],
          '#242C89',
          '#333',
        ],
        'line-width': [
          'case',
          ['boolean', ['feature-state', 'hover'], false],
          5,
          2,
        ],
      },
    };
  }
});

const layerPerimeter = {
  id: 'perimeter',
  type: 'line',
  source: 'perimeter',
  layout: {},
  paint: {
    'line-color': '#000',
    'line-width': 10,
  },
};

const geojson = ref(null);
const perimeterGeoJSON = ref(null);
let selectedFeatures = []; // arreglo para guardar los IDs de los polígonos seleccionados

const mensajeInfo = computed(() => {
  return { tipo: 'Entidad', texto: 'Sitúate sobre una manzana' };
});

const mapContainer = ref(null);
const map = ref(null);
const features = ref(null);

const fitBounds = () => {
  map.value.fitBounds(turf.bbox(geojson.value), { duration: 0 });
  map.value.setPitch(0);
};

const rePaintMap = () => {
  console.log('Entro al rePaintMap');
  map.value.addSource('geojson', {
    type: 'geojson',
    data: geojson.value,
  });

  map.value.addSource('perimeter', {
    type: 'geojson',
    data: perimeterGeoJSON.value,
  });
  //capa vialidad
  map.value.addSource('route', {
    type: 'geojson',
    data: VialidadGeoJSON.value,
    generateId: true,
  });

  /* Agrega las vialidades */

  console.log('Afuera**************', VialidadGeoJSON.value.features);
  map.value.addLayer(layerPerimeter);
  map.value.addLayer(layer.value);
  map.value.addLayer(layerOutline.value);
  if (VialidadGeoJSON.value.features !== null) {
    console.log('Entro**************', VialidadGeoJSON.value.features);
    let style = null;
    if (VialidadGeoJSON.value.features[0].properties.categoria === 1) {
      style = {
        'line-color': '#ff462e',
        'line-width': 4,
        'line-opacity': 1,
        'line-dasharray': [2, 2],
      };
    }
    if (VialidadGeoJSON.value.features[0].properties.categoria === 5) {
      style = {
        'line-color': '#8c00ff',
        'line-width': 4,
        'line-opacity': 1,
      };
    }
    if (VialidadGeoJSON.value.features[0].properties.categoria === 6) {
      style = {
        'line-color': '#ff462e',
        'line-width': 4,
        'line-opacity': 1,
      };
    }
    map.value.addLayer({
      id: 'route',
      type: 'line',
      source: 'route',
      layout: {
        'line-join': 'round',
        'line-cap': 'round',
      },
      paint: style,
    });
  }

  //separamos los diferentes iconos
  const escuelas = {
    type: 'FeatureCollection',
    features: [],
  };
  const casillas = {
    type: 'FeatureCollection',
    features: [],
  };

  for (const item of SitioGeoJSON.value.features) {
    if (item.properties.tipo == 1) escuelas.features.push(item);
    if (item.properties.tipo != 1 && item.properties.tipo != null)
      casillas.features.push(item);
  }

  //capas icons markets
  map.value.loadImage('/_nuxt/assets/img/m5.png', function (error, image) {
    if (error) throw error;
    map.value.addImage('custom-marker', image);
    // Add a GeoJSON source
    map.value.addSource('escuelas', {
      type: 'geojson',
      data: escuelas,
      generateId: true,
    });

    // Add a symbol layer
    map.value.addLayer({
      id: 'escuelas',
      type: 'symbol',
      source: 'escuelas',
      layout: {
        'icon-image': 'custom-marker',
      },
    });
  });

  map.value.loadImage('/_nuxt/assets/img/c6.png', function (error, image) {
    if (error) throw error;
    map.value.addImage('custom-casilla', image);
    // Add a GeoJSON source
    map.value.addSource('casillas', {
      type: 'geojson',
      data: casillas,
      generateId: true,
    });

    // Add a symbol layer
    map.value.addLayer({
      id: 'casillas',
      type: 'symbol',
      source: 'casillas',
      layout: {
        'icon-image': 'custom-casilla',
      },
    });
  });

  fitBounds();
  map.value.on('mousemove', 'manzanas', function (e) {
    features.value = map.value.queryRenderedFeatures(e.point)[0];
    if (features.value) {
      if (hoveredPolygon.value) {
        map.value.setFeatureState(
          { source: 'geojson', id: hoveredPolygon.value },
          { hover: false },
        );
      }
      hoveredPolygon.value = features.value.id;

      map.value.setFeatureState(
        { source: 'geojson', id: hoveredPolygon.value },
        { hover: true },
      );
    }
  });
  map.value.on('mouseleave', 'manzanas', function () {
    if (hoveredPolygon.value) {
      map.value.setFeatureState(
        { source: 'geojson', id: hoveredPolygon.value },
        { hover: false },
      );
    }
    hoveredPolygon.value = null;
  });

  // adición de un "click listener" a la capa llamada "manzanas"
  map.value.on('click', 'manzanas', function (e) {
    const clickedFeatureId = e.features[0].id;

    // una variable que nos indica si el polígono ha sido seleccionado previamente
    const isSelected = map.value.getFeatureState({
      source: 'geojson',
      id: clickedFeatureId,
    }).selected;

    if (isSelected) {
      // quitar el polígono del arreglo de seleccionados
      const index = selectedFeatures.indexOf(clickedFeatureId);
      if (index > -1) {
        selectedFeatures.splice(index, 1);
      }

      // cambia el estado del polígono
      map.value.setFeatureState(
        { source: 'geojson', id: clickedFeatureId },
        { selected: false },
      );

      const barraColoresSelected = usePaletaColoresSelected(selectedFeatures);
      // cambio de color a color original
      map.value.setPaintProperty(
        'manzanas',
        'fill-color',
        barraColoresSelected,
      );
    } else {
      // agregar el ID del polígono seleccionado al arreglo de seleccionados
      selectedFeatures.push(clickedFeatureId);
      const barraColoresSelected = usePaletaColoresSelected(selectedFeatures);
      // cambia el estado del polígono
      map.value.setFeatureState(
        { source: 'geojson', id: clickedFeatureId },
        { selected: true },
      );
      map.value.setPaintProperty(
        'manzanas',
        'fill-color',
        barraColoresSelected,
      );
    }
    console.log('Esta es la lista que llevas:  ' + selectedFeatures);
    storeSideBar.setIdsMzn(selectedFeatures);
  });
  // Cambia el valor de la bandera para que se pueda repintar cuando se agrega ST
  storeSideBar.setBanderaRePaint(false);
};

const fetchGeoMzn = async () => {
  try {
    const url = `http://localhost:3030/getCartografia/${goverment.value}/${district.value}/${section.value}`;
    const response = await fetch(url, {
      method: 'GET',
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error(error);
  }
};

const geojsonGeometries = ref(null);
const ManzanaGeoJSON = ref(null);
const VialidadGeoJSON = ref(null);
const SitioGeoJSON = ref(null);

onMounted(async () => {
  geojsonGeometries.value = await fetchGeoMzn();
  ManzanaGeoJSON.value = JSON.parse(geojsonGeometries.value.CartoManzanas.geom);
  VialidadGeoJSON.value = JSON.parse(geojsonGeometries.value.CartoVialidad.geom);
  SitioGeoJSON.value = JSON.parse(geojsonGeometries.value.CartoSitio.geom);
  // Inicia el Mapa
  map.value = markRaw(
    new Map({
      container: mapContainer.value,
      style: {
        version: 8,
        sources: {},
        layers: [],
      },
      zoom: 4,
      maxZoom: 24,
      center: [-102.7204777, 24.0666245],
      pitch: 0,
      attributionControl: false,
    }),
  );

  map.value.addControl(new NavigationControl(), 'top-left');

  map.value.on('style.load', () => {
    listo.value = true;
  });
});

watch(
  () => [listo.value, in3d.value, banderaRePaint.value],

  async () => {
    // console.log('Valor de banderaDatos :    ' + banderaDatos.value);
    console.log(geojson.value);
    if (geojson.value === null) {
      // Pide el GeoJSON con sus propiedades
      ({ geojson: geojson.value } = await useGeoJSONFeaturesMultyPolygon(
        ManzanaGeoJSON.value,
        escenarioEdit.value.id,
        goverment.value,
        district.value,
        section.value,
      ));

      perimeterGeoJSON.value = usePerimeterGeoJSON(ManzanaGeoJSON.value);
      // banderaDatos.value = true;
      if (geojson.value) {
        rePaintMap();
      }
    } else if (geojson.value !== null && banderaRePaint.value === true) {
      console.log('Entre al que reinicia');
      geojson.value = null;
      perimeterGeoJSON.value = null;
      // Reinicia los listeners del mapa asociados al click
      const events = map.value._listeners['click'];
      if (events && events.length) {
        events.forEach(function (listener) {
          map.value.off('click', listener);
        });
      }

      // Quita las capas
      map.value
        .removeLayer('manzanas')
        .removeLayer('outline')
        .removeLayer('perimeter')
        .removeSource('perimeter')
        .removeSource('geojson')
        .removeLayer('route')
        .removeSource('route')
        .removeLayer('escuelas')
        .removeSource('escuelas')
        .removeLayer('casillas')
        .removeSource('casillas')
        .removeImage('custom-casilla');

      map.value.removeImage('custom-marker');
      // Vacía el arreglo de los poligonos seleccionados
      selectedFeatures = [];

      // Vuelve a pedir los geoJSON con sus nuevas propiedades
      ({ geojson: geojson.value } = await useGeoJSONFeaturesMultyPolygon(
        ManzanaGeoJSON.value,
        escenarioEdit.value.id,
        goverment.value,
        district.value,
        section.value,
      ));

      perimeterGeoJSON.value = usePerimeterGeoJSON(ManzanaGeoJSON.value);
      if (geojson.value) {
        rePaintMap();
      }
      // banderaDatos.value = false;
    } else {
      console.log('No entro porque BanderaRePaint esta en false');
    }
  },
);
</script>

<template>
  <div class="w-full h-full">
    <div>
      <div
        ref="mapContainer"
        class="map w-full h-full bg-slate-300"
      />
      
    </div>
    <div
      id="info-mapa"
      class="max-w-sm rounded overflow-hidden bg-white shadow-lg"
    >
      <div class="px-3 py-2">
        <div
          class="font-bold xl:text-2xl md:text-xl mb-2 text-[#6F2F71] text-center"
        >
          Información
        </div>
        <div v-if="!hoveredPolygon">
          <p class="text-gray-700 xl:text-base md:text-sm">
            {{ mensajeInfo.texto }}
          </p>
        </div>
        <div v-else>
          <table>
            <tbody>
              <p class="font-bold xl:text-xl md:text-base mb-2 text-[#6F2F71]">
                {{ mensajeInfo.tipo }}
              </p>
              <p class="xl:text-sm md:text-xs py-0 my-0">
                <span class="font-bold">ST</span>
                {{ features.properties.st }}
              </p>
              <p class="xl:text-sm md:text-xs py-0 my-0">
                <span class="font-bold">Manzana</span>
                {{ features.properties.id }}
              </p>
              <p class="xl:text-sm md:text-xs py-0 my-0">
                <span class="font-bold pb-0 mb-0">Localidad:</span>
                {{ features.properties.nombre_localidad }} (
                {{ features.properties.localidad }} )
              </p>
              <p class="xl:text-sm md:text-xs py-0 my-0">
                <span class="font-bold pb-0 mb-0">L.Nominal:</span>
                {{ features.properties.l_nominal }}
              </p>
              <p class="xl:text-sm md:text-xs py-0 my-0">
                <span class="font-bold pb-0 mb-0">Padrón:</span>
                {{ features.properties.padron }}
              </p>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div
      v-if="geojson"
      id="btn-fit-bounds"
      class="max-w-sm rounded overflow-hidden bg-white shadow-lg p-1"
    >
      <button @click="fitBounds">Home</button>
    </div>

    <div
      v-if="geojson"
      id="btn-3d"
      class="max-w-sm rounded overflow-hidden bg-white shadow-lg p-1 font-bold"
    >
      3D <input v-model="in3d" type="checkbox" >
    </div>
  </div>
</template>

<style scoped>
#info-mapa {
  position: absolute;
  right: 1vw;
  bottom: 20vh;
  max-width: 17.5vw;
  max-height: 40vh;
}

/* .map {
  position: absolute;
  width: 100%;
  height: 100%;
} */

.map {
  /* position: absolute; */
  /* top: 0;
  bottom: 0;
  width: 100%;
  height: 100%; */
}

#btn-fit-bounds {
  position: absolute;
  right: 0.5vw;
  top: 14vh;
}

#btn-3d {
  position: absolute;
  right: 3.5vw;
  top: 14vh;
}
</style>
