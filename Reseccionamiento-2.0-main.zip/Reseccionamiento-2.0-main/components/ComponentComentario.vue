<template>
  <div>
    <div class="container">
      <template v-if="comentarios.length > 0">
        <div class="h-56 overflow-auto scrollbar pb-4 px-4">
          <div
            v-for="(comentario, index) in comentarios"
            :key="index"
            class="comentario bg-white rounded-lg shadow-xl pt-4 pb-2 px-4 border border-gray-300 mt-3"
          >
            <div class="mb-4">
              <p class="text-sm font-semibold">
                {{ comentario.comentario }}
              </p>
            </div>
            <div class="border-t border-gray-300 my-4"/>
            <div class="flex justify-between items-center mb-2">
              <div class="flex flex-col">
                <p class="text-xs text-slate-900">
                  {{ comentario.nombre_usuario }}
                </p>
                <p class="text-xs text-slate-600">
                  {{ comentario.formatted_fecha }}
                </p>
              </div>
              <div class="flex items-center">
                <img
                  class="h-8 w-8 rounded-full"
                  :src="transformarRuta(comentario.logo)"
                  alt="Imagen de perfil"
                >
              </div>
            </div>
          </div>
        </div>
      </template>
      <div class="writePrintComment mt-10">
        <form @submit.prevent="submitForm">
          <div v-for="p in permiso" :key="p.permiso">
            <template v-if="p == 0">
              <div class="relative">
                <label
                  for="message"
                  class="block mb-2 text-base font-medium text-gray-900"
                >Escribe tu comentario:</label
                >
                <textarea
                  id="message"
                  v-model="formData.comentario"
                  rows="4"
                  class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-sm border-2 border-gray-300 focus:ring-pink-600 focus:border-pink-600 resize-none"
                  placeholder="Escribe tu comentario..."
                />
                <button
                  type="submit"
                  class="absolute right-2 bottom-2 h-8 px-2 flex items-center justify-center rounded-md border text-sm border-buttonsEnviar bg-buttonsEnviar text-white hover:text-buttonsEnviar hover:bg-transparent"
                >
                  <span class="mr-1">
                    <IconComponent :icon="['fas', 'paper-plane']" />
                  </span>
                  Enviar
                </button>
              </div>
            </template>
          </div>
        </form>
        <div class="flex justify-center mt-6">
          <button
            class="text-sm font-semibold border rounded-sm p-1 bg-navBar text-white uppercase w-full text-center hover:text-navBar hover:bg-transparent border-navBar"
            @click="imprimirComentarios"
          >
            <span class="mr-2">
              <IconComponent :icon="['fas', 'print']" />
            </span>
            Imprimir Comentarios
          </button>
        </div>
        <div class="flex justify-center mt-3">
          <button
            class="text-sm font-semibold border rounded-sm p-1 bg-navBar text-white uppercase w-full text-center hover:text-navBar hover:bg-transparent border-navBar"
            @click="returnPage()"
          >
            <span class="mr-2">
              <IconComponent :icon="['fas', 'fa-house-chimney']" />
            </span>
            Regresar
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import jsPDF from 'jspdf';
import { storeToRefs } from 'pinia';
import { sideBarStore } from './../stores/sideBar';
import fondoPDF from '@/assets/img/fondoPDF.png';
import logoINE from '@/assets/img/INE_blanco.png';
const storeSideBar = sideBarStore();
const { goverment, goverments, district, section, escenarioEdit } =
  storeToRefs(storeSideBar);

const comentarios = ref([]);
const permiso = ref([]);
const formData = ref({ comentario: '' });
const commentsByUser = ref([]);

const transformarRuta = (ruta) => {
  if (ruta) {
    return `/_nuxt/assets/resources/img${ruta.replace('resources/img', '')}`;
  }
};

// Nos traemos los comentarios
const fetchComentarios = async () => {
  const url = `http://localhost:3030/getComentarios?idEscenario=${escenarioEdit.value.id}&typeUser=ADMINISTRADOR`;
  try {
    const response = await fetch(url);
    const data = await response.json();
    comentarios.value = data;
  } catch (error) {
    console.error(error);
  }
};

// Esta funcion permite reasignar la url del logo para que sea mostrada
const returnPage = () => {
  navigateTo('/console/crearEscenarios');
};

const fetchPermisosToComment = async () => {
  // const url ='http://localhost:3030/permisosToComment?idEscenario=2&entidad=1&distrito=1&typeUser=ADMINISTRADOR';
  const url = `http://localhost:3030/permisosToComment?idEscenario=${escenarioEdit.value.id}&entidad=${goverment.value}&distrito=${district.value}&typeUser=ADMINISTRADOR`;
  try {
    const response = await fetch(url);
    const data = await response.json();
    permiso.value = data;
  } catch (error) {
    console.error(error);
  }
};

const getCommentsByUser = async () => {
  const url = `http://localhost:3030/printCommentByUser?idEscenario=${escenarioEdit.value.id}&userName=erick.loza&typeUser=ADMINISTRADOR`;
  try {
    const response = await fetch(url);
    const data = await response.json();
    commentsByUser.value = data;
  } catch (error) {
    console.error(error);
  }
};

onMounted(fetchComentarios);
onMounted(fetchPermisosToComment);
onMounted(getCommentsByUser);

// console.log('IdEscenario*********', escenarioEdit.value.id);

// Esta funcion envia el formulario
const submitForm = async () => {
  const data = {
    comentario: formData.value.comentario,
  };

  try {
    // const url = 'http://localhost:3030/addComentario?idEscenario=1&nombreUsuario=erick.loza&typeUser=PRI-CDV';
    const url = `http://localhost:3030/addComentario?idEscenario=${escenarioEdit.value.id}&nombreUsuario=erick.loza&typeUser=ADMINISTRADOR`;
    const response = await fetch(url, {
      method: 'POST',
      body: JSON.stringify(data),
    });

    if (response.ok) {
      // La solicitud se realizó con éxito
      console.log('Datos enviados correctamente');

      // Actualizar la lista de comentarios después de enviar el comentario correctamente
      await fetchComentarios();
      await getCommentsByUser();

      // Restablecer los valores del formulario
      formData.value.comentario = '';
    } else {
      // Hubo un error en la respuesta
      console.log('Error al enviar los datos');
    }
  } catch (error) {
    // Hubo un error en la solicitud
    console.log('Error en la solicitud:', error);
  }
};

// Esta función imprime en pdf los comentarios
const imprimirComentarios = () => {
  const doc = new jsPDF();

  // *** FONDO DEL PDF ***
  const fondoDelPDF = {
    image: fondoPDF,
  };

  // Obtener las dimensiones de la página
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  // Establecer la posición y escala del logo de fondo
  const fondoDelPDFX = 0;
  const fondoDelPDFY = 5;
  const fondoDelPDFWidth = pageWidth;
  const fondoDelPDFHeight = pageHeight;

  const principal = () => {
    // Agregar el logo de fondo con transparencia
    doc.addImage(
      fondoDelPDF.image,
      'PNG',
      fondoDelPDFX,
      fondoDelPDFY,
      fondoDelPDFWidth,
      fondoDelPDFHeight,
      '',
      'MEDIUM',
    );

    // *** TERMINA CODIGO FONDO DEL PDF ***

    // *** FONDO MORADO DEL ENCABEZADO ***
    // Filled square with red borders
    doc.setDrawColor(0);
    doc.setFillColor(154, 24, 106);
    doc.rect(0, 0, doc.internal.pageSize.getWidth(), 30, 'F');

    // *** TERMINA CODIGO DEL FONDO MORADO ***

    // *** INGRESAMOS EL LOGO DEL INE ***
    const logoContent = {
      image: logoINE,
      width: 40,
      height: 12,
    };

    doc.addImage(
      logoContent.image,
      'PNG',
      20,
      10,
      logoContent.width,
      logoContent.height,
    );

    // *** TERMINAMOS DE INGRESAR EL LOGO DEL INE ***

    // *** ENCABEZADO DE RESECCIONAMIENTO EN LA PARTE DERECHA ***

    doc.setFontSize(15);
    doc.setTextColor('white');
    doc.setFont('helvetica', 'normal');
    doc.text('Sistema de Reseccionamiento 2023', 190, 22, null, null, 'right');

    // *** TERMINAMOS DE INGRESAR EL ULTIMO ENCABEZADO ***
  };

  principal();

  // *** TITULO PRINCIPAL ***
  doc.setFontSize(15);
  doc.setTextColor(154, 24, 106);
  doc.setFont('helvetica', 'bold');
  doc.text('OBSERVACIONES AL ESCENARIO', 105, 45, null, null, 'center');

  // Regresamos al color normal del texto
  doc.setTextColor(0, 0, 0);

  // *** FIN TITULO PRINCIPAL ***

  // *** TITULO SECUNDARIO ***
  const govermentName = goverments.value[goverment.value].name.toUpperCase();
  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text(
    // 'SONORA / DISTRITO FEDERAL ELECTORAL 6 / SECCIÓN 808',
    `${govermentName} / DISTRITO FEDERAL ELECTORAL ${district.value} / SECCIÓN ${section.value}`,
    105,
    53,
    null,
    null,
    'center',
  );

  // *** FIN TITULO SECUNDARIO ***

  // *** COMENTARIOS ***
  // Posición Y inicial del primer comentario
  let startY = 73;
  // Altura de cada línea de comentario
  const lineHeight = 5;
  const totalComentarios = commentsByUser.value.length;
  commentsByUser.value.forEach((comentarios, index) => {
    const { nombre_usuario, formatted_fecha, comentario } = comentarios;

    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(154, 24, 106);
    doc.text(nombre_usuario, 20, startY);

    // Obtener la posición X del final del nombre de usuario
    const usuarioX = doc.getTextWidth(nombre_usuario) + 25;

    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 0, 0);
    doc.text(formatted_fecha, usuarioX, startY);

    startY += lineHeight + 1;

    // Dividir el comentario en líneas
    const maxWidth = pageWidth; // Ancho máximo ajustado para el comentario
    const textLines = doc.splitTextToSize(comentario, maxWidth - 25);

    // const textLines = doc.splitTextToSize(comentario, 170);

    // Imprimir el comentario línea por línea
    for (let i = 0; i < textLines.length; i++) {
      const line = textLines[i];

      // Verificar si se debe agregar una nueva página
      if (startY + lineHeight > doc.internal.pageSize.getHeight() - 20) {
        doc.addPage();
        principal();
        startY = 40;
      }

      // Imprimir la línea actual del comentario
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(0, 0, 0);
      doc.text(20, startY, line, { align: 'justify', maxWidth: maxWidth - 25 });
      startY += lineHeight;
    }

    // Agregar una línea divisoria si no es el último comentario
    if (index < totalComentarios - 1) {
      if (startY + lineHeight + 10 > doc.internal.pageSize.getHeight() - 20) {
        doc.addPage();
        principal();
        startY = 40;
      }

      doc.setDrawColor(154, 24, 106);
      doc.setLineWidth(0.3);
      doc.line(20, startY, 70, startY);
      startY += lineHeight + 5;
    }
  });

  const lastCommentY = startY + (totalComentarios - 1) * lineHeight;

  // Posición Y inicial del apartado de la zona de firma
  let signatureAreaY = 0;
  totalComentarios > 1
    ? (signatureAreaY = lastCommentY + 30)
    : (signatureAreaY = startY + 30);

  // Verificar si el apartado de la zona de firma se encuentra fuera del área visible de la página
  if (signatureAreaY > doc.internal.pageSize.getHeight() - 25) {
    // Agregar una nueva página
    doc.addPage();

    // Agregamos los datos que debe llevar cada pagina
    principal();

    // Reiniciar la posición Y para el nuevo conjunto de comentarios en la página siguiente
    startY = 40;
    signatureAreaY = 73;
  }

  // Largo de la linea de firma
  const lineLength = 80;

  // Calcular la posición X inicial de la línea de firma en el centro de la página
  const lineX = (pageWidth - lineLength) / 2;

  const lineEndX = lineX + lineLength;

  // Posición Y de la línea debajo del último comentario
  // const lineY = lastCommentY + lineHeight + 75;

  // Dibujar la línea debajo del último comentario
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.3);
  doc.line(lineX, signatureAreaY, lineEndX, signatureAreaY);

  // Posición Y del nombre de usuario para firmar
  const signatureY = signatureAreaY + 8;

  // Imprimir el nombre de la persona que firmara
  doc.setFontSize(12);
  doc.setTextColor(154, 24, 106);
  doc.setFont('helvetica', 'bold');
  doc.text('ERICK RAUL LOZA DOMINGUEZ', 105, signatureY, null, null, 'center');

  // Imprimir el nombre de usuario que firmara
  doc.setFontSize(12);
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'bold');
  doc.text('dante.ezio', 105, signatureY + 6, null, null, 'center');

  // Posicion de la persona que firmara
  doc.setFontSize(12);
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  doc.text(
    'TÉCNICO CARTÓGRAFO EN SISTEMAS DE CONSULTAS DE ALTO VOLUMEN',
    105,
    signatureY + 12,
    null,
    null,
    'center',
  );

  // *** Termina zona de firma ***

  // Generar un objeto Blob con el contenido del PDF
  const pdfBlob = doc.output('blob');

  // Crear una URL para el objeto Blob
  const pdfUrl = URL.createObjectURL(pdfBlob);

  // Abrir una nueva ventana emergente con el PDF
  const ventanaNueva = window.open(pdfUrl, '_blank', 'width=600,height=400');

  // Liberar la URL del objeto Blob cuando la ventana se cierre
  ventanaNueva.addEventListener('beforeunload', () => {
    URL.revokeObjectURL(pdfUrl);
  });
};
</script>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px; /* Ancho de la barra de desplazamiento */
}

.scrollbar::-webkit-scrollbar-track {
  background-color: transparent; /* Color de fondo de la barra de desplazamiento */
}

.scrollbar::-webkit-scrollbar-thumb {
  background-color: #d1d5db; /* Color del pulgar de la barra de desplazamiento */
  border-radius: 3px; /* Borde redondeado del pulgar de la barra de desplazamiento */
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background-color: #9ca3af; /* Color del pulgar de la barra de desplazamiento al pasar el cursor */
}

.scrollbar::-webkit-scrollbar-thumb:active {
  background-color: #6b7280; /* Color del pulgar de la barra de desplazamiento al hacer clic */
}
</style>
