<template>
  <div class="w-full h-full relative">
    <!-- Map -->
    <div
      ref="mapContainer" class="map bg-gray-300 dark:bg-[#2e2e2e44] absolute"
      :style="{ height: `${availableHeight}px` }" />

    <!-- Adicionales Map -->
    <div v-if="geojson" class="max-w-sm rounded absolute top-3 right-3 flex flex-col gap-2">
      <!-- Button Action -->
      <div class="flex gap-2 items-end justify-end">
        <UTooltip :text="isAnimating ? 'Deshabilite la animación primero' : (in3d ? 'Deshabilitar 3D' : 'Habilitar 3D')">
          <UButton
            icon="i-heroicons-cube" 
            label="3D"
            color="white" 
            :disabled="isAnimating"
            :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-[#252756d7] dark:ring-ineRosa text-white dark:text-white bg-[#252756d7]  dark:bg-[#bf889ed7] hover:bg-gray-800/50 dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 disabled:bg-gray-800/50 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }" @click="in3d = !in3d" />
        </UTooltip>
        <!-- Button to toggle the animation -->
        <UTooltip v-if="in3d && route.path !== '/console/editarEscenarios'" :text="isAnimating ? 'Detener animación 3D' : 'Iniciar animación 3D'">
          <UButton
            :icon="isAnimating ? 'i-heroicons-stop' : 'i-heroicons-play'" color="white" :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-[#252756d7] dark:ring-ineRosa text-white dark:text-white bg-[#252756d7]  dark:bg-[#bf889ed7] hover:bg-gray-800/50 dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }" @click="toggleAnimation" />
        </UTooltip>

        <UTooltip text="Volver a la vista inicial">
          <UButton
            icon="i-heroicons-home" color="white" :ui="{
              color: {
                white: {
                  solid:
                    'text-xs shadow-sm ring-1 ring-inset ring-[#252756d7] dark:ring-ineRosa text-white dark:text-white bg-[#252756d7]  dark:bg-[#bf889ed7] hover:bg-gray-800/50 dark:hover:bg-gray-800/50 dark:disabled:bg-gray-900 focus-visible:ring-2 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400 transition-hover duration-1000',
                },
              },
            }" @click="fitBounds" /> 
        </UTooltip>
      </div>
      <!-- Control de Opacidad -->
      <div class="max-w-sm rounded overflow-hidden bg-[#252756d7]  dark:bg-[#bf889ed7] dark:border-[0.5px] dark:border-ineRosa dark:text-white text-white shadow-lg py-3 px-3 flex flex-col items-center justify-center gap-2">
        <UFormGroup
          :ui="{
            label: {
              base: 'text-white font-normal dark:text-[#fafafafa] text-[14px] pb-1',
            },
          }" name="range" label="Transparencia de capas:">
          <URange
            v-model="opacity" :min="0" :max="1" :step="0.1"
            :ui="{
              progress: {
                background: 'bg-pink-200 dark:bg-inePurpura',
              },
              thumb: {
                base: '[&::-webkit-slider-thumb]:relative [&::-moz-range-thumb]:relative [&::-webkit-slider-thumb]:z-[1] [&::-moz-range-thumb]:z-[1] [&::-webkit-slider-thumb]:appearance-none [&::-moz-range-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0',
                color: 'text-ineRosa dark:text-pink-500 dark:hover:text-pink-600',
                background: '[&::-webkit-slider-thumb]:bg-slate-100 [&::-webkit-slider-thumb]:hover:bg-slate-300 [&::-webkit-slider-thumb]:dark:bg-pink-500 [&::-webkit-slider-thumb]:dark:hover:bg-pink-600 [&::-moz-range-thumb]:bg-current',
              }
            }"
          />
        </UFormGroup>
      </div>
      <!-- Habilitar/Deshabilitar Secciones de Trabajo -->
      <div class="flex flex-col justify-end items-end">
        <!-- ST AND LN -->
        <div  class="max-w-[100px] rounded py-2 px-4 overflow-hidden bg-[#252756d7]  dark:bg-[#bf889ed7]  dark:border-[0.5px] dark:border-ineRosa dark:text-[#fafafafa] text-white font-semibold flex flex-col gap-2">
          <!-- Title -->
          <div class="text-semibold text-center">
            <h1 class="text-[14px]">ST / L.N</h1>
          </div>
          <!-- Button Actions -->
          <div class="flex flex-col gap-2">
            <div v-for="(st, index) in sortedSections" :key="st" class="text-[12px] flex items-center gap-2">
              <UTooltip :text="'Habilitar/Deshabilitar ST ' + st">
                <button :style="getButtonStyle(index, st)" class="rounded text-center text-white w-7 h-7 flex justify-center items-center hover:opacity-80" @click="toggleSt(st)">
                  {{ st }}
                </button>
              </UTooltip>
              <!-- L-N -->
              <p>{{ summedSectionLNominal[index + 1] }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Información Part 1 -->
    <div v-if="hoveredPolygon" class="absolute top-3 left-1/2 transform -translate-x-1/2 flex gap-2 text-white bg-[#252756d7]  dark:bg-[#512f73d3] px-6 rounded-md">
      <!-- ST -->
      <h1>
        ST {{ features.properties.st }}
      </h1>
      <!-- Rango -->
      <h1>/ R {{ roundNumbers(features.properties.rango) }}</h1>
      <!-- Conformación -->
      <h1>/ C {{ roundNumbers(features.properties.conformacion) }}</h1>
      <!-- Vialidad -->
      <div class="flex items-center gap-1">
        <h1>/ V</h1>
        <UIcon
          :class="features.properties.vialidad === 0 ? 'text-red-500 dark:text-red-700' : 'text-green-500 dark:text-green-400'"
          class="text-lg font-bold"
          :name="features.properties.vialidad === 0 ? 'i-heroicons-x-circle' : 'i-heroicons-check-circle'" />
      </div>
      <!-- Sitio -->
      <div class="flex items-center gap-1">
        <h1>/ S</h1>
        <UIcon
          :class="features.properties.sitio === 0 ? 'text-red-500 dark:text-red-700' : 'text-green-500 dark:text-green-400'"
          class="text-lg font-bold"
          :name="features.properties.sitio === 0 ? 'i-heroicons-x-circle' : 'i-heroicons-check-circle'" />
      </div>
    </div>
    <!-- Information Part 2 -->
    <div class="absolute bottom-2 right-3">
      <div
        class="max-w-sm rounded py-2 px-4 overflow-hidden bg-[#252756d7]  dark:bg-[#bf889ed7] dark:border-[0.5px] dark:border-ineRosa dark:text-[#fafafafa] text-white">
        <!-- Title -->
        <div class="text-semibold text-center">
          <p class="text-[12px] font-semibold">{{ entityName.name }} / D: {{district}} / S: {{ section }}</p>
          <h2 v-if="!hoveredPolygon" class="text-[12px]">{{ mensajeInfo.texto }}</h2>
        </div>
        <div v-if="hoveredPolygon" class="text-[12px]">
          <!-- Información Manzana -->
          <div class="text-[20px] text-center text-white font-semibold pt-1">
            <h2>Manzana</h2>
          </div>
          <div>
            <p>Manzana: {{ features.properties.id }}</p>
          </div>
          <!-- Localidad -->
          <div>
            <p>Localidad: {{ features.properties.nombre_localidad }} (
              {{ features.properties.localidad }} )</p>
          </div>
          <!-- L.Nominal -->
          <div v-if="features.properties.l_nominal !== 0">
            <p>L.Nominal: {{ features.properties.l_nominal }}</p>
          </div>
          <!-- Padrón -->
          <div v-if="features.properties.padron !== 0">
            <p>Padrón: {{ features.properties.padron }}</p>
          </div>
          <!-- Información sección de trabajo -->
          <div class="text-[20px] text-center text-white font-semibold pt-1">
            <h2>Sección de trabajo {{ features.properties.st }}</h2>
          </div>
          <!-- L.Nominal ST -->
          <div v-if="features.properties.lnominal_st !== 0">
            <p>L.Nominal: {{ features.properties.lnominal_st }}</p>
          </div>
          <!-- ádrón ST -->
          <div v-if="features.properties.padron_st !== 0">
            <p>Padrón: {{ features.properties.padron_st }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { Map, NavigationControl, Marker, ScaleControl } from 'maplibre-gl';
import BasemapsControl from 'maplibre-gl-basemaps';
import * as turf from '@turf/turf';
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/stores/sideBar';
import { medidasStores } from '@/stores/medidasStores';
import { descargasStore } from '@/stores/descargasStore';
import { useRoute } from 'vue-router';
import schoolIcon from '@/assets/img/m5.png';
import casillaIcon from '@/assets/img/c6.png';
import { roundNumbers } from '~/services/roundNumbers';

// *** Manejo de Stores ***
const storeMedidas = medidasStores();
const { dataAlto } = storeToRefs(storeMedidas);

// Le asigna el alto al mapa
const availableHeight = ref(null);
watchEffect(() => {
  availableHeight.value = dataAlto.value;
});

const storeSideBar = sideBarStore();
const { goverments, goverment, district, section, banderaRePaint, idEscenario } = storeToRefs(storeSideBar);

const entityName = goverments.value.find((g) => g.id === goverment.value);

const storeDescargas = descargasStore();

const hoveredPolygon = ref(null);
const listo = ref(false);
const in3d = ref(false);
const selectedFeatures = ref([]);
const geojson = ref(null);
const perimeterGeoJSON = ref(null);
const mensajeInfo = computed(() => ({ tipo: 'Entidad', texto: 'Sitúate sobre una manzana' }));
const mapContainer = ref(null);
const map = ref(null);
const features = ref(null);
const geojsonGeometries = ref(null);
const ManzanaGeoJSON = ref(null);
const VialidadGeoJSON = ref(null);
const SitioGeoJSON = ref(null);

const barraColores = usePaletaColores();
const barraColores3D = usePaletaColores3D();
const layer = computed(() => {
  if (in3d.value) {
    return {
      id: 'manzanas',
      type: 'fill-extrusion',
      source: 'geojson',
      paint: {
        'fill-extrusion-color': [
          'case',
          ['boolean', ['feature-state', 'selected'], false],
          '#ff0000', // Color when selected
          barraColores3D,
        ],
        'fill-extrusion-height': ['get', 'height'],
        'fill-extrusion-base': ['get', 'base_height'],
        'fill-extrusion-opacity': 1, // Inicializar la opacidad para modo 3D
      },
    };
  } else {
    return {
      id: 'manzanas',
      type: 'fill',
      source: 'geojson',
      paint: {
        'fill-color': [
          'case',
          ['boolean', ['feature-state', 'selected'], false],
          '#ff0000', // Color when selected
          barraColores,
        ],
        'fill-opacity': 1, // Inicializar la opacidad para modo 2D
      },
    };
  }
});

const layerOutline = computed(() => {
  return {
    id: 'outline',
    type: 'line',
    source: 'geojson',
    layout: {},
    paint: {
      'line-color': [
        'case',
        ['boolean', ['feature-state', 'hover'], false],
        '#242C89',
        '#333',
      ],
      'line-width': [
        'case',
        ['boolean', ['feature-state', 'hover'], false],
        5,
        2,
      ],
      'line-opacity': 1, // Ajustar la opacidad
    },
  };
});

const layerPerimeter = {
  id: 'perimeter',
  type: 'line',
  source: 'perimeter',
  layout: {},
  paint: {
    'line-color': '#252756',
    'line-width': 10,
  },
};

const fitBounds = () => {
  if(in3d.value){
    // Ajustar la vista inicial para el modo 3D
    const center = calculateCentroid(geojson.value) ;
    map.value.jumpTo({
      center: [center[0], center[1]],
      pitch: 60, // Ajustar la inclinación para una buena visualización en 3D
      bearing: 0, // Orientación inicial, puedes ajustar según tu preferencia
      zoom: 14, // Reducir el nivel de zoom en 1
    });
  }else{
    map.value.fitBounds(turf.bbox(geojson.value), { duration: 0 });
    map.value.setPitch(0);
  }
};

// const fitBounds = () => {
//   const padding = 120; // Ajusta este valor según necesites
//   map.value.fitBounds(turf.bbox(geojson.value), {
//     padding: {
//       top: padding,
//       bottom: padding,
//       left: padding,
//       right: padding,
//     },
//     duration: 0,
//   });
//   map.value.setPitch(0);
// };

const removeMapInteractions = () => {
  if (map.value) {
    const events = ['mousemove', 'mouseleave', 'click'];
    events.forEach(event => {
      if (map.value._listeners[event]) {
        map.value._listeners[event].forEach(listener => map.value.off(event, 'manzanas', listener));
      }
    });
  }
};

const rePaintMap = () => {
  removeMapInteractions(); // Eliminar eventos antiguos

  // Limpiar capas y fuentes antiguas
  const layers = ['manzanas', 'outline', 'perimeter', 'route'];
  const sources = ['perimeter', 'geojson', 'route'];

  layers.forEach(layer => {
    if (map.value.getLayer(layer)) {
      map.value.removeLayer(layer);
    }
  });

  sources.forEach(source => {
    if (map.value.getSource(source)) {
      map.value.removeSource(source);
    }
  });

  // Añadir nuevas fuentes y capas
  map.value.addSource('geojson', {
    type: 'geojson',
    data: geojson.value,
  });

  map.value.addSource('perimeter', {
    type: 'geojson',
    data: perimeterGeoJSON.value,
  });

  map.value.addLayer(layerPerimeter);
  map.value.addLayer(layer.value);
  map.value.addLayer(layerOutline.value);

  if (VialidadGeoJSON.value.features !== null) {
    map.value.addSource('route', {
      type: 'geojson',
      data: VialidadGeoJSON.value,
      generateId: true,
    });
    let style = null;
    if (VialidadGeoJSON.value.features[0].properties.categoria === 1) {
      style = {
        'line-color': '#ff462e',
        'line-width': 4,
        'line-opacity': 1,
        'line-dasharray': [2, 2],
      };
    }
    if (VialidadGeoJSON.value.features[0].properties.categoria === 5) {
      style = {
        'line-color': '#8c00ff',
        'line-width': 4,
        'line-opacity': 1,
      };
    }
    if (VialidadGeoJSON.value.features[0].properties.categoria === 6) {
      style = {
        'line-color': '#ff462e',
        'line-width': 4,
        'line-opacity': 1,
      };
    }
    map.value.addLayer({
      id: 'route',
      type: 'line',
      source: 'route',
      layout: {
        'line-join': 'round',
        'line-cap': 'round',
      },
      paint: style,
    });
  }

  fitBounds();
  addMapInteractions(); // Añadir nuevos eventos
  // *** Obtenemos las Secciones de Trabajo y las Listas Nominales ***
  processGeojsonFeatures(geojson.value);
};

const route = useRoute();
const addMapInteractions = () => {
  map.value.on('mousemove', 'manzanas', function (e) {
    features.value = map.value.queryRenderedFeatures(e.point)[0];
    if (features.value) {
      if (hoveredPolygon.value) {
        map.value.setFeatureState(
          { source: 'geojson', id: hoveredPolygon.value },
          { hover: false },
        );
      }
      hoveredPolygon.value = features.value.id;

      map.value.setFeatureState(
        { source: 'geojson', id: hoveredPolygon.value },
        { hover: true },
      );
    }
  });

  map.value.on('mouseleave', 'manzanas', function () {
    if (hoveredPolygon.value) {
      map.value.setFeatureState(
        { source: 'geojson', id: hoveredPolygon.value },
        { hover: false },
      );
    }
    hoveredPolygon.value = null;
  });

  if (route.path !== '/console/verEscenario') {
    map.value.on('click', 'manzanas', function (e) {
      if (e.originalEvent.cancelBubble) return; // Evitar doble ejecución

      e.originalEvent.cancelBubble = true; // Marcar el evento como manejado

      const clickedFeatureId = e.features[0].id;
      const isSelected = map.value.getFeatureState({ source: 'geojson', id: clickedFeatureId }).selected;

      if (isSelected) {
        const index = selectedFeatures.value.indexOf(clickedFeatureId);
        if (index > -1) {
          selectedFeatures.value.splice(index, 1);
        }
        map.value.setFeatureState({ source: 'geojson', id: clickedFeatureId }, { selected: false });
      } else {
        selectedFeatures.value.push(clickedFeatureId);
        map.value.setFeatureState({ source: 'geojson', id: clickedFeatureId }, { selected: true });
      }

      const barraColoresSelected = usePaletaColoresSelected(selectedFeatures.value);
      map.value.setPaintProperty('manzanas', in3d.value ? 'fill-extrusion-color' : 'fill-color', barraColoresSelected);

      storeSideBar.setIdsMzn(selectedFeatures.value);
    });
  }
  storeSideBar.setBanderaRePaint(false);
};

const fetchGeoMzn = async () => {
  try {
    const url = `http://localhost:3030/getCartografia/${goverment.value}/${district.value}/${section.value}`;
    const response = await fetch(url, { method: 'GET' });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error(error);
  }
};

onMounted(async () => {
  try {
    geojsonGeometries.value = await fetchGeoMzn();
    ManzanaGeoJSON.value = JSON.parse(geojsonGeometries.value.CartoManzanas.geom);
    VialidadGeoJSON.value = JSON.parse(geojsonGeometries.value.CartoVialidad.geom);
    SitioGeoJSON.value = JSON.parse(geojsonGeometries.value.CartoSitio.geom);

    // Guardamos en el store la data de escenarios para el componente descargas
    storeDescargas.setDataEscenario(ManzanaGeoJSON.value);

    map.value = markRaw(new Map({
      container: mapContainer.value,
      style: { version: 8, sources: {}, layers: [] },
      zoom: 4,
      maxZoom: 24,
      center: [-102.7204777, 24.0666245],
      pitch: 0,
      attributionControl: false,
    }));

    map.value.addControl(new NavigationControl(), 'top-left');
    map.value.addControl(new ScaleControl(), 'bottom-left');
    const optionsBaseMap = useBaseMaps();
    map.value.addControl(new BasemapsControl(optionsBaseMap), 'bottom-left');

    map.value.on('style.load', () => {
      listo.value = true;

      // Add markers for all features
      addMarkers(SitioGeoJSON.value.features);
    });
  } catch (error) {
    console.error('Error during onMounted execution:', error);
  }
});

// *** Función que permite agregar los marcadores al mapa (Escuelas y Casillas) ***
const addMarkers = (features) => {
  features.forEach(feature => {
    const el = document.createElement('div');
    el.className = 'marker';

    // Style the marker element
    el.style.backgroundImage = feature.properties.tipo === 'ESCUELA' 
      ? `url(${schoolIcon})` 
      : `url(${casillaIcon})`;
    el.style.width = '22px';
    el.style.height = '22px';
    el.style.backgroundSize = '100%';

    new Marker({element: el})
      .setLngLat(feature.geometry.coordinates)
      .addTo(map.value);
  });
};

watch([listo, in3d, banderaRePaint], async () => {
  if (geojson.value === null) {
    ({ geojson: geojson.value } = await useGeoJSONFeaturesMultyPolygon(
      ManzanaGeoJSON.value,
      idEscenario.value,
      goverment.value,
      district.value,
      section.value,
    ));
    perimeterGeoJSON.value = usePerimeterGeoJSON(ManzanaGeoJSON.value);
    if (geojson.value) {
      rePaintMap();
    }
  } else if (geojson.value !== null && banderaRePaint.value === true) {
    geojson.value = null;
    perimeterGeoJSON.value = null;
    selectedFeatures.value = [];

    const layers = ['manzanas', 'outline', 'perimeter', 'route'];
    const sources = ['perimeter', 'geojson', 'route'];

    layers.forEach(layer => {
      if (map.value.getLayer(layer)) {
        map.value.removeLayer(layer);
      }
    });

    sources.forEach(source => {
      if (map.value.getSource(source)) {
        map.value.removeSource(source);
      }
    });

    ({ geojson: geojson.value } = await useGeoJSONFeaturesMultyPolygon(
      ManzanaGeoJSON.value,
      idEscenario.value,
      goverment.value,
      district.value,
      section.value,
    ));
    perimeterGeoJSON.value = usePerimeterGeoJSON(ManzanaGeoJSON.value);
    if (geojson.value) {
      rePaintMap();
    }
    storeSideBar.setBanderaRePaint(false);
  }
});

// *** Observador para repintar el mapa cuando se habilita/deshabilita el 3D ***
watch(in3d, (newValue) => {
  if (newValue !== null) {
    rePaintMap();

    if (newValue) {
      // Ajustar la vista inicial para el modo 3D
      const center = calculateCentroid(geojson.value);
      map.value.jumpTo({
        center: [center[0], center[1]],
        pitch: 60, // Ajustar la inclinación para una buena visualización en 3D
        bearing: 0, // Orientación inicial, puedes ajustar según tu preferencia
        // zoom: map.value.getZoom() - 0.5, // Reducir el nivel de zoom en 1
      });
    } else {
      // Restablecer la vista al modo 2D
      fitBounds();
    }
  }
});

// *** Control de opacidad ***
const opacity = ref(1); // Valor inicial de la opacidad
watch(opacity, (newOpacity) => {
  if (map.value) {
    if (map.value.getLayer('manzanas')) {
      if (in3d.value) {
        map.value.setPaintProperty('manzanas', 'fill-extrusion-opacity', parseFloat(newOpacity));
      } else {
        map.value.setPaintProperty('manzanas', 'fill-opacity', parseFloat(newOpacity));
      }
      map.value.setPaintProperty('outline', 'line-opacity', parseFloat(newOpacity));
    }
  }
});

// *** Esta función genera la lógica para obtener la información que pintará las Secciones de trabajo y las listas nominales ***
const sections = new Set(); // Usamos un Set para evitar secciones duplicadas
const sectionLNominal = {}; // Objeto para almacenar los valores de l_nominal por sección
const sectionCoordinates = {}; // Objeto para almacenar secciones y coordenadas
const sortedSections = ref(null);
let summedSectionLNominal;

function processGeojsonFeatures(geojson) {
  geojson.features.forEach(feature => {
    if (feature.properties && feature.properties.st) {
      const section = feature.properties.st;
      const lNominal = feature.properties.l_nominal;
      sections.add(section);
      
      // Agregar las coordenadas de la sección al objeto sectionCoordinates
      if (!sectionCoordinates[section]) {
        sectionCoordinates[section] = [];
      }
      sectionCoordinates[section].push(feature.geometry.coordinates);

      // Agregar el valor de l_nominal de la sección al objeto sectionLNominal
      if (!sectionLNominal[section]) {
        sectionLNominal[section] = [];
      }
      sectionLNominal[section].push(lNominal);
    }
  });

  summedSectionLNominal = Object.fromEntries(
    Object.entries(sectionLNominal).map(([key, values]) => [
      key,
      values.reduce((acc, curr) => acc + curr, 0),
    ]),
  );
  
  sortedSections.value = Array.from(sections).sort((a, b) => a - b); // Ordena las secciones de menor a mayor
}

// *** Esta función extrae los colores del composable para poder pintarlos en el componente de las secciones ***
const coloresMap = ref([]);
for (let i = 4; i < barraColores.length; i ++) { // Comienza en 4 para omitir el primer color
  if (typeof barraColores[i] === 'string' && barraColores[i].startsWith('#')) {
    coloresMap.value.push(barraColores[i]);
    
  }
}

// *** Esta función habilita y deshabilita la sección seleccionada ***
const sectionVisibility = ref({});
const toggleSt = (section) => {
  const features = geojson.value.features.filter(feature => feature.properties.st === section);
  const isVisible = features.every(feature => map.value.getFeatureState({ source: 'geojson', id: feature.id }).visible);

  features.forEach(feature => {
    map.value.setFeatureState({ source: 'geojson', id: feature.id }, { visible: !isVisible });
  });

  sectionVisibility.value[section] = !isVisible;

  // Actualizar la propiedad de color de relleno para reflejar la visibilidad
  if (map.value.getLayer('manzanas')) {
    const fillProperty = in3d.value ? 'fill-extrusion-color' : 'fill-color';
    map.value.setPaintProperty('manzanas', fillProperty, [
      'case',
      ['boolean', ['feature-state', 'visible'], false],
      '#252756',
      in3d.value ? barraColores3D : barraColores,
    ]);
  }

  // Centrar el mapa en la sección seleccionada
  const sectionBbox = turf.bbox({
    type: 'FeatureCollection',
    features: features,
  });
  map.value.fitBounds(sectionBbox, { duration: 1000 });
};

// *** Método para obtener el estilo del botón ***
const getButtonStyle = (index, st) => {
  const isVisible = sectionVisibility.value[st] ?? false;
  return {
    backgroundColor: coloresMap.value[index],
    opacity: !isVisible ? 1 : 0.3,
  };
};

// Variables y estados
const animationId = ref(null);
const isAnimating = ref(false);

// Función para calcular el centroide
const calculateCentroid = (geojson) => {
  const centroid = turf.centroid(geojson);
  return centroid.geometry.coordinates;
};

// Función para iniciar la animación
const startAnimation = () => {
  if (!in3d.value || !map.value || !geojson.value) return; // Asegurarse de que está en modo 3D y el mapa está disponible

  const center = calculateCentroid(geojson.value);
  let angle = 0;
  const speed = 0.001; // Velocidad de la rotación más lenta

  const animateCamera = () => {
    angle += speed; // Incrementar el ángulo para la rotación

    map.value.easeTo({
      center: [center[0], center[1]],
      pitch: 60, // Ajustar la inclinación para un mejor efecto 3D
      bearing: (angle * 180) / Math.PI, // Ajustar el bearing para crear el efecto de rotación
      duration: 50, // Duración más corta para una animación más suave
      easing: (t) => t,
    });

    animationId.value = requestAnimationFrame(animateCamera);
  };

  animationId.value = requestAnimationFrame(animateCamera);
  isAnimating.value = true;
};

// Función para detener la animación
const stopAnimation = () => {
  if (animationId.value) {
    cancelAnimationFrame(animationId.value);
    animationId.value = null;
  }
  isAnimating.value = false;
};

// Función para alternar la animación
const toggleAnimation = () => {
  if (isAnimating.value) {
    stopAnimation();
  } else {
    startAnimation();
  }
};

// Detener la animación al desmontar el componente
onBeforeUnmount(() => {
  if (animationId.value) cancelAnimationFrame(animationId.value);
});

</script>

<style scoped>
.marker {
  background-size: cover;
  width: 32px;
  height: 32px;
}

/* Estiliza la barra de rango para navegadores basados en WebKit */
.inputTransparency[type=range]::-webkit-slider-runnable-track {
  background: #F472B6; /* Cambia el color de la barra aquí */
  height: 8px;
  border-radius: 4px;
}

.inputTransparency[type=range]::-webkit-slider-thumb {
  background: #ffffff; /* Cambia el color del pulgar aquí */
  border: 2px solid #F472B6;
  height: 16px;
  width: 16px;
  border-radius: 50%;
  margin-top: -4px; /* Ajusta la posición del pulgar */
  cursor: pointer;
}

/* Estiliza la barra de rango para Firefox */
.inputTransparency[type=range]::-moz-range-track {
  background: #F472B6; /* Cambia el color de la barra aquí */
  height: 8px;
  border-radius: 4px;
}
.inputTransparency[type=range]::-moz-range-thumb {
  background: #fff; /* Cambia el color del pulgar aquí */
  border: 2px solid #F472B6;
  height: 16px;
  width: 16px;
  border-radius: 50%;
  cursor: pointer;
}
</style>
