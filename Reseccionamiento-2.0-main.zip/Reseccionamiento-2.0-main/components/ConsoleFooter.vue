<template>
  <div class=" bg-gray-600 text-white pt-2 pb-2 shadow-md border text-center w-full">
    <div class="grid grid-cols-6 gap-1">
      <!-- ... -->
      <div class="col-end-1 col-span-2 pl-5">
        <div class="text-xs text-left font-bold">
          Departamento de Desarrollo de Herramientas Geoelectorales.
        </div>
        <div class="text-xs text-left">
          Subdirección de Desarrollo de Sistemas Geográficos Electorales.
        </div>
        <div class="text-xs text-left">
          Dirección de Cartografía Electoral.
        </div>
      </div>
      <div class="col-start-7 col-end-7 pr-3 w-28 mx-auto">
        <img src="@/assets/img/INE_blanco.png">
      </div>
    </div>
  </div>
</template>
