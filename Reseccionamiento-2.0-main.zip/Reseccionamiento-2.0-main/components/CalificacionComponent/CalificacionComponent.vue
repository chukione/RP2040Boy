<template>
  <div v-if="asignData == 'Success'" class="w-full flex flex-col items-center justify-center gap-4">
    <!--Tabla 1-->
    <div class="w-full">
      <table class="table-auto mx-auto">
        <thead class="bg-pink-500">
          <tr>
            <th
              scope="col"
              class="px-3 py-3 text-xs text-white uppercase tracking-wider border border-violet-300 text-center font-bold"
            >
              ST
            </th>
            <th
              scope="col"
              class="px-2 py-3 text-xs font-bold text-white uppercase tracking-wider border border-violet-300 text-center"
            >
              Rango
            </th>
            <th
              scope="col"
              class="px-2 py-3 text-xs font-bold text-white uppercase tracking-wider border border-violet-300 text-center"
            >
              Conformación
            </th>
            <th
              scope="col"
              class="px-2 py-3 text-xs font-bold text-white uppercase tracking-wider border border-violet-300 text-center"
            >
              Vialidad
            </th>
            <th
              scope="col"
              class="px-2 py-3 text-xs font-bold text-white uppercase tracking-wider border border-violet-300 text-center"
            >
              Sitio
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="(item, index) in calificacion"
            :key="index"
            :class="
              index % 2 === 0
                ? 'bg-white hover:bg-gray-300'
                : 'bg-gray-200 hover:bg-gray-300'
            "
          >
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300 text-center"
            >
              {{ calificacion[index].ST}}
            </td>
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300 text-center"
            >
              {{ roundNumbers(calificacion[index].Rango) }}
            </td>
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300 text-center"
            >
              {{ roundNumbers(calificacion[index].Conformacion) }}
            </td>
            <td
              class="px-2 py-2 whitespace-nowrap text-base text-black-500 border border-violet-300 text-center"
            >
              <div v-if="calificacion[index].Vialidad" style="color: #07f702">
                <IconComponent :icon="['fas', 'circle-check']" />
              </div>
              <div v-else style="color: #e91616">
                <IconComponent :icon="['fas', 'circle-xmark']" />
              </div>
            </td>
            <td
              class="px-2 py-2 whitespace-nowrap text-base text-black-500 border border-violet-300 text-center"
            >
              <div v-if="calificacion[index].Sitio" style="color: #07f702">
                <IconComponent :icon="['fas', 'circle-check']" />
              </div>
              <div v-else style="color: #e91616">
                <IconComponent :icon="['fas', 'circle-xmark']" />
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <!--Fin tabla 1-->
    <!--Tabla 2-->
    <div>
      <table class="table-auto mx-auto">
        <thead class="bg-pink-500">
          <tr>
            <th
              scope="col"
              class="px-2 py-2 text-xs text-white uppercase tracking-wider border border-violet-300 text-center font-bold"
            >
              Cumplimiento
            </th>
            <th
              scope="col"
              class="px-2 py-2 text-xs text-white uppercase tracking-wider border border-violet-300 text-center font-bold"
            >
              Total (puntos)
            </th>
          </tr>
        </thead>
        <tbody>
          <tr class="bg-white hover:bg-gray-300">
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300"
            >
              En rango de electores (30 pts):
            </td>
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300 text-center font-bold"
            >
              {{ roundNumbers(dataEscenario.Rango) }}
            </td>
          </tr>
          <tr class="bg-gray-200 hover:bg-gray-300">
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300"
            >
              En conformación (24 pts):
            </td>
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300 text-center font-bold"
            >
              {{ roundNumbers(dataEscenario.Conformacion) }}
            </td>
          </tr>
          <tr class="bg-white hover:bg-gray-300">
            <td
              class="px-2 py-2 whitespace-normal text-xs text-black-500 border border-violet-300"
            >
              En vialidades o fraccionamientos con barda que no dividan la
              sección de trabajo (22 pts):
            </td>
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300 text-center font-bold"
            >
              {{ roundNumbers(dataEscenario.Vialidad) }}
            </td>
          </tr>
          <tr class="bg-gray-200 hover:bg-gray-300">
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300"
            >
              En sitio para casilla (24 pts):
            </td>
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300 text-center font-bold"
            >
              {{ roundNumbers(dataEscenario.Sitio) }}
            </td>
          </tr>
          <tr class="bg-pink-50 hover:bg-pink-200">
            <td
              class="px-2 py-2 whitespace-nowrap text-xs text-black-500 border border-violet-300 text-center font-bold"
              colspan="2"
            >
              EVALUACIÓN DEL ESCENARIO:
              <a class="text-pink-600 font-extrabold text-lg">
                {{ roundNumbers(dataEscenario.Calificacion) }}
              </a>
              PUNTOS
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <!--Fin tabla 2-->
    <div class="w-full">
      <div class="mb-6">
        <button
          class="hover:bg-pink-600 hover:text-white uppercase w-full text-center text-base text-pink-600 font-bold border border-pink-600 rounded-md"
          @click="
            calificacion !== null && dataEscenario !== null
              ? imprimirFormato()
              : withoutQualification()
          "
        >
          <IconComponent :icon="['fas', 'print']" />
          Imprimir Formato
        </button>
      </div>
      <div>
        <NuxtLink to="/console">
          <button
            class="hover:bg-pink-600 hover:text-white uppercase w-full text-center text-base text-pink-600 font-bold border border-pink-600 rounded-md"
          >
            <IconComponent :icon="['fas', 'home']" />
            Regresar
          </button>
        </NuxtLink>
      </div>
    </div>
  </div>
</template>
<script setup>
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { storeToRefs } from 'pinia';
import { sideBarStore } from './../stores/sideBar';
import fondoPDF from '@/assets/img/fondoPDF.png';
import logoINE from '@/assets/img/INE_blanco.png';
import { roundNumbers } from '~/services/roundNumbers';
const { $notify } = useNuxtApp();
const storeSideBar = sideBarStore();
const {
  escenarioEdit,
  escenarioVer,
  goverment,
  goverments,
  district,
  etapa,
  section,
} = storeToRefs(storeSideBar);
const calificacion = ref([]);
const dataEscenario = ref([]);
const dataEscenario2 = reactive({}); // Se implemento esta segunda variable para poder obtener los datos en el pdf
const respuestaCalificacion = ref([]);
const route = useRoute();
const id = ref(null);
onMounted(() => {
  const path = route.path;
  if (path === '/console/editarEscenarios') {
    id.value = escenarioEdit.value.id;
  }
  if (path === '/console/verEscenario') {
    id.value = escenarioVer.value.Id;
  }
  getCalificacion();
});
const asignData = ref(null);
const getCalificacion = async () => {
  respuestaCalificacion.value = null;
  dataEscenario.value = null;
  calificacion.value = null;
  asignData.value = 'pending';
  console.log('Actualizamos Calificacion');
  try {
    const url = `http://localhost:3030/getDatosAndCalificaciones?id=${id.value}`;
    respuestaCalificacion.value = await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
    dataEscenario.value = respuestaCalificacion.value.datos_escenario;
    Object.assign(dataEscenario2, respuestaCalificacion.value.datos_escenario); // Variable para PDF
    calificacion.value = respuestaCalificacion.value.seccionesDeTrabajo;
    asignData.value = 'Success';
  } catch (error) {
    $notify({
      title: 'Calificación',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
  
// Se acciona en caso de que el componente no tenga calificacion
const withoutQualification = () => {
  $notify({
    title: 'Calificación',
    text: 'Ocurrió un error, el elemento aún no tiene calificación',
    type: 'danger',
  });
};
  
defineExpose({
  getCalificacion,
});
  
//////////////////////////////////////////////////////////
const imprimirFormato = () => {
     
  const doc = new jsPDF();
  
  // *** FONDO DEL PDF ***
  const fondoDelPDF = {
    image: fondoPDF,
  };
  
  // Obtener las dimensiones de la página
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  
  // Establecer la posición y escala del logo de fondo
  const fondoDelPDFX = 0;
  const fondoDelPDFY = 5;
  const fondoDelPDFWidth = pageWidth;
  const fondoDelPDFHeight = pageHeight;
  
  const principal = () => {
    // Agregar el logo de fondo con transparencia
    doc.addImage(
      fondoDelPDF.image,
      'PNG',
      fondoDelPDFX,
      fondoDelPDFY,
      fondoDelPDFWidth,
      fondoDelPDFHeight,
      '',
      'MEDIUM',
    );
  
    // *** TERMINA CODIGO FONDO DEL PDF ***
  
    // *** FONDO MORADO DEL ENCABEZADO ***
    // Filled square with red borders
    doc.setDrawColor(0);
    doc.setFillColor(154, 24, 106);
    doc.rect(0, 0, doc.internal.pageSize.getWidth(), 30, 'F');
  
    // *** TERMINA CODIGO DEL FONDO MORADO ***
  
    // *** INGRESAMOS EL LOGO DEL INE ***
    const logoContent = {
      image: logoINE,
      width: 40,
      height: 12,
    };
  
    doc.addImage(
      logoContent.image,
      'PNG',
      20,
      10,
      logoContent.width,
      logoContent.height,
    );
  
    // *** TERMINAMOS DE INGRESAR EL LOGO DEL INE ***
  
    // *** ENCABEZADO DE RESECCIONAMIENTO EN LA PARTE DERECHA ***
  
    doc.setFontSize(15);
    doc.setTextColor('white');
    doc.setFont('helvetica', 'normal');
    doc.text('Sistema de Reseccionamiento 2023', 190, 22, null, null, 'right');
  
    // *** TERMINAMOS DE INGRESAR EL ULTIMO ENCABEZADO ***
  };
  
  // Mandamos a llamar a nuestra función que muestra el encabezado y el fondo
  principal();
  
  // *** TITULO PRINCIPAL ***
  doc.setFontSize(15);
  doc.setTextColor(154, 24, 106);
  doc.setFont('helvetica', 'bold');
  doc.text(
    // 'GENERACIÓN DE PROPUESTAS DISTRITALES',
    `GENERACIÓN DE ${dataEscenario.value.NombreEtapa.toUpperCase()}`,
    105,
    45,
    null,
    null,
    'center',
  );
  
  // Regresamos al color normal del texto
  doc.setTextColor(0, 0, 0);
  
  // *** FIN TITULO PRINCIPAL ***
  
  // *** TITULO SECUNDARIO ***
  const govermentName = goverments.value[goverment.value].name.toUpperCase();
  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text(
    // `SONORA / DISTRITO FEDERAL ELECTORAL 6 / SECCIÓN 808`,
    `${govermentName} / DISTRITO FEDERAL ELECTORAL ${district.value} / SECCIÓN ${section.value}`,
    105,
    53,
    null,
    null,
    'center',
  );
  
  // *** FIN TITULO SECUNDARIO ***
  
  // *** TITULO PRIMERA TABLA ***
  
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('EVALUACIÓN DE LAS SECCIONES DE TRABAJO', 20, 66);
  
  // *** FIN TITULO TABLA ***
  
  // *** CREACIÓN DE LA PRIMERA TABLA ***
  
  // Obtener los datos de la variable calificacion
  // const data = this.calificacion;
  
  // Crear el arreglo de columnas para la tabla
  const columns = [
    { header: 'ST', dataKey: 'col1' },
    { header: 'Rango', dataKey: 'col2' },
    { header: 'Conformacion', dataKey: 'col3' },
    { header: 'Vialidad', dataKey: 'col4' },
    { header: 'Sitio', dataKey: 'col5' },
    // Agrega las columnas adicionales que necesites
  ];
  
  // Crear el arreglo de filas para la tabla
     
  const rows = calificacion.value.map((item) => ({
    col1: item.ST,
    col2:
        item.Rango === 0 || item.Rango % 1 === 0
          ? item.Rango
          : parseFloat(item.Rango).toFixed(4),
    col3:
        item.Conformacion === 0 || item.Conformacion % 1 === 0
          ? item.Conformacion
          : parseFloat(item.Conformacion).toFixed(4),
    col4:
        item.Vialidad === 0 || item.Vialidad % 1 === 0
          ? item.Vialidad
          : parseFloat(item.Vialidad).toFixed(4),
    col5:
        item.Sitio === 0 || item.Sitio % 1 === 0
          ? item.Sitio
          : parseFloat(item.Sitio).toFixed(4),
    // Agrega las columnas adicionales que necesites
  }));
  
  const headStyles = {
    fillColor: '#9A186A', // Cambia este valor al color deseado
    textColor: '#fff', // Cambia este valor al color deseado
  };
  
  // Configuración de los bordes
  // eslint-disable-next-line no-var
  var lineWidth = 1;
  // eslint-disable-next-line no-var
  var lineColor = '#fff';
  
  const cellStyles = {
    columnStyles: {
      col1: { fillColor: '#D73775', textColor: 'white', fontStyle: 'bold' },
      col2: { fillColor: '#f5f5f5', textColor: 'black', halign: 'center' },
      col3: { fillColor: '#f5f5f5', textColor: 'black', halign: 'center' },
      col4: { fillColor: '#f5f5f5', textColor: 'black', halign: 'center' },
      col5: { fillColor: '#f5f5f5', textColor: 'black', halign: 'center' },
    },
    // Agrega los estilos de bordes
    cellWidth: 40,
    cellHeight: 10,
    lineWidth,
    lineColor,
  };
  
  // Agregar la tabla al documento PDF
  doc.autoTable({
    columns,
    body: rows,
    startY: 69,
    headStyles,
    margin: { left: 20, right: 20 },
    styles: {
      fontSize: 12,
      halign: 'center',
    },
    ...cellStyles,
    // Agrega el código para dibujar los bordes
    didDrawCell: function (data) {
      // Dibuja los bordes izquierdos y derechos de las celdas
      doc.setLineWidth(lineWidth);
      doc.setDrawColor(lineColor);
      doc.line(
        data.cell.x,
        data.cell.y,
        data.cell.x,
        data.cell.y + data.cell.height,
      );
      doc.line(
        data.cell.x + data.cell.width,
        data.cell.y,
        data.cell.x + data.cell.width,
        data.cell.y + data.cell.height,
      );
  
      // Dibuja los bordes superiores de las celdas
      if (data.row.index === 0) {
        doc.line(
          data.cell.x,
          data.cell.y,
          data.cell.x + data.cell.width,
          data.cell.y,
        );
      }
  
      // Dibuja los bordes inferiores de las celdas
      if (data.row.index === data.table.body.length - 1) {
        doc.line(
          data.cell.x,
          data.cell.y + data.cell.height,
          data.cell.x + data.cell.width,
          data.cell.y + data.cell.height,
        );
      }
  
      // Dibuja los bordes internos de las celdas
      doc.setLineWidth(lineWidth);
      doc.setDrawColor(lineColor);
      doc.line(
        data.cell.x,
        data.cell.y,
        data.cell.x + data.cell.width,
        data.cell.y,
      );
      doc.line(
        data.cell.x,
        data.cell.y + data.cell.height,
        data.cell.x + data.cell.width,
        data.cell.y + data.cell.height,
      );
    },
  });
  
  // *** TABLA DOS ***
  
  const startYNewTable = doc.autoTable.previous.finalY + 20; // Ajusta el espacio entre las dos tablas según tu preferencia
  
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('EVALUACIÓN DEL ESCENARIO', 20, startYNewTable);
  
  const columnsNewTable = [
    { header: 'Cumplimiento', dataKey: 'col1' },
    { header: 'Valor', dataKey: 'col2' },
    { header: 'Calificación', dataKey: 'col3' },
  ];
  
  // Crear el arreglo de filas para la segunda tabla
  const col1Values = [
    'Rango de electores',
    'Conformación',
    'Vialidades y fraccionamientos que no dividan la ST',
    'Sitio para casilla',
  ];
  
  const col2Values = ['30 pts', '24 pts', '22 pts', '24 pts'];
  
  const col3Values = [
    dataEscenario2.Rango === 0 || dataEscenario2.Rango % 1 === 0
      ? dataEscenario2.Rango
      : parseFloat(dataEscenario2.Rango).toFixed(4),
    dataEscenario2.Conformacion === 0 || dataEscenario2.Conformacion % 1 === 0
      ? dataEscenario2.Conformacion
      : parseFloat(dataEscenario2.Conformacion).toFixed(4),
    dataEscenario2.Vialidad === 0 || dataEscenario2.Vialidad % 1 === 0
      ? dataEscenario2.Vialidad
      : parseFloat(dataEscenario2.Vialidad).toFixed(4),
    dataEscenario2.Sitio === 0 || dataEscenario2.Sitio % 1 === 0
      ? dataEscenario2.Sitio
      : parseFloat(dataEscenario2.Sitio).toFixed(4),
    dataEscenario2.Calificacion === 0 || dataEscenario2.Calificacion % 1 === 0
      ? dataEscenario2.Calificacion
      : parseFloat(dataEscenario2.Calificacion).toFixed(4),
  ];
  
  const rowsNewTable = col1Values.map((col1Value, index) => ({
    col1: col1Value,
    col2: col2Values[index],
    col3: col3Values[index] || '',
  }));
  
  const cellStyles2 = {
    columnStyles: {
      col1: { fillColor: '#f5f5f5', textColor: 'black', halign: 'left' },
      col2: { fillColor: '#f5f5f5', textColor: 'black', halign: 'center' },
      col3: {
        fillColor: '#D73775',
        textColor: 'white',
        fontStyle: 'bold',
        halign: 'center',
      },
    },
    // Agrega los estilos de bordes
    cellWidth: 40,
    cellHeight: 10,
    lineWidth,
    lineColor,
  };
  
  // Agregar la tabla al documento PDF
  doc.autoTable({
    columns: columnsNewTable, // Cambiado de columnsNewTable a columns
    body: rowsNewTable,
    startY: startYNewTable + 3,
    margin: { left: 20, right: 20 },
    headStyles,
    styles: {
      fontSize: 12,
    },
    ...cellStyles2,
    didParseCell: function (data) {
      const rowIndex = data.row.index;
      const columnIndex = data.column.index;
  
      if (rowIndex === 0) {
        // Si es la primera fila (encabezados)
        if (columnIndex === 1 || columnIndex === 2) {
          // Columnas 2 y 3
          data.cell.styles.halign = 'center'; // Centrar el texto del encabezado
        }
      }
    },
    didDrawCell: function (data) {
      // Dibuja los bordes izquierdos y derechos de las celdas
      doc.setLineWidth(lineWidth);
      doc.setDrawColor(lineColor);
      doc.line(
        data.cell.x,
        data.cell.y,
        data.cell.x,
        data.cell.y + data.cell.height,
      );
      doc.line(
        data.cell.x + data.cell.width,
        data.cell.y,
        data.cell.x + data.cell.width,
        data.cell.y + data.cell.height,
      );
  
      // Dibuja los bordes superiores de las celdas
      if (data.row.index === 0) {
        doc.line(
          data.cell.x,
          data.cell.y,
          data.cell.x + data.cell.width,
          data.cell.y,
        );
      }
  
      // Dibuja los bordes inferiores de las celdas
      if (data.row.index === data.table.body.length - 1) {
        doc.line(
          data.cell.x,
          data.cell.y + data.cell.height,
          data.cell.x + data.cell.width,
          data.cell.y + data.cell.height,
        );
      }
  
      // Dibuja los bordes internos de las celdas
      doc.setLineWidth(lineWidth);
      doc.setDrawColor(lineColor);
      doc.line(
        data.cell.x,
        data.cell.y,
        data.cell.x + data.cell.width,
        data.cell.y,
      );
      doc.line(
        data.cell.x,
        data.cell.y + data.cell.height,
        data.cell.x + data.cell.width,
        data.cell.y + data.cell.height,
      );
    },
  });
  
  // *** FIN TABLA DOS ***
  
  // *** EVALUACIÓN FINAL ***
  
  const startYNewTable2 = doc.autoTable.previous.finalY + 10; // Ajusta el espacio entre las dos tablas según tu preferencia
  const text = 'EVALUACIÓN FINAL DEL ESCENARIO: ';
  const secondText = `${
    dataEscenario2.Calificacion === 0 || dataEscenario2.Calificacion % 1 === 0
      ? dataEscenario2.Calificacion
      : parseFloat(dataEscenario2.Calificacion).toFixed(4)
  } PUNTOS`;
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  
  const textWidth = doc.getTextWidth(text);
  const secondTextWidth = doc.getTextWidth(secondText);
  const pageWidth2 = doc.internal.pageSize.getWidth() - 20;
  const xPosition = pageWidth2 - textWidth - secondTextWidth - 2; // Ajusta el espacio entre los textos
  
  doc.text(text, xPosition, startYNewTable2);
  doc.setTextColor(154, 24, 106);
  doc.text(secondText, xPosition + textWidth + 2, startYNewTable2);
  
  // *** FIN DE LA EVAUACIÓN FINAL ***
  
  // *** FIN DE LA CREACIÓN DE LA PRIMERA TABLA ***
  
  // // Abrir una nueva ventana con el PDF generado
  // const pdfDataUrl = doc.output('dataurl');
  // const ventanaNueva = window.open('', '_blank', 'width=600,height=400');
  // ventanaNueva.document.open();
  // ventanaNueva.document.write(
  //   `<iframe src="${pdfDataUrl}" style="width: 100%; height: 100%; border: none;"></iframe>`
  // );
  // ventanaNueva.document.close();
  
  // Generar un objeto Blob con el contenido del PDF
  const pdfBlob = doc.output('blob');
  
  // Crear una URL para el objeto Blob
  const pdfUrl = URL.createObjectURL(pdfBlob);
  
  // Abrir una nueva ventana emergente con el PDF
  const ventanaNueva = window.open(pdfUrl, '_blank', 'width=600,height=400');
  
  // Liberar la URL del objeto Blob cuando la ventana se cierre
  ventanaNueva.addEventListener('beforeunload', () => {
    URL.revokeObjectURL(pdfUrl);
  });
};
</script>
  
