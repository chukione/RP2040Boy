<template>
  <div class="bg-white shadow-md sm:rounded-lg border border-gray-200">
    <!-- header -->
    <div class="w-full flex flex-row mb-5 mt-3 px-6">
      <div>
        <img class="w-12" :src="ImageSrc">
      </div>
      <div class="ml-3">
        <div>
          <label class="text-lg font-bold">{{ props.escenario.Alias }}</label>
        </div>
        <div>
          <label class="text-labelsStats font-bold">{{
            `${props.escenario.Nstemporales} secciones de trabajo`
          }}</label>
        </div>
      </div>
    </div>
    <!-- /header -->
    <!-- Data -->
    <div
      v-for="item in getDataCards"
      :key="`informacion-${item.score}-${item.labelType}`"
      class="grid grid-cols-2 px-6"
    >
      <div class="col-span-1 text-xs flex flex-row">
        <label>{{ item.labelPuntos }}</label>
        <label class="ml-12">{{ item.labelType }}</label>
      </div>
      <div class="col-span-1 text-xs ml-16">
        {{ item.score }}
      </div>
    </div>
    <!-- Score -->
    <div
      class="flex justify-end items-center text-labelsStats font-bold mb-4 mt-2 px-2"
    >
      {{ roundNumbers(props.escenario.Calificacion) }}
    </div>
    <!-- Button poner v-if="props.escenario.guardado == 0" cuando este coenctado y listo els ervicio de validar -->
    <div
      v-if="props.escenario.Guardado == 0"
      class="w-full flex items-center justify-center mb-3 border-t border-gray-200"
    >
      <button
        class="mt-3 mb-3 py-2 px-4 border border-transparent text-sm font-bold rounded-md text-white bg-blue-600 shadow-sm hover:bg-blue-500 focus:outline-none focus:shadow-outline-blue focus:bg-blue-500 active:bg-blue-600 transition duration-150 ease-in-out"
        @click="openModal()"
      >
        <IconComponent :icon="['fas', 'square-check']" />
        Validar y Guardar
      </button>
    </div>
    <div
      v-else
      class="w-full flex items-center justify-center mb-3 border-t border-gray-200"
    >
      <button
        class="mt-3 mb-3 py-2 px-4 border border-transparent text-sm font-bold rounded-md text-white bg-green-600 shadow-sm hover:bg-green-500 focus:outline-none focus:shadow-outline-green focus:bg-green-500 active:bg-green-600 transition duration-150 ease-in-out"
        :disabled="true"
      >
        <IconComponent :icon="['fas', 'square-check']" />
        <label class="font-bold">
          {{
            `Guardado el ${props.escenario.Fguardado}`
          }}</label>
      </button>
    </div>
    <ConsoleModal ref="modalAction" @validatesave="saveValidate()" />
  </div>
</template>

<script setup>
import { storeToRefs } from 'pinia';
import { roundNumbers } from './../services/roundNumbers';
import { sideBarStore } from './../stores/sideBar';
const storeSideBar = sideBarStore();
const { goverment, district, section, etapa } =
  storeToRefs(storeSideBar);
const props = defineProps({
  escenario: {
    required: true,
    type: Object,
  },
});
const propId = props.escenario.Id;
console.log('propId: ', props.escenario);
console.log('propfguardado: ', props.escenario.Fguardado);
const modalAction = ref(null);
const ImageSrc = `/_nuxt/assets/${props.escenario.Logo}`;
const getDataCards = computed(() => {
  const data = [];
  data.push({
    labelPuntos: '(30pts)',
    labelType: 'Rango',
    score: roundNumbers(props.escenario.Rango),
  });
  data.push({
    labelPuntos: '(24pts)',
    labelType: 'Conformación',
    score: roundNumbers(props.escenario.Conformacion),
  });
  data.push({
    labelPuntos: '(22pts)',
    labelType: 'Vialidad',
    score: roundNumbers(props.escenario.Vialidad),
  });
  data.push({
    labelPuntos: '(24pts)',
    labelType: 'Sitio',
    score: roundNumbers(props.escenario.Sitio),
  });
  return data;
});
const openModal = () => {
  const title = '¿Quieres validar y guardar?';
  const message = '¿Quieres validar y guardar?';
  modalAction.value?.open(title, message);
};
const saveValidate = async () => {
  console.log('Ejecutar Actions******');
  if (Number(goverment.value) <= 0) {
    return;
  }
  try {
    // const url = `http://localhost:3030/guardarEscenario?idEscenario=${propId}&etapa=${etapa.value}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&typeUser=ADMINISTRADOR`;
    const url = `http://localhost:3030/guardarEscenario?idEscenario=${propId}&etapa=${etapa.value}&entidad=${goverment.value}&distrito=${district.value}&seccion=${section.value}&typeUser=MORENA-CDV`;

    await $fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
      },
      method: 'GET',
    });
  } catch (error) {
    $notify({
      title: 'Aprobar Escenario',
      text: 'Ocurrido un error, inténtelo más tarde',
      type: 'danger',
    });
  }
};
</script>
