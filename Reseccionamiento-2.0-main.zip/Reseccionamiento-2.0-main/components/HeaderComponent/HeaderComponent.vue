<template>
  <div :class="isDark ? 'modoOscuro' : 'bg-ineAzul'" class="dark:border-b-[0.5px] dark:border-ineRosa">
    <div class="px-4 py-2 w-full flex lg:flex-row md:flex-col flex-col lg:justify-between md:justify-between justify-center items-center">
      <!-- Part-One -->
      <div class="lg:mt-0 md:mt-0 mt-2 flex lg:flex-row md:flex-row flex-col items-center gap-3 py-2">
        <!-- Logo -->
        <div>
          <img
            class="h-[33px] mx-auto"
            src="@/assets/img/INE_blanco.png"
            alt=""
          >
        </div>
        <!--  Title -->
        <div class="text-[18px] text-white lg:text-start md:text-start text-center">
          <h1>
            Reseccionamiento 2024
          </h1>
        </div>
      </div>
      <!-- Part-Two -->
      <div
        class="flex justify-center items-center gap-5 mr-2"
      >
        <div class="flex items-center justify-center gap-1">
          <div class="flex items-center gap-1 text-[14px] text-white">
            <!-- User -->
            <div class="flex items-center gap-1">
              <UIcon name="i-heroicons-user" />
              <!-- <h1>{{ user }}</h1> -->
              <h1>Dante.Ezio</h1>
            </div>
            <div>
              <h1>|</h1>
            </div>
            <!-- Log out -->
            <!-- <div class="flex items-center gap-1 hover:text-slate-900 dark:text-gray-300 dark:hover:text-white cursor-pointer" @click="exit()"> -->
            <div class="flex items-center gap-1 hover:bg-gray-50/20 text-white hover:text-gray-50 dark:hover:bg-gray-800 cursor-pointer p-1.5 rounded-md">
              <UIcon name="i-heroicons-arrow-left-end-on-rectangle" />
              <h1>Cerrar sesión</h1>
            </div>
          </div>
          <!-- DarkMode -->
          <div>
            <UTooltip
              :text="isDark ? 'Habilitar modo normal' : 'Habilitar modo oscuro'"
            >
              <button class="hover:bg-gray-50/20 text-white hover:text-gray-50 dark:hover:bg-gray-800 p-1.5 rounded-md" @click="isDark = !isDark">
                <template v-if="isDark">
                  <UIcon size="24px" name="i-meteocons:clear-day-fill" dynamic />
                </template>
                <template v-else-if="!isDark">
                  <UIcon size="18px" name="i-line-md:moon-loop" dynamic />
                </template>
              </button>
            </UTooltip>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
//   const { $auth, $signOut } = useNuxtApp();
//   const storeDce = ssoStoreDce();
//   const user = ref(storeDce.user.userName);

//   const exit = () => {
//     $signOut($auth).then(() => {
//       navigateTo('/console');
//       window.location.reload();
//     }).catch((error) => {
//       console.error('error', error);
//     });
//   };
// DarkMode
const colorMode = useColorMode();
const isDark = computed({
  get () {
    return colorMode.value === 'dark';
  },
  set () {
    colorMode.preference = colorMode.value === 'dark' ? 'light' : 'dark';
  },
});
</script>
