<template>
  <div
    class="fixed top-0 right-0 flex items-start justify-end px-4 py-6 sm:p-6 pointer-events-auto"
  >
    <div class="max-w-sm w-full">
      <transition-group
        tag="div"
        :enter-active-class="
          sortedNotifications.length > 1
            ? 'transform ease-out delay-300 duration-300 transition'
            : 'transform ease-out duration-300 transition'
        "
        enter-class="translate-x-4 opacity-0"
        enter-to-class="translate-x-0 opacity-100"
        leave-active-class="transition ease-in duration-500"
        leave-class="opacity-100"
        leave-to-class="opacity-0"
        move-class="transition ease-in-out duration-500"
      >
        <notifications-list-item
          v-for="(notify, index) in sortedNotifications()"
          :key="notify.id"
          :notify="notify"
          :class="index > 0 ? 'mt-4' : ''"
          @remove="removeNotification"
        />
      </transition-group>
    </div>
  </div>
</template>

<script setup>
import { notifyStore } from './../stores/notificaciones';
const storeNotify = notifyStore();

const removeNotification = (id) => {
  storeNotify.removeNotification(id);
};

const sortedNotifications = () => {
  return [...storeNotify.notifications].reverse().reverse().slice(0, 4);
};
</script>
