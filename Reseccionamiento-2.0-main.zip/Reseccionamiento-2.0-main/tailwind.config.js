module.exports = {
  content: [
    './components/**/*.{js,vue,ts}',
    './layouts/**/*.vue',
    './pages/**/*.vue',
    './plugins/**/*.{js,ts}',
    './nuxt.config.{js,ts}',
  ],
  theme: {
    extend: {
      fontFamily: {

      },
      colors: {
        ineAzul: '#252756',
        ineMorado: '#512f73',
        ineRosa: '#bf889e',
        inePurpura: '#80416b',
        ineLila: '#ae80b7',
      },
    },
  },
  plugins: [

  ],
};
