<template>
  <div>
    <div class="flex flex-col min-h-[100vh]" :class="isDark ? 'modoOscuroMain' : 'bg-white'">
      <!-- Header -->
      <div ref="headerRef" class="sticky top-0 z-[99]">
        <HeaderComponent />
      </div>

      <!-- Main Content -->
      <div class="flex flex-grow">
        <!-- Sidebar -->
        <div v-if="showSideBar" ref="sidebarRef" :class="isDark ? 'modoOscuroMain' : 'bg-white text-ineAzul'">
          <SidebarComponent />
        </div>

        <div v-else class="w-[400px]">
          <SidebarEscenario />
        </div>

        <div class="flex-grow">
          <slot />
        </div>

        <!-- Alerts -->
        <notifications-list class="mt-10" />
      </div>

      <!-- Footer -->
      <div v-if="showFooter" ref="footerRef" class="z-10 ">
        <FooterComponent />
      </div>
    </div>
  </div>
</template>

<script setup>
import { medidasStores } from '@/stores/medidasStores';

// *** Manejo de Stores ***
const storeMedidas = medidasStores();
const setAltoDisponible = (val) => {
  storeMedidas.setDataAlto(val);
};
const setAltoDisponibleMain = (val) => {
  storeMedidas.setDataAltoMain(val);
};
const setAnchoDisponible = (val) => {
  storeMedidas.setDataAncho(val);
};

const route = useRoute();
const showSideBar = ref(true);
const showFooter = ref(true);
let resizeObserver;
onMounted(() => {
  showSideBar.value = route.path !== '/console/verEscenario';
  reloadSideBarpersistence();

  // *** Alto Disponible ***
  // Observar el redimensionamiento de la ventana
  resizeObserver = new ResizeObserver(updateDimensions);
  resizeObserver.observe(document.body);

  updateDimensions();
});

onUnmounted(() => {
  // Asegúrate de limpiar el observador cuando el componente se desmonte
  if (resizeObserver) {
    resizeObserver.disconnect();
  }
});

// Simplificamos la lógica del watcher
watch(
  () => route.path,
  (newPath) => {
    if (
      newPath === '/console/verEscenario' ||
      newPath === '/console/editarEscenarios'
    ) {
      showSideBar.value = false;
      showFooter.value = false;
    } else {
      showSideBar.value = true;
      showFooter.value = true;
    }
    // console.log('Ruta actual:', newPath, 'showSideBar:', showSideBar.value);
  },
  { immediate: true },
);

const reloadSideBarpersistence = () => {
  if (
    route.path === '/console/verEscenario' ||
    route.path === '/console/editarEscenarios'
  ) {
    showSideBar.value = false;
    showFooter.value = false;
  } else {
    showSideBar.value = true;
    showFooter.value = true;
  }
};

// *** Medidas Disponibles Dinamicas ***
const headerRef = ref(null);
const footerRef = ref(null);
const sidebarRef = ref(null);
const availableHeight = ref(null);
const availableMainHeight = ref(null);
const availableMainWidth = ref(null);
const updateDimensions = () => {
  // const headerHeight = headerRef.value ? headerRef.value.$el.clientHeight : 0; // Cuando el componente no esta dentro de un div
  const headerHeight = headerRef.value ? headerRef.value.clientHeight : 0;
  // console.log('headerHeight', headerHeight);
  const footerHeight = footerRef.value ? footerRef.value.clientHeight : 0;
  const sidebarWidth = sidebarRef.value ? sidebarRef.value.clientWidth : 0;
  // console.log('footerHeight', footerHeight);
  availableHeight.value = window.innerHeight - headerHeight;
  availableMainHeight.value = window.innerHeight - headerHeight - footerHeight;
  availableMainWidth.value = window.innerWidth - sidebarWidth;
  setAltoDisponible(availableHeight.value);
  setAltoDisponibleMain(availableMainHeight.value);
  setAnchoDisponible(availableMainWidth.value);
};

// DarkMode
const colorMode = useColorMode();
const isDark = computed({
  get () {
    return colorMode.value === 'dark';
  },
  set () {
    colorMode.preference = colorMode.value === 'dark' ? 'light' : 'dark';
  },
});
</script>
