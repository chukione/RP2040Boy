<template>
  <div class="h-screen w-full overflow-hidden flex flex-col">
    <div class="bg-navBar">
      <!-- <console-header /> -->
      <HeaderComponent />
    </div>
    <!-- TODO ADD to div -->
    <!-- v-if="user" -->
    <div
      class="h-screen flex overflow-hidden bg-white"
    >
      <!-- TODO add this -->
      <!-- <app-waiting v-if="waiting" /> -->
      <!-- <client-only> -->
      <div v-if="showSideBar">
        <ConsoleSideDesktop />
        <!-- <SidebarComponent/> -->
      </div>
      <div v-else class="w-96 mt-4 ml-4 overflow-auto scrollbar">
        <ConsoleTabsEscenario />
      </div>
      <!-- </client-only> -->
      <div class="flex flex-col w-0 flex-1 overflow-hidden">
        <main
          ref="main"
          class="flex-1 relative z-0 overflow-y-auto pb-6 focus:outline-none"
          tabindex="0"
        >
          <!-- <div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              <h1 class="text-2xl font-semibold text-gray-900">
                {{ title }}
              </h1>
            </div> -->
  
          <div class="max-w-7xl mx-auto">
            <!-- Replace with your content -->
            <div>
              <div class="h-auto">
                <slot />
              </div>
            </div>
            <!-- /End replace -->
          </div>
          <!-- TODO add this -->
          <notifications-list class="mt-10" />
        </main>
      </div>
    </div>
    <!-- footer -->
    <div class="bg-gray-200 shadow-md border text-center w-full">
      <!-- <console-footer /> -->
      <FooterComponent />
    </div>
    <!-- /footer -->
  </div>
</template>
  
<script setup>
  
const searchURL = new URL(window.location);
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const urlactual = searchURL.pathname;
const route = useRoute();
const showSideBar = ref(true);
onMounted(() => {
  showSideBar.value = route.path !== '/console/verEscenario';
  reloadSideBarpersistence();
});
watch(route, () => {
  if (route.path === '/console/verEscenario') {
    showSideBar.value = route.path !== '/console/verEscenario';
  } else if (route.path === '/console/editarEscenarios') {
    showSideBar.value = route.path !== '/console/editarEscenario';
    showSideBar.value = false;
    console.log(showSideBar.value);
  } else {
    showSideBar.value = true;
  }
});
const reloadSideBarpersistence = () => {
  if (route.path === '/console/verEscenario') {
    showSideBar.value = route.path !== '/console/verEscenario';
  } else if (route.path === '/console/editarEscenarios') {
    showSideBar.value = route.path !== '/console/editarEscenario';
    showSideBar.value = false;
  } else {
    showSideBar.value = true;
  }
};
</script>
  
  <style scoped>
  .scrollbar::-webkit-scrollbar {
    width: 6px; /* Ancho de la barra de desplazamiento */
  }
  
  .scrollbar::-webkit-scrollbar-track {
    background-color: transparent; /* Color de fondo de la barra de desplazamiento */
  }
  
  .scrollbar::-webkit-scrollbar-thumb {
    background-color: #d1d5db; /* Color del pulgar de la barra de desplazamiento */
    border-radius: 3px; /* Borde redondeado del pulgar de la barra de desplazamiento */
  }
  
  .scrollbar::-webkit-scrollbar-thumb:hover {
    background-color: #9ca3af; /* Color del pulgar de la barra de desplazamiento al pasar el cursor */
  }
  
  .scrollbar::-webkit-scrollbar-thumb:active {
    background-color: #6b7280; /* Color del pulgar de la barra de desplazamiento al hacer clic */
  }
  </style>
  
