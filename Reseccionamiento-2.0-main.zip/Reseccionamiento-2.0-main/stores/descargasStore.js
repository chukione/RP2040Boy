import { defineStore } from 'pinia';

export const descargasStore = defineStore('storeDescargas', {
  state: () => ({
    dataEscenario: null,
    dataAcuseGuardado: null,
    dataST: null,
    dataEvaluacionEscenario: null,
  }),
  actions: {
    setDataEscenario (val) {
      this.dataEscenario = val;
    },
    setDataAcuseGuardado (val) {
      this.dataAcuseGuardado = val;
    },
    setDataST (val) {
      this.dataST = val;
    },
    setDataEvaluacionEscenario (val) {
      this.dataEvaluacionEscenario = val;
    },
  },
});
