import { defineStore } from 'pinia';
import { goverments } from '../services/goverments';
export const sideBarStore = defineStore('sideBar', {
  state: () => ({
    goverments: [],
    goverment: 0,
    district: 0,
    sections: [],
    section: 0,
    etapa: 0,
    idEscenario: 0,
    dataEscenarios: [],
    dataCreateScenarios: [],
    escenarioEdit: null,
    st: 0,
    escenarioVer: [],
    selectedFeatures: [],
    banderaRePaint: false,
    EscenariosAprobar: [],
    selectedMenuOption: '', // Nueva propiedad para la opción del menú
    dataLiberarEscenario:[],
    routeLocationKey: null,
  }),
  persist: {
    storage: persistedState.localStorage,
  },
  getters: {
    govermentsIndex: (state) => {
      return state.goverments;
    },
  },
  actions: {
    //* mutations
    setEscenarioVer (val) {
      this.escenarioVer = val;
    },
    setST (val) {
      this.st = val;
    },
    setEscenarios (val) {
      this.dataEscenarios = val;
    },
    setEscenarioEdit (val) {
      this.escenarioEdit = val;
    },
    setCreateScenarios (val) {
      this.dataCreateScenarios = val;
    },
    setEscenariosAprobar (val) {
      this.EscenariosAprobar = val;
    },
    setGoverments (val) {
      this.goverments = val;
    },
    setGoverment (val) {
      this.goverment = val;
    },
    setGovermentCopyE(val){
      this.goverment = val;
    },
    setDistrict (val) {
      this.district = val;
    },
    setSections (val) {
      this.setions = val;
    },
    setSection (val) {
      this.section = val;
    },
    setEtapa (val) {
      this.etapa = val;
    },
    setIdEscenario (val) {
      this.idEscenario = val;
    },
    setIdsMzn (val) {
      this.selectedFeatures = val;
    },
    setBanderaRePaint (val) {
      this.banderaRePaint = val;
    },
    setRouteLocationKey (val) {
      this.routeLocationKey = val;
    },
    setSelectedMenuOption (value) { // Nueva acción para actualizar la opción del menú
      this.selectedMenuOption = value;
    },
    setLiberarEscenario (val) {
      this.dataLiberarEscenario = val;
    },
    //* actions
    getGoverments () {
      if (this.goverments.length > 0) {
        return this.goverments;
      }
      //* Get goverments from core service
      // const list = [{ id: 0, name: 'Selecciona una entidad', capital: '', slug: '', distritoFederal: '' }];
      const list = [];
      Object.keys(goverments).forEach((govermentId) => {
        const goverment = goverments[govermentId];
        list.push({
          id: parseInt(govermentId),
          name: goverment.name,
          capital: goverment.capital,
          slug: goverment.slug,
          distritoFederal: goverment.distrito.federal,
        });
      });
      this.setGoverments(list);
      return this.goverments;
    },
    getSections (payload) {
      const { goverment, district } = payload;
      return new Promise((resolve, reject) => {
        const url = `/search/sections?e=${goverment}&d=${district}`;
        $fetch(url, {
          headers: {
          },
          method: 'GET',
        })
          .then((res) => {
            if (res) {
              this.setSections(res);
              resolve(this.sections);
            } else {
              this.setSections([]);
            }
          })
          .catch((error) => {
            this.setSections([]);
            console.error(error);
            reject(error);
          });
      });
    },
  },
});
