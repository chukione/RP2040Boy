export const useStore = defineStore('useStore', () => {
  /* Variables de actualización de tiempo */
  const segundosRemesa = 10;
  const segundosGrafica = 10;
  const segundo = 1000;
  const tiempoActualizaRemesa = segundosRemesa * segundo;
  const tiempoActualizaGrafica = segundosGrafica * segundo;

  /* Variables de tienda */
  const eleccionSelected = ref(1);
  const entidadSelected = ref(null);
  const mapaSelected = ref(1);
  const graficaSelected = ref(1);
  const tipoContent = ref(1);
  const remesa = ref(null);
  const total = ref(0);
  const entidadName = ref('');

  const in3d = ref(false);

  const asesores = ref([]);
  const candidatos = ref([]);
  const actualizaIntervalo = ref(false);

  const actualizaGrafica = ref(false);

  const actualizaMiniMapa = ref(false);

  const desHabCandidato = (idCandidato) => {
    candidatos.value.find(item => item.id_candidato === idCandidato).activo ^= 1;
  };

  const desHabAsesor = (idAsesor) => {
    asesores.value.find(item => item.id_asesor === idAsesor).activo ^= 1;
  };

  return {
    in3d,
    entidadSelected,
    eleccionSelected,
    mapaSelected,
    graficaSelected,
    tipoContent,
    remesa,
    total,
    entidadName,
    asesores,
    candidatos,
    desHabCandidato,
    actualizaIntervalo,
    desHabAsesor,
    tiempoActualizaRemesa,
    tiempoActualizaGrafica,
    actualizaGrafica,
    actualizaMiniMapa,
  };
});
