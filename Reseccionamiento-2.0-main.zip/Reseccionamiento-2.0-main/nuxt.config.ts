// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  ssr: false,
  css: [
    '~/assets/sass/main.sass',
    '@/assets/css/main.css',
    '@fortawesome/fontawesome-svg-core/styles.css',
    'maplibre-gl/dist/maplibre-gl.css',
  ],
  modules: [//* Doc: https://www.npmjs.com/package/@nuxtjs/tailwindcss
    '@pinia/nuxt', // '@nuxtjs/tailwindcss', //* Doc: https://prazdevs.github.io/pinia-plugin-persistedstate/frameworks/nuxt-3.html
    '@pinia-plugin-persistedstate/nuxt', '@nuxt/ui',
    '@nuxt/eslint',
  ],
  plugins: [
    '~/plugins/notificacion.client.js',
  ],
  vite: {
    define: {
      'process.env.POLYGON_CLIPPING_MAX_QUEUE_SIZE': '1000000',
      'process.env.POLYGON_CLIPPING_MAX_SWEEPLINE_SEGMENTS': '1000000',
    },
  },
});
