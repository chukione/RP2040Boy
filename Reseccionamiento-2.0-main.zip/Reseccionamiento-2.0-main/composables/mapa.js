
const factorVolumen = 2;

const fetchListMznByST = async (idEsc, ent, distrito, sec) => {
  try {

    const url = `http://localhost:3030/getIdBySt?idEscenario=${idEsc}&entidad=${ent}&distrito=${distrito}&seccion=${sec}`;
    const response = await fetch(
      url,
      {
        method: 'GET',
      },
    );
    const data = await response.json();
    return data;
  } catch (error) {
    console.error(error);
  }
};

export const useGeoJSONFeaturesMultyPolygon = async ( geoMzn, idEsc, ent, distrito, sec) => {
  let geojson = null;
  let nombre = null;
  let dataMzn = null;
  geojson = geoMzn;
  nombre = 'manzanas';

  dataMzn = await fetchListMznByST(idEsc, ent, distrito, sec);
  
  let features = await geojson.features;

  features = await features.map((item) => {
    // encontrar el objeto correspondiente del arreglo de entrada que tenga el id de manzana en su propiedad ids_manzana
    // const propsMzn = dataMzn.find(obj => obj.ids_manzana.split(",").includes(String(item.properties.id)));
    // Se agrego esta linea para checar que no sea nulo
    const propsMzn = dataMzn.length > 0 ? dataMzn.find(obj => obj.ids_manzana.split(',').includes(String(item.properties.id))) : 0;
    return {
      type: item.type,
      geometry: item.geometry,
      properties: {
        ...item.properties,
        height: item.properties.l_nominal * factorVolumen,
        base_height: 0,
        st: propsMzn.st,
        rango: propsMzn.rango,
        conformacion: propsMzn.conformacion,
        sitio: propsMzn.sitio,
        vialidad: propsMzn.vialidad,
        lnominal_st: propsMzn.lnominal_st,
        padron_st: propsMzn.padron_st,
      },
      id: item.properties.id,
    };
  });

  const geoJSON = {
    type: 'FeatureCollection',
    name: nombre,
    crs: {
      type: 'name',
      properties: { name: 'urn:ogc:def:crs:OGC:1.3:CRS84' },
    },
    features,
  };

  return { geojson: geoJSON };
};

export const usePerimeterGeoJSON = (geojson) => {
  const features = geojson.features;
  const nombre = 'manzanas';
  const geoJSON = {
    type: 'FeatureCollection',
    name: nombre,
    crs: {
      type: 'name',
      properties: { name: 'urn:ogc:def:crs:OGC:1.3:CRS84' },
    },
    features,
  };
  return geoJSON;
};
