
export const usePaletaColoresSelected = ( arraySeleccion) => {
  let  arrayColoresSelected = [
    'case',
    ['in', ['get', 'id'], ['literal', arraySeleccion]],
    '#FFFF00',
    ['==', ['get', 'st'], 0],
    '#202020',
    ['==', ['get', 'st'], 1],
    '#B5179E',
    ['==', ['get', 'st'], 2],
    '#FF006E',
    ['==', ['get', 'st'], 3],
    '#7209B7',
    ['==', ['get', 'st'], 4],
    '#CA1E2B',
    ['==', ['get', 'st'], 5],
    '#FB5607',
    ['==', ['get', 'st'], 6],
    '#DE4D86',
    ['==', ['get', 'st'], 7],
    '#F29CA3',
    ['==', ['get', 'st'], 8],
    '#F7A072',
    ['==', ['get', 'st'], 9],
    '#457B9D',
    ['==', ['get', 'st'], 10],
    '#08BDBD',
    ['==', ['get', 'st'], 11],
    '#84E6F8',
    ['==', ['get', 'st'], 12],
    '#3A86FF',
    ['==', ['get', 'st'], 13],
    '#7678ED',
    ['==', ['get', 'st'], 14],
    '#29BF12',
    ['==', ['get', 'st'], 15],
    '#ABFF4F',
    ['==', ['get', 'st'], 16],
    '#DEFF0A',
    ['==', ['get', 'st'], 17],
    '#EDDEA4',
    ['==', ['get', 'st'], 18],
    '#008000',
    ['==', ['get', 'st'], 19],
    '#FBFF12',
    ['==', ['get', 'st'], 20],
    '#FFBE0B',
    '#000000',
  ];
  return arrayColoresSelected;

};

export const usePaletaColores = ( ) => {
  let arrayColores = [
    'case',
    ['==', ['get', 'st'], 0],
    '#202020',
    ['==', ['get', 'st'], 1],
    '#B5179E',
    ['==', ['get', 'st'], 2],
    '#FF006E',
    ['==', ['get', 'st'], 3],
    '#7209B7',
    ['==', ['get', 'st'], 4],
    '#CA1E2B',
    ['==', ['get', 'st'], 5],
    '#FB5607',
    ['==', ['get', 'st'], 6],
    '#DE4D86',
    ['==', ['get', 'st'], 7],
    '#F29CA3',
    ['==', ['get', 'st'], 8],
    '#F7A072',
    ['==', ['get', 'st'], 9],
    '#457B9D',
    ['==', ['get', 'st'], 10],
    '#08BDBD',
    ['==', ['get', 'st'], 11],
    '#84E6F8',
    ['==', ['get', 'st'], 12],
    '#3A86FF',
    ['==', ['get', 'st'], 13],
    '#7678ED',
    ['==', ['get', 'st'], 14],
    '#29BF12',
    ['==', ['get', 'st'], 15],
    '#ABFF4F',
    ['==', ['get', 'st'], 16],
    '#DEFF0A',
    ['==', ['get', 'st'], 17],
    '#EDDEA4',
    ['==', ['get', 'st'], 18],
    '#008000',
    ['==', ['get', 'st'], 19],
    '#FBFF12',
    ['==', ['get', 'st'], 20],
    '#FFBE0B',
    '#000000',
  ];
  return arrayColores;

};

// export const usePaletaColores = () => {
//   let arrayColores = [
//     'case',
//     ['==', ['get', 'st'], 0],
//     '#A8DADC', // Soft cyan
//     ['==', ['get', 'st'], 1],
//     '#457B9D', // Steel blue
//     ['==', ['get', 'st'], 2],
//     '#1D3557', // Dark blue
//     ['==', ['get', 'st'], 3],
//     '#FFB4A2', // Soft coral
//     ['==', ['get', 'st'], 4],
//     '#E5989B', // Dusty pink
//     ['==', ['get', 'st'], 5],
//     '#B5838D', // Mauve
//     ['==', ['get', 'st'], 6],
//     '#6D6875', // Grey purple
//     ['==', ['get', 'st'], 7],
//     '#BFD200', // Lime green
//     ['==', ['get', 'st'], 8],
//     '#FFC300', // Soft yellow
//     ['==', ['get', 'st'], 9],
//     '#FF8C42', // Soft orange
//     ['==', ['get', 'st'], 10],
//     '#D4A5A5', // Light rose
//     ['==', ['get', 'st'], 11],
//     '#7EBDC2', // Soft teal
//     ['==', ['get', 'st'], 12],
//     '#A2B9BC', // Light teal
//     ['==', ['get', 'st'], 13],
//     '#B2B1CF', // Lavender grey
//     ['==', ['get', 'st'], 14],
//     '#9B5DE5', // Purple
//     ['==', ['get', 'st'], 15],
//     '#F15BB5', // Pink
//     ['==', ['get', 'st'], 16],
//     '#00BBF9', // Light blue
//     ['==', ['get', 'st'], 17],
//     '#00F5D4', // Mint green
//     ['==', ['get', 'st'], 18],
//     '#FF006E', // Hot pink
//     ['==', ['get', 'st'], 19],
//     '#8338EC', // Deep purple
//     ['==', ['get', 'st'], 20],
//     '#FB5607', // Vivid orange
//     '#000000', // Default color (black)
//   ];
//   return arrayColores;
// };

export const usePaletaColores3D = () => {
  let arrayColores3D = [
    'case',
    ['boolean', ['feature-state', 'hover'], false],
    '#242C89',
    ['==', ['get', 'st'], 0],
    '#202020',
    ['==', ['get', 'st'], 1],
    '#B5179E',
    ['==', ['get', 'st'], 2],
    '#FF006E',
    ['==', ['get', 'st'], 3],
    '#7209B7',
    ['==', ['get', 'st'], 4],
    '#CA1E2B',
    ['==', ['get', 'st'], 5],
    '#FB5607',
    ['==', ['get', 'st'], 6],
    '#DE4D86',
    ['==', ['get', 'st'], 7],
    '#F29CA3',
    ['==', ['get', 'st'], 8],
    '#F7A072',
    ['==', ['get', 'st'], 9],
    '#457B9D',
    ['==', ['get', 'st'], 10],
    '#08BDBD',
    ['==', ['get', 'st'], 11],
    '#84E6F8',
    ['==', ['get', 'st'], 12],
    '#3A86FF',
    ['==', ['get', 'st'], 13],
    '#7678ED',
    ['==', ['get', 'st'], 14],
    '#29BF12',
    ['==', ['get', 'st'], 15],
    '#ABFF4F',
    ['==', ['get', 'st'], 16],
    '#DEFF0A',
    ['==', ['get', 'st'], 17],
    '#EDDEA4',
    ['==', ['get', 'st'], 18],
    '#008000',
    ['==', ['get', 'st'], 19],
    '#FBFF12',
    ['==', ['get', 'st'], 20],
    '#FFBE0B',
    '#202020',
  ];
  return arrayColores3D;
};
