import { environment } from '@/environments/environment';

export const useBaseMaps = () => {
  const propertiesBaseMap = {
    basemaps: [
      {
        id: 'Satelite',
        tiles: [
          `https://api.maptiler.com/maps/satellite/{z}/{x}/{y}@2x.jpg?${environment.keyMap}`,
        ],
        sourceExtraParams: {
          tileSize: 512,
          attribution: '<a href="https://www.google.com/intl/es_US/help/terms_maps/">Datos de Mapas &copy; 2023 Google, INEGI  </a>',
          minzoom: 0,
          maxzoom: 21,
        },
      },
      {
        id: 'JpMieruneDark',
        tiles: [
          `https://api.maptiler.com/maps/jp-mierune-dark/{z}/{x}/{y}@2x.png?${environment.keyMap}`,
        ],
        sourceExtraParams: {
          tileSize: 512,
          attribution: '<a href="https://www.google.com/intl/es_US/help/terms_maps/">Datos de Mapas &copy; 2023 Google, INEGI  </a>',
          minzoom: 0,
          maxzoom: 21,
        },
      },
      {
        id: 'Streets',
        tiles: [
          `https://api.maptiler.com/maps/streets-v2/{z}/{x}/{y}@2x.png?${environment.keyMap}`,
        ],
        sourceExtraParams: {
          tileSize: 512,
          attribution: '<a href="https://www.google.com/intl/es_US/help/terms_maps/">Datos de Mapas &copy; 2023 Google, INEGI  </a>',
          minzoom: 0,
          maxzoom: 21,
        },
      },
      {
        id: 'Toner',
        tiles: [
          `https://api.maptiler.com/maps/toner-v2/{z}/{x}/{y}@2x.png?${environment.keyMap}`,
        ],
        sourceExtraParams: {
          tileSize: 512,
          attribution: '<a href="https://www.google.com/intl/es_US/help/terms_maps/">Datos de Mapas &copy; 2023 Google, INEGI  </a>',
          minzoom: 0,
          maxzoom: 21,
        },
      },
      {
        id: 'Winter',
        tiles: [
          `https://api.maptiler.com/maps/winter-v2/{z}/{x}/{y}@2x.png?${environment.keyMap}`,
        ],
        sourceExtraParams: {
          tileSize: 512,
          minzoom: 0,
          maxzoom: 21,
        },
      },
      {
        id: 'Topo',
        tiles: [
          `https://api.maptiler.com/maps/topo-v2/{z}/{x}/{y}@2x.png?${environment.keyMap}`,
        ],
        sourceExtraParams: {
          tileSize: 512,
          minzoom: 0,
          maxzoom: 21,
        },
      },
    ],
    initialBasemap: 'JpMieruneDark',
    expandDirection: 'right',
  
  };
  return propertiesBaseMap;
};
