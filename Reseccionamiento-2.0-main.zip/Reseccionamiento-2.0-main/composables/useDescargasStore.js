import { ref, computed, onMounted } from 'vue';
// import { useRoute } from 'vue-router';
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/stores/sideBar';
import { descargasStore } from '@/stores/descargasStore';
import fondoPDF from '@/assets/img/fondoPDF.png';
import logoINE from '@/assets/img/INE_blanco.png';
import check from '@/assets/resources/img/circle-check-solid.png';
import xmark from '@/assets/resources/img/circle-xmark-solid.png';

export function useEscenario(idEscenario) {
  const storeSideBar = sideBarStore();
  const storeDescargas = descargasStore();
  const calificacion = ref([]);
  const dataEscenario = ref([]);
  const dataEscenario2 = ref({});
  const respuestaCalificacion = ref([]);
  const asignData = ref(null);
  const checkBase64 = ref(null);
  const xmarkBase64 = ref(null);
  const colorMode = useColorMode();
  const isDark = computed(() => colorMode.value === 'dark');

  const { $notify } = useNuxtApp();
  const { goverment, goverments, district, section } = storeToRefs(storeSideBar);
  //   const route = useRoute();

  onMounted(async () => {
    await getCalificacion();

    storeDescargas.setDataEvaluacionEscenario(rows.value);
    await fetchBase64Images();
    storeDescargas.setDataAcuseGuardado({
      fondoPDF,
      logoINE,
      dataEscenario,
      goverments,
      goverment,
      district,
      section,
      columns,
      rows,
      columnsNewTable,
      rowsNewTable,
      dataEscenario2,
      checkBase64: checkBase64.value,
      xmarkBase64: xmarkBase64.value,
    });
  });

  const getCalificacion = async () => {
    respuestaCalificacion.value = null;
    dataEscenario.value = null;
    calificacion.value = [];
    asignData.value = 'pending';

    try {
      const url = `http://localhost:3030/getDatosAndCalificaciones?id=${idEscenario}`;
      respuestaCalificacion.value = await $fetch(url, {
        headers: {
          Accept: 'application/json, text/plain, */*',
        },
        method: 'GET',
      });

      const { seccionesDeTrabajo, datos_escenario } = respuestaCalificacion.value;
      dataEscenario.value = datos_escenario;
      Object.assign(dataEscenario2.value, datos_escenario);
      calificacion.value = seccionesDeTrabajo;
      asignData.value = 'Success';
    } catch (error) {
      console.error('Error al obtener la calificación:', error);
      $notify({
        title: 'Calificación',
        text: 'Ocurrido un error, inténtelo más tarde',
        type: 'danger',
      });
    }
  };

  const withoutQualification = () => {
    $notify({
      title: 'Calificación',
      text: 'Ocurrió un error, el elemento aún no tiene calificación',
      type: 'danger',
    });
  };

  const columns = [
    { key: 'col1', label: 'ST' },
    { key: 'col2', label: 'RANGO' },
    { key: 'col3', label: 'CONFORMACIÓN' },
    { key: 'col4', label: 'VALIDAD' },
    { key: 'col5', label: 'SITIO' },
  ];

  const rows = computed(() => {
    return calificacion.value.map((item) => ({
      col1: item.ST,
      col2: item.Rango === 0 || item.Rango % 1 === 0 ? item.Rango : parseFloat(item.Rango).toFixed(4),
      col3: item.Conformacion === 0 || item.Conformacion % 1 === 0 ? item.Conformacion : parseFloat(item.Conformacion).toFixed(4),
      col4: item.Vialidad === 0 || item.Vialidad % 1 === 0 ? item.Vialidad : parseFloat(item.Vialidad).toFixed(4),
      col5: item.Sitio === 0 || item.Sitio % 1 === 0 ? item.Sitio : parseFloat(item.Sitio).toFixed(4),
    }));
  });

  const columnsNewTable = [
    { key: 'col1', label: 'CUMPLIMIENTO' },
    { key: 'col2', label: 'VALOR' },
    { key: 'col3', label: 'TOTAL (PUNTOS)' },
  ];

  const col1Values = [
    'Rango de electores',
    'Conformación',
    'Vialidades y fraccionamientos que no dividan la ST',
    'Sitio para casilla',
  ];

  const col2Values = ['30 pts', '24 pts', '22 pts', '24 pts'];

  const col3Values = computed(() => [
    dataEscenario2.value.Rango === 0 || dataEscenario2.value.Rango % 1 === 0 ? dataEscenario2.value.Rango : parseFloat(dataEscenario2.value.Rango).toFixed(4),
    dataEscenario2.value.Conformacion === 0 || dataEscenario2.value.Conformacion % 1 === 0 ? dataEscenario2.value.Conformacion : parseFloat(dataEscenario2.value.Conformacion).toFixed(4),
    dataEscenario2.value.Vialidad === 0 || dataEscenario2.value.Vialidad % 1 === 0 ? dataEscenario2.value.Vialidad : parseFloat(dataEscenario2.value.Vialidad).toFixed(4),
    dataEscenario2.value.Sitio === 0 || dataEscenario2.value.Sitio % 1 === 0 ? dataEscenario2.value.Sitio : parseFloat(dataEscenario2.value.Sitio).toFixed(4),
  ]);

  const rowsNewTable = computed(() => {
    return col1Values.map((col1Value, index) => ({
      col1: col1Value,
      col2: col2Values[index],
      col3: col3Values.value[index] || '',
    }));
  });

  async function fetchPngAndConvertToBase64(pngUrl) {
    try {
      const response = await fetch(pngUrl);
      const blob = await response.blob();
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    } catch (error) {
      console.error('Error al convertir el PNG a Base64:', error);
      return null;
    }
  }

  const fetchBase64Images = async () => {
    [checkBase64.value, xmarkBase64.value] = await Promise.all([
      fetchPngAndConvertToBase64(check),
      fetchPngAndConvertToBase64(xmark),
    ]);
  };

  const imagesReady = computed(() => checkBase64.value !== null && xmarkBase64.value !== null);

  async function imprimirFormato(nombreFormato) {
    if (!imagesReady.value) {
      await fetchBase64Images();
    }

    const { imprimirFormato } = useImprimirFormatoCalificacion(
      nombreFormato,
      fondoPDF,
      logoINE,
      dataEscenario,
      goverments,
      goverment,
      district,
      section,
      columns,
      rows,
      columnsNewTable,
      rowsNewTable,
      dataEscenario2,
      checkBase64.value,
      xmarkBase64.value,
    );
    imprimirFormato();
  }

  return {
    asignData,
    columns,
    rows,
    columnsNewTable,
    rowsNewTable,
    dataEscenario,
    isDark,
    calificacion,
    imagesReady,
    withoutQualification,
    imprimirFormato,
  };
}
