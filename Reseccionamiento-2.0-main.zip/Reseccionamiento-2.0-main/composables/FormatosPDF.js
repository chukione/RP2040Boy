import jsPDF from 'jspdf';
import 'jspdf-autotable';

export const useImprimirFormatoCalificacion = (nombreFormato, fondoPDF, logoINE, dataEscenario, goverments, goverment, district, section, columns, rows, columnsNewTable, rowsNewTable, dataEscenario2, check, xmark) => {
  const imprimirFormato = () => {
    const doc = new jsPDF();

    const fondoDelPDF = {
      image: fondoPDF,
    };

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    const fondoDelPDFX = 0;
    const fondoDelPDFY = 5;
    const fondoDelPDFWidth = pageWidth;
    const fondoDelPDFHeight = pageHeight;

    const principal = () => {
      doc.addImage(
        fondoDelPDF.image,
        'PNG',
        fondoDelPDFX,
        fondoDelPDFY,
        fondoDelPDFWidth,
        fondoDelPDFHeight,
        '',
        'MEDIUM',
      );

      doc.setDrawColor(0);
      doc.setFillColor(154, 24, 106);
      doc.rect(0, 0, doc.internal.pageSize.getWidth(), 30, 'F');

      const logoContent = {
        image: logoINE,
        width: 40,
        height: 12,
      };

      doc.addImage(
        logoContent.image,
        'PNG',
        20,
        10,
        logoContent.width,
        logoContent.height,
      );

      doc.setFontSize(15);
      doc.setTextColor('white');
      doc.setFont('helvetica', 'normal');
      doc.text('Sistema de Reseccionamiento 2024', 190, 22, null, null, 'right');
    };

    principal();

    doc.setFontSize(15);
    doc.setTextColor(255, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.text(
      nombreFormato.toUpperCase(),
      105,
      43,
      null,
      null,
      'center',
    );

    // 45, 53 62
    doc.setFontSize(12);
    doc.setTextColor(154, 24, 106);
    doc.setFont('helvetica', 'bold');
    doc.text(
      `GENERACIÓN DE ${dataEscenario.value.NombreEtapa.toUpperCase()}`,
      105,
      53,
      null,
      null,
      'center',
    );

    doc.setTextColor(0, 0, 0);

    // console.log(goverments.value.find(government => government.id === 1).name);
    // const govermentName = goverments.value[goverment.value].name.toUpperCase();
    const govermentName = goverments.value.find(government => government.id === goverment.value).name.toUpperCase();
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(
      `${govermentName} / DISTRITO FEDERAL ELECTORAL ${district.value} / SECCIÓN ${section.value}`,
      105,
      59,
      null,
      null,
      'center',
    );

    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.text('EVALUACIÓN DE LAS SECCIONES DE TRABAJO', 20, 70);

    const headStyles = {
      fillColor: '#9A186A',
      textColor: '#fff',
    };

    var lineWidth = 1;
    var lineColor = '#fff';

    const cellStyles = {
      columnStyles: {
        col1: { fillColor: '#D73775', textColor: 'white', fontStyle: 'bold' },
        col2: { fillColor: '#f5f5f5', textColor: 'black', halign: 'center' },
        col3: { fillColor: '#f5f5f5', textColor: 'black', halign: 'center' },
        col4: { fillColor: '#f5f5f5', textColor: 'black', halign: 'center' },
        col5: { fillColor: '#f5f5f5', textColor: 'black', halign: 'center' },
      },
      cellWidth: 40,
      cellHeight: 10,
      lineWidth,
      lineColor,
    };

    const transformedRows = rows.value.map(row => {
      return {
        ...row,
        col4: row.col4 === 1 ? '' : null,
        col5: row.col5 === 1 ? '' : null,
      };
    });
    doc.autoTable({
      head: [columns.map((col) => col.label)],
      columns: columns,
      body: transformedRows,
      startY: 73,
      headStyles,
      margin: { left: 20, right: 20 },
      styles: {
        fontSize: 12,
        halign: 'center',
      },
      ...cellStyles,
      didDrawCell: function (data) {
        doc.setLineWidth(lineWidth);
        doc.setDrawColor(lineColor);
        doc.line(
          data.cell.x,
          data.cell.y,
          data.cell.x,
          data.cell.y + data.cell.height,
        );
        doc.line(
          data.cell.x + data.cell.width,
          data.cell.y,
          data.cell.x + data.cell.width,
          data.cell.y + data.cell.height,
        );

        if (data.row.index === 0) {
          doc.line(
            data.cell.x,
            data.cell.y,
            data.cell.x + data.cell.width,
            data.cell.y,
          );
        }

        if (data.row.index === data.table.body.length - 1) {
          doc.line(
            data.cell.x,
            data.cell.y + data.cell.height,
            data.cell.x + data.cell.width,
            data.cell.y + data.cell.height,
          );
        }

        doc.setLineWidth(lineWidth);
        doc.setDrawColor(lineColor);
        doc.line(
          data.cell.x,
          data.cell.y,
          data.cell.x + data.cell.width,
          data.cell.y,
        );
        doc.line(
          data.cell.x,
          data.cell.y + data.cell.height,
          data.cell.x + data.cell.width,
          data.cell.y + data.cell.height,
        );

        if (data.column.dataKey === 'col4' || data.column.dataKey === 'col5') {
          if (data.cell.raw === '') {
            doc.addImage(check, 'PNG', data.cell.x + (data.cell.width / 2 - 2), data.cell.y + 1.7, 5, 5);
          } else if (data.cell.raw === null) {
            data.cell.text = '';
            doc.addImage(xmark, 'PNG', data.cell.x + (data.cell.width / 2 - 2), data.cell.y + 1.7, 5, 5);
          }
        }
      },
    });

    const startYNewTable = doc.autoTable.previous.finalY + 20;

    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('EVALUACIÓN DEL ESCENARIO', 20, startYNewTable);

    const cellStyles2 = {
      columnStyles: {
        col1: { fillColor: '#f5f5f5', textColor: 'black', halign: 'left' },
        col2: { fillColor: '#f5f5f5', textColor: 'black', halign: 'center' },
        col3: {
          fillColor: '#D73775',
          textColor: 'white',
          fontStyle: 'bold',
          halign: 'center',
        },
      },
      cellWidth: 40,
      cellHeight: 10,
      lineWidth,
      lineColor,
    };

    doc.autoTable({
      head: [columnsNewTable.map((col) => col.label)],
      columns: columnsNewTable,
      body: rowsNewTable.value,
      startY: startYNewTable + 3,
      margin: { left: 20, right: 20 },
      headStyles,
      styles: {
        fontSize: 12,
        halign: 'center',
      },
      ...cellStyles2,
      didDrawCell: function (data) {
        doc.setLineWidth(lineWidth);
        doc.setDrawColor(lineColor);
        doc.line(
          data.cell.x,
          data.cell.y,
          data.cell.x,
          data.cell.y + data.cell.height,
        );
        doc.line(
          data.cell.x + data.cell.width,
          data.cell.y,
          data.cell.x + data.cell.width,
          data.cell.y + data.cell.height,
        );

        if (data.row.index === 0) {
          doc.line(
            data.cell.x,
            data.cell.y,
            data.cell.x + data.cell.width,
            data.cell.y,
          );
        }

        if (data.row.index === data.table.body.length - 1) {
          doc.line(
            data.cell.x,
            data.cell.y + data.cell.height,
            data.cell.x + data.cell.width,
            data.cell.y + data.cell.height,
          );
        }

        doc.setLineWidth(lineWidth);
        doc.setDrawColor(lineColor);
        doc.line(
          data.cell.x,
          data.cell.y,
          data.cell.x + data.cell.width,
          data.cell.y,
        );
        doc.line(
          data.cell.x,
          data.cell.y + data.cell.height,
          data.cell.x + data.cell.width,
          data.cell.y + data.cell.height,
        );
      },
    });

    const startYNewTable2 = doc.autoTable.previous.finalY + 10;
    const text = 'EVALUACIÓN FINAL DEL ESCENARIO: ';
    const secondText = `${
      dataEscenario2.value.Calificacion === 0 || dataEscenario2.value.Calificacion % 1 === 0
        ? dataEscenario2.value.Calificacion
        : parseFloat(dataEscenario2.value.Calificacion).toFixed(4)
    } PUNTOS`;
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 0, 0);

    const textWidth = doc.getTextWidth(text);
    const secondTextWidth = doc.getTextWidth(secondText);
    const pageWidth2 = doc.internal.pageSize.getWidth() - 20;
    const xPosition = pageWidth2 - textWidth - secondTextWidth - 2;

    doc.text(text, xPosition, startYNewTable2);
    doc.setTextColor(154, 24, 106);
    doc.text(secondText, xPosition + textWidth + 2, startYNewTable2);

    const pdfBlob = doc.output('blob');
    const pdfUrl = URL.createObjectURL(pdfBlob);
    const ventanaNueva = window.open(pdfUrl, '_blank', 'width=600,height=400');

    ventanaNueva.addEventListener('beforeunload', () => {
      URL.revokeObjectURL(pdfUrl);
    });
  };

  return {
    imprimirFormato,
  };
};
