/**
 * Goverments
 */
export interface Goverment {
    capital: string;
    distrito: {
        federal: number;
        local: number;
    };
    name: string;
    slug: string;
}
export interface Goverments {
    [govermentId: string]: Goverment;
}
