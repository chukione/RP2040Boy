<template>
  <div>
    <NuxtPage />
  </div>
</template>

<script setup>
// This compiler macro works in both <script> and <script setup>
definePageMeta({
  layout: 'console',
});
</script>
