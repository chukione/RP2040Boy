<template>
  <div>
    <SidebarComponentTabsTabRecomendarEscenario />
  </div>
</template>

