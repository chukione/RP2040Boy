<template>
  <div>
    <SidebarComponentTabsTabVerEscenario />
  </div>
</template>
