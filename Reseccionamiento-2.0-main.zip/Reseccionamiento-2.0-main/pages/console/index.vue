<template>
  <div>
    <transition-group
      tag="div"
      class="w-full my-4 px-4 grid grid-cols-1 gap-4 lg:grid-cols-3 xl:grid-cols-6"
      enter-active-class="transition-all ease-out duration-100 transform"
      leave-active-class="transition-all ease-in duration-75 transform"
      enter-class="opacity-0 scale-75"
      enter-to-class="opacity-100 scale-100"
      leave-class="opacity-100 scale-100"
      leave-to-class="opacity-0 scale-75"
    />
  </div>
</template>
