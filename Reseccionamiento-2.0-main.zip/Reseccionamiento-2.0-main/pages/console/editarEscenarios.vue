<template>
  <div>
    <MapComponent2 />
  </div>
</template>
