<template>
  <div>
    <SidebarComponentTabsTabReportesTabReporteEscenarios />
  </div>
</template>
