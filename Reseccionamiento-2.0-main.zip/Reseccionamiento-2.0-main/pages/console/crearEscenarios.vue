<template>
  <div v-if="dataCreateScenarios.length > 0" :class="dataCreateScenarios.length > 1 ? 'justify-center' : 'justify-start'" class="flex flex-wrap gap-10 p-5">
    <SidebarComponentTabsTabCrearEscenarios
      v-for="esc in dataCreateScenarios"
      :key="`escenario-${esc.Id}`"
      :escenario="esc"
    />
  </div>
</template>
<script setup>
import { storeToRefs } from 'pinia';
import { sideBarStore } from '@/stores/sideBar';
const storeSideBar = sideBarStore();
const { dataCreateScenarios } = storeToRefs(storeSideBar);
</script>
