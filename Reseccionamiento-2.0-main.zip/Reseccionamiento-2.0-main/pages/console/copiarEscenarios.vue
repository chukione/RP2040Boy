<template>
  <div class="p-5">
    <SidebarComponentTabsTabCopiarEscenarios />
  </div>
</template>
