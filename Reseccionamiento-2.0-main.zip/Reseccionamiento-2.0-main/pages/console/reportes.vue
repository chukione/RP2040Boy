<template>
  <div >
    <div>
      <div class="flex py-3.5 border-b border-gray-200 dark:border-gray-700 pt-4">
        <UInput
          v-model="search"
          icon="i-heroicons-magnifying-glass-20-solid"
          placeholder="Buscar..."
          :ui="{
            color: {
              white: {
                outline: 'shadow-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white ring-1 ring-inset ring-gray-300 dark:ring-gray-700 focus:ring-2 focus:ring-pink-500 dark:focus:ring-primary-400',
              },
            },
          }"
        />
      </div>
      <div>
        <UTable :rows="filteredRows" :columns="columns" />
      </div>
      <div class="flex justify-between px-3 py-3.5 border-t-[0.5px] border-gray-400 dark:border-white">
        <div>
          <span class="text-sm leading-5">
            Mostrando
            <span class="font-medium"/>
            a
            <span class="font-medium"/>
            de
            <span class="font-medium"/>
            registros
          </span>
        </div>
        <div class="flex justify-end px-3 py-3.5 border-gray-200 dark:border-gray-700">
          <UPagination v-model="page" :page-count="pageCount" :total="people.length" />
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>

// *** Logica del DataTable ***
const page = ref(1);
const pageCount = 5;

const columns = [{
  key: 'id',
  label: 'ID',
  sortable: true,
}, {
  key: 'name',
  label: 'Name',
}, {
  key: 'title',
  label: 'Title',
}, {
  key: 'email',
  label: 'Email',
}, {
  key: 'role',
  label: 'Role',
}];

const people = [{
  id: 1,
  name: 'Lindsay Walton',
  title: 'Front-end Developer',
  email: 'lindsay.walton@example.com',
  role: 'Member',
}, {
  id: 2,
  name: 'Courtney Henry',
  title: 'Designer',
  email: 'courtney.henry@example.com',
  role: 'Admin',
}, {
  id: 3,
  name: 'Tom Cook',
  title: 'Director of Product',
  email: 'tom.cook@example.com',
  role: 'Member',
}, {
  id: 4,
  name: 'Whitney Francis',
  title: 'Copywriter',
  email: 'whitney.francis@example.com',
  role: 'Admin',
}, {
  id: 5,
  name: 'Leonard Krasner',
  title: 'Senior Designer',
  email: 'leonard.krasner@example.com',
  role: 'Owner',
}, {
  id: 6,
  name: 'Floyd Miles',
  title: 'Principal Designer',
  email: 'floyd.miles@example.com',
  role: 'Member',
}];

const search = ref('');

const filteredRows = computed(() => {
  if (!search.value) {
    return people.slice((page.value - 1) * pageCount, (page.value) * pageCount);
    // return people
  }

  return people.filter((person) => {
    return Object.values(person).some((value) => {
      return String(value).toLowerCase().includes(search.value.toLowerCase());
    });
  });
});

</script>
