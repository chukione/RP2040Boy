<template>
  <div>
    <SidebarComponentTabsTabReportesTabReporteComentarios />
  </div>
</template>
