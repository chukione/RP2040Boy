<template>
  <div class="flex justify-center items-center min-h-screen text-xl">
    <h1 class="text-red-500 font-bold">
      Page Index.
    </h1>
  </div>
</template>
