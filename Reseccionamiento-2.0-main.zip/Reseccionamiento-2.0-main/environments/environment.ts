export const environment = {
  keyMap: 'key=ohjYShQcLX1hleDQSMWj',
};
